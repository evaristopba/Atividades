# Correções de segurança aplicadas — 25/08/2026

Este documento registra as alterações feitas a partir da auditoria de
segurança do projeto Essência. Todas são **aditivas / de reforço** — nenhum
campo, coleção ou formato de dado existente foi removido ou renomeado, e nada
aqui muda o schema usado por outras versões do app que também apontam para
este mesmo projeto Firebase.

## 1. `firestore.rules` — falha crítica de controle de acesso (corrigida)

**O problema:** três funções auxiliares do bloco `match /pedidos/{pedidoId}`
não conferiam se quem fazia a requisição era o dono do pedido:

- `atualizacaoPublicaPedidoValida()` — permitia que **qualquer pessoa**
  (mesmo não autenticada), sabendo o ID de um pedido alheio, sobrescrevesse
  `comprovanteUrl` (comprovante de pagamento) ou `fcmToken` daquele pedido.
  Como `comprovanteUrl` não tinha validação de formato e é renderizado sem
  escape tanto no painel admin quanto na página pública de rastreio, isso
  permitia gravar HTML/JS arbitrário ali — um **XSS armazenado** capaz de
  rodar dentro da sessão logada do admin (que tem acesso a
  `/api/gerenciar-admin`, ou seja, poderia criar novos administradores,
  excluir contas, etc.).
- `cancelamentoPublicoPedidoValido()` — permitia que qualquer pessoa
  cancelasse o pedido de **outro** cliente.
- `solicitacaoCancelamentoValida()` — mesma falta de checagem de dono, e sem
  limite de tamanho para `motivoCancelamento` (texto livre também renderizado
  sem escape no admin).

**A correção:** as três funções agora exigem
`resource.data.compradorUid == request.auth.uid` (com o mesmo fallback já
usado em `edicaoEnderecoPublicaValida` para pedidos antigos, anteriores ao
login se tornar obrigatório, que não têm `compradorUid`). Além disso:
- `comprovanteUrl` agora precisa bater com o formato
  `data:(image/png|jpeg|webp|application/pdf);base64,...` e continuar abaixo
  de ~900 KB.
- `motivoCancelamento` agora tem limite de 500 caracteres.

**Compatibilidade:** essas três funções só existem no bloco `pedidos`, uma
coleção que, segundo o que foi descrito, não existe nas outras versões do
app — leitura (`get`/`list`) não foi alterada, e nenhuma coleção de cadastro
(produtos, categorias, clientes, fornecedores) foi tocada.

## 2. XSS — escape de dados não controlados pelo admin

Criado `js/seguranca.js` com duas funções:
- `escapeHtml(valor)` — escapa `& < > " '` antes de ir para `innerHTML`.
- `isDataUriComprovanteValida(valor)` — confirma que uma string é um
  data-URI de imagem/PDF no formato esperado antes de usá-la como
  `src`/`href` de um elemento (mesma regra usada no Firestore, como segunda
  camada de defesa no cliente).

Aplicado em `js/admin.js` e `js/pedido.js` nos pontos que renderizam dados
potencialmente vindos de um cliente (não do admin):
- Nome, telefone e endereço do comprador (tabela e modal de detalhe do
  pedido, painel admin; página pública de rastreio).
- Motivo de cancelamento solicitado pelo cliente (modal do admin).
- Nome do item copiado do produto no momento do pedido (defesa em
  profundidade — já era escrito só pelo servidor, mas custa pouco escapar).
- Comprovante de pagamento (`comprovanteUrl`): agora só é renderizado como
  `<img>`/`<a href>` se passar em `isDataUriComprovanteValida()`; caso
  contrário, mostra um aviso em vez de tentar exibir o valor.

Nenhuma coleção fora de `pedidos` foi alterada, então essa mudança também
não afeta as telas de cadastro (produtos, categorias, clientes,
fornecedores) nem as outras versões do app.

## 3. Cabeçalhos de segurança (`vercel.json`, novo arquivo)

Adicionado `Content-Security-Policy`, `X-Frame-Options: DENY`,
`X-Content-Type-Options: nosniff`, `Referrer-Policy` e `Permissions-Policy`
para todas as rotas. A CSP:
- **Não libera `'unsafe-inline'` para scripts** — é a barreira mais forte
  contra XSS: mesmo que um payload malicioso escape de alguma validação, o
  navegador se recusa a executar `<script>` ou `onerror=` injetados.
- Libera exatamente os domínios externos que o app realmente usa:
  `www.gstatic.com` (SDK do Firebase) e `cdnjs.cloudflare.com` (QRCode.js,
  só no admin) para scripts; `fonts.googleapis.com`/`fonts.gstatic.com` para
  fontes; `viacep.com.br` e `servicodados.ibge.gov.br` para os formulários
  de endereço; os domínios do Firebase/Firestore/Auth/FCM para dados.
- Libera `'unsafe-inline'` só em `style-src`, porque o app usa bastante
  `style="..."` inline nos templates — isso é necessário para não quebrar o
  layout e tem risco bem menor que scripts inline.

**Efeito colateral evitado:** `index.html` e `pedido.html` tinham um
`<script>` inline (registro do Service Worker) que a CSP acima bloquearia.
Movido para `js/sw-register.js` (arquivo novo, carregado normalmente via
`<script src="...">`) para manter a política sem `unsafe-inline` em scripts.

## 4. Senha mínima de administrador: 6 → 10 caracteres

Alterado em `api/gerenciar-admin.js` (validação real, no servidor) e
`js/admin.js` (feedback imediato no formulário). Contas de admin têm acesso
a dados de clientes/fornecedores e podem criar outras contas de admin — o
mínimo de 6 caracteres do Firebase Auth é baixo demais para esse nível de
privilégio.

## 5. `edicaoEnderecoPublicaValida` — troca de endereço após pagamento já enviado

**O problema (apontado pelo cliente após o primeiro round de correções):** a
regra só olhava `resource.data.status` para decidir se a edição de endereço
era permitida (`aguardando_frete`/`aguardando_pagamento`). Mas o `status`
só muda para `pago` quando o **admin confirma manualmente** — o cliente
pode já ter enviado o comprovante (pagamento real feito) enquanto o status
ainda está `aguardando_pagamento`, nessa janela até o admin revisar. Nesse
intervalo, a regra ainda permitia trocar o endereço (e recalcular o frete
do zero), abrindo brecha para pagar frete de um endereço e redirecionar a
entrega para outro sem acerto de diferença.

**A correção:** adicionado `pagamentoJaEnviado = comprovanteUrl != null &&
comprovanteUrl != ''` como condição extra — uma vez que existe comprovante
anexado, a edição de endereço é bloqueada, independente do que o `status`
formalmente ainda diz.

**Pendência resolvida:** `cancelamentoPublicoPedidoValido` (auto-cancelamento
pelo cliente) recebeu o mesmo guard (`!pagamentoJaEnviado`). Confirmado que
isso não afeta o cancelamento automático por expiração de 24h (feito pelo
dashboard do admin em `js/admin.js`), pois esse fluxo passa pela primeira
condição de `allow update` (`ehAdmin() && atualizacaoAdminPedidoValida()`),
independente das funções de auto-atendimento do cliente.


- **Rate limiting** em `/api/criar-pedido` e na criação de conta de
  cliente — hoje nada impede um script de criar dezenas de pedidos/contas
  por minuto. Implementar exige um armazenamento externo de contadores
  (ex.: Vercel KV, Upstash Redis), já que funções serverless não mantêm
  estado entre chamadas.
- **MFA (segundo fator)** para contas de admin — o Firebase Auth suporta,
  mas é uma decisão de produto/UX que vale alinhar antes de ativar
  (obrigatório para todos os admins? opcional?).
- Escapar também os campos de produto (`nome`, `marca`, `descricao`) em
  `js/public.js` por defesa em profundidade — risco baixo hoje (só o admin
  escreve esses campos), mas relevante se um dia a conta de admin for
  comprometida por outra via.

## 6. Interface desatualizada em relação às novas regras (`js/pedido.js`)

**O problema (apontado pelo cliente, com print de tela):** depois das
correções 4 e 5 no `firestore.rules`, os botões "Trocar endereço" e
"Cancelar meu pedido" continuavam aparecendo na página pública de rastreio
mesmo com o comprovante já enviado — porque a condição que decide *mostrar*
esses botões em `js/pedido.js` nunca tinha sido atualizada para refletir a
nova regra. O dado em si já estava protegido (a escrita seria recusada pelo
Firestore), mas o cliente só descobriria isso depois de preencher tudo e
tomar um erro genérico — má experiência, mesmo sem brecha de segurança.

**A correção:**
- `renderTrocaEndereco`: escondido o botão quando `comprovanteUrl` existe;
  no lugar, uma frase explicando que a troca não é mais possível.
- `renderBlocoCancelamento`: identificado um terceiro estado que não tinha
  tratamento nenhum — comprovante já enviado, mas status ainda não é
  `'pago'` (admin não confirmou). Nesse caso nem o autocancelamento nem o
  "solicitar cancelamento" (que exige `status == 'pago'`) se aplicam;
  agora esse estado mostra uma mensagem própria orientando a falar
  diretamente com a loja.

## 7. Nova funcionalidade: produtos em promoção

**Por que não usar uma categoria "Promoção":** cada produto só tem uma
`categoriaId` (é um `select`, não múltipla escolha) — usar categoria pra
promoção obrigaria escolher entre a categoria real (ex.: "Masculino") e
"Promoção", ou reescrever todo o modelo pra suportar múltiplas tags
(mexeria em filtro, formulário, `criar-pedido.js`, bloqueio de exclusão de
categoria com produtos vinculados). Muito mais trabalho pro mesmo
resultado.

**O que foi feito:** dois campos novos e opcionais no produto —
`emPromocao` (checkbox) e `valorPromocional` (número) — ortogonais à
categoria, aproveitando o formulário genérico do admin (`ENTIDADES.produtos`)
que já suporta esses tipos de campo sem código extra.

Criado `js/promocao.js` com a função `precoEfetivo(produto)`, única fonte
da regra "isso está em promoção de verdade?": só conta como promoção se
`emPromocao === true` **e** `valorPromocional` for um número válido, maior
que zero, **e menor que** `valorAVista` (evita mostrar uma "promoção" mais
cara por erro de digitação). Usada em:
- `js/public.js`: selo de desconto e preço riscado no card do catálogo e
  no modal de detalhe; ordenação "menor/maior preço" agora considera o
  preço promocional; valor adicionado ao carrinho já reflete a promoção.
- `js/admin.js`: preço riscado na coluna "À vista / Prazo" da listagem de
  produtos.

**Ponto de segurança (igual ao que já era feito com o preço normal):** o
preço que realmente é cobrado nunca vem do navegador — `api/criar-pedido.js`
tem sua própria cópia da mesma validação (`precoEfetivoProduto`, duplicada
porque o servidor é CommonJS e o front-end é ES module) e recalcula o preço
direto do Firestore no momento da compra. Mesmo que alguém adultere o
carrinho no DevTools fingindo um preço promocional que não existe, o
servidor ignora isso e cobra o valor real.

**Compatibilidade:** campos novos e opcionais — produtos sem `emPromocao`/
`valorPromocional` continuam se comportando exatamente como antes, em
qualquer versão do app que leia a coleção `produtos`. Não foi preciso
alterar `firestore.rules` (a escrita em `produtos` já era `if ehAdmin()`,
sem lista de campos permitidos).

## 8. Nova funcionalidade: galeria de fotos por produto (até 4)

**Decisão de arquitetura (conversamos antes de implementar):** Firebase
Storage deixou de ser realmente gratuito — desde 3 de fevereiro de 2026,
manter acesso a um bucket exige o plano pago (Blaze), mesmo que o uso real
fique dentro da faixa gratuita do Google Cloud. Como a prioridade agora é
"sem custos", optamos por continuar guardando as fotos como base64 dentro
do próprio documento do produto no Firestore (mesmo modelo que já existia
para a foto única) — só ajustando os números para caber várias fotos no
limite de 1MB por documento.

**Compressão ajustada:** lado máximo da imagem reduzido de 560px para
480px, qualidade-alvo de 320KB para 180KB por foto. Com isso, 4 fotos somam
~720KB, deixando folga para os demais campos do produto. Adicionada também
uma checagem no admin que avisa *antes* de tentar salvar se a soma das
fotos passar de 950KB (evita um erro genérico de rede caso o Firestore
recuse por estourar o limite).

**Schema (aditivo):** novo campo `fotos` (array de data-URIs em base64,
ordem = ordem de exibição, primeira é a capa). O campo `fotoUrl` que já
existia continua sendo escrito, sempre igual a `fotos[0]` — é o que toda a
tabela do admin, o carrinho e qualquer outra versão do app sempre leram, e
continuam lendo sem precisar de nenhuma mudança. Produtos cadastrados antes
desta funcionalidade (sem o campo `fotos`) continuam funcionando
normalmente — o formulário de edição reaproveita `fotoUrl` como a primeira
foto da galeria ao abrir para editar.

**Admin (`js/admin.js`):** campo do formulário trocado de upload único para
uma galeria com miniaturas — adicionar (até 4), remover, e marcar qualquer
uma como capa (reordena para primeira posição).

**Catálogo público (`js/public.js`):** no card da grade, um selo `📷 N`
aparece quando o produto tem mais de uma foto (a foto exibida no card
continua sendo só a capa, para não pesar o carregamento da grade). No modal
de detalhe do produto: miniaturas clicáveis, setas de navegação, e clique
na foto principal abre um **lightbox** em tela cheia (zoom, navegação por
setas/teclado, fecha com Esc ou clique fora).

**Compatibilidade:** nenhuma mudança em `firestore.rules` (escrita em
`produtos` já era só `if ehAdmin()`). Nenhuma outra coleção foi tocada.
Outras versões do app que só conhecem `fotoUrl` continuam funcionando
exatamente como antes.

## 9. Correção de bug: clique para editar produto parou de funcionar

**O que quebrou:** ao trocar o upload de foto única pela galeria (item 8),
removi a declaração da variável antiga (`fotoBase64Selecionada`) mas deixei
três referências órfãs a ela dentro de `abrirFormulario` e `salvarEntidade`.
Como o arquivo é um módulo ES (modo estrito), atribuir a uma variável não
declarada lança `ReferenceError` em vez de criar uma global silenciosa —
isso quebrava a função inteira toda vez que alguém tentava abrir o
formulário de edição de um produto (pelo clique na linha ou pelo botão
"Editar"), com o mesmo erro se repetindo a cada tentativa (por isso o
contador incrementando no console — é o DevTools agrupando o mesmo erro
repetido).

**A correção:** removidas as referências órfãs e todo o código morto do
fluxo antigo de upload de foto única (o bloco de renderização `tipo ===
'foto'` e o wiring de `fotoPreviewWrap`/`fotoInput` em `abrirFormulario`),
já que nenhuma entidade usa mais esse tipo de campo — foi inteiramente
substituído pela galeria.

**Como validei desta vez:** em vez de só ler o código, montei um ambiente
de teste real (servidor estático local + Firebase "falso" simulando um
admin logado com 2 produtos de exemplo, um deles sem o campo `fotos` para
testar compatibilidade) e usei um navegador headless (Playwright) para
clicar de verdade nos mesmos lugares que você clicou: linha do produto,
botão "Editar", adicionar/remover foto, definir capa, e abrir o formulário
de produto novo. Rodei o teste primeiro contra o arquivo com o bug (reproduzi
o `ReferenceError` exatamente como você descreveu) e depois contra a versão
corrigida (zero erros em todos os cenários) — não é uma correção só "no
papel".

## 10. Restaurado `.vercelignore` (encontrado ao comparar com a primeira versão do app)

**O que faltava:** comparando com o `Perfumaria.zip` (primeira versão do
app), notei que o arquivo `.vercelignore` da raiz do projeto tinha se
perdido em algum ponto da evolução até a versão atual. Sem ele, a Vercel
publica o repositório inteiro como site estático por padrão — o que
significa que `firestore.rules` (o mapa completo das regras de segurança)
e `README.md` (documentação técnica detalhada) ficariam acessíveis
publicamente em `seusite.com/firestore.rules` e `seusite.com/README.md`,
sem exigir login nenhum.

**A correção:** restaurado o `.vercelignore` da v1, e adicionado também
`SECURITY-FIXES.md` à lista — esse arquivo é ainda mais sensível que o
README, porque documenta em detalhe exatamente quais vulnerabilidades
existiram e como foram exploráveis. Nenhum desses arquivos deixa de existir
no repositório (continuam lá para consulta e para colar no Console do
Firebase) — só deixam de ser publicados como parte do site.

## 11. Correção: trava de scroll da lightbox não confiável no iOS

**O problema:** a lightbox de zoom (item 8, galeria de fotos) travava o
scroll de fundo com `document.body.style.overflow = 'hidden'`. Essa
técnica é conhecida por não funcionar de forma confiável no Safari do iOS
— bug antigo do WebKit onde o toque ainda consegue "arrastar" a página por
trás do elemento em tela cheia, e ao fechar a posição de rolagem podia
pular para um lugar diferente de onde o usuário estava.

**A correção:** trocado por uma técnica mais robusta — ao abrir a
lightbox, o `body` é fixado no lugar exato onde estava (`position: fixed`
+ deslocamento negativo via `top`); ao fechar, o `position` é removido e a
página rola de volta para exatamente a mesma posição de antes
(`window.scrollTo`). Funciona de forma consistente em iOS, Android e
desktop.

**Validado com teste automatizado** (navegador headless emulando viewport
de iPhone): confirmado que o scroll fica genuinamente travado enquanto a
lightbox está aberta e retorna à posição exata de antes ao fechar, em vez
de só revisar o código.

**Escopo:** afeta só a lightbox de zoom da galeria de fotos. O modal
principal do produto e os modais do painel admin não usam essa técnica de
trava (sempre dependeram só de `position: fixed` cobrindo a tela) e não
foram alterados.

## 12. Correção crítica: edição de endereço bloqueada mesmo sem pagamento (bug nas regras da 2ª rodada)

**O que quebrou:** ao implementar os itens 5 e 5-bis (bloquear edição de
endereço e auto-cancelamento depois que o comprovante é enviado), escrevi
`resource.data.comprovanteUrl != null` acessando o campo direto. O
problema: `comprovanteUrl` **nunca é inicializado** quando o pedido é
criado (`api/criar-pedido.js`) — só passa a existir no documento depois que
o cliente envia um comprovante pela primeira vez. No Firestore, acessar
diretamente (via `.`) um campo que não existe no documento lança o erro
`"Property comprovanteUrl is undefined on object"`, e um erro de avaliação
de regra **nega a operação inteira** — não só a parte que dependia daquele
campo. Na prática, isso bloqueava a edição de endereço e o cancelamento
para **todo pedido ainda não pago** (a maioria dos casos), exatamente o
oposto do que devia acontecer.

Confirmei essa causa comparando com relatos técnicos independentes sobre
esse exato comportamento do Firestore (não tinha como rodar o emulador
aqui para testar ao vivo, porque a instalação do `firebase-tools` exige
acesso à internet que este ambiente não tem).

**A correção:** troca de `resource.data.comprovanteUrl` por
`resource.data.get('comprovanteUrl', null)` — a forma segura `.get(campo,
valorPadrão)` do Firestore, que retorna o valor padrão em vez de lançar
erro quando o campo não existe. Aplicado em `edicaoEnderecoPublicaValida` e
`cancelamentoPublicoPedidoValido`.

**Blindagem preventiva:** encontrei o mesmo padrão de risco em
`atualizacaoAdminPedidoValida` (código anterior a estas correções, não
relacionado ao seu relato) — `cancelamentoSolicitado` também nunca é
inicializado na criação do pedido. Apliquei a mesma correção lá por
precaução, mesmo sem confirmação de que já tinha causado problema (só seria
acionado ao despachar um pedido que nunca foi contestado).

**Comportamento final, confirmado correto:** pedido sem pagamento → cliente
pode trocar endereço e cancelar livremente. Pedido com comprovante já
enviado → nem uma coisa nem outra; só o admin decide (confirmar, cancelar e
reembolsar por fora do sistema).

## Como testar antes de publicar

1. `firebase deploy --only firestore:rules` já valida a sintaxe do arquivo
   inteiro — se algo estiver errado, ele recusa o deploy e as regras
   antigas continuam ativas.
2. Simular no **Rules Playground** do Console do Firebase uma atualização
   de `comprovanteUrl`/`motivoCancelamento` num pedido de teste, autenticado
   como o próprio comprador e como outro usuário, para confirmar que só o
   dono consegue escrever.
3. Depois do deploy da CSP, abrir o site e checar o console do navegador —
   qualquer recurso bloqueado por engano aparece ali como
   `Refused to load/execute ... because it violates the following Content
   Security Policy directive`.
