// ============================================================================
// ⚠️⚠️⚠️  ATENÇÃO: SUBSTITUA OS PLACEHOLDERS ABAIXO PELOS DADOS REAIS  ⚠️⚠️⚠️
// ============================================================================
//
// Este arquivo PRECISA ter os mesmos dados do js/firebase-config.js.
// Se deixar com placeholder, as notificações push NÃO FUNCIONAM.
//
// COPIE o objeto firebaseConfig do js/firebase-config.js (já preenchido)
// e cole aqui, substituindo o objeto abaixo.
// ============================================================================

importScripts('https://www.gstatic.com/firebasejs/10.14.1/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.14.1/firebase-messaging-compat.js');

firebase.initializeApp({
  apiKey: "AIzaSyDh_AqBiKhzuqmAdOuvux7aGvBvzl_6h2U",
  authDomain: "toque-zen.firebaseapp.com",
  projectId: "toque-zen",
  storageBucket: "toque-zen.firebasestorage.app",
  messagingSenderId: "778431982220",
  appId: "1:778431982220:web:df14feec23b50818d2e9a9"
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  const notificationTitle = payload.notification?.title || 'Essência Perfumaria';
  const notificationOptions = {
    body: payload.notification?.body || '',
    icon: payload.notification?.icon || '/icon-192.png',
    badge: '/icon-72.png',
    data: payload.data || {},
    requireInteraction: false,
  };
  self.registration.showNotification(notificationTitle, notificationOptions);
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const urlToOpen = event.notification.data?.link || '/';
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((windowClients) => {
      for (let client of windowClients) {
        if (client.url === urlToOpen && 'focus' in client) {
          return client.focus();
        }
      }
      if (clients.openWindow) {
        return clients.openWindow(urlToOpen);
      }
    })
  );
});
