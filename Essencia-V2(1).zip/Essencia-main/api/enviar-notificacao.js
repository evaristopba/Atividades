// ============================================================================
// /api/enviar-notificacao.js
// ============================================================================
// Função serverless separada para envio de notificações push (FCM).
// Requer a variável de ambiente FIREBASE_SERVICE_ACCOUNT.
// ============================================================================

const admin = require('firebase-admin');

function inicializarAdmin() {
  if (admin.apps.length) return;
  const raw = process.env.FIREBASE_SERVICE_ACCOUNT;
  if (!raw) {
    throw new Error('FIREBASE_SERVICE_ACCOUNT não configurada nas variáveis de ambiente da Vercel.');
  }
  let serviceAccount;
  try {
    serviceAccount = JSON.parse(raw);
  } catch (e) {
    throw new Error('FIREBASE_SERVICE_ACCOUNT não é um JSON válido.');
  }
  admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
}

async function pegarUsuarioAutenticado(req) {
  const authHeader = req.headers.authorization || '';
  const idToken = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
  if (!idToken) {
    const erro = new Error('Token de autenticação ausente.');
    erro.status = 401;
    throw erro;
  }
  try {
    return await admin.auth().verifyIdToken(idToken);
  } catch (err) {
    const erro = new Error('Token inválido ou expirado.');
    erro.status = 401;
    throw erro;
  }
}

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Método não permitido.' });
    return;
  }

  try {
    inicializarAdmin();
  } catch (err) {
    console.error('Erro ao inicializar Firebase Admin:', err);
    res.status(500).json({ error: err.message });
    return;
  }

  let body = req.body;
  if (typeof body === 'string') {
    try { body = JSON.parse(body); } catch (e) { body = {}; }
  }
  const { titulo, corpo, link } = body || {};

  try {
    const decoded = await pegarUsuarioAutenticado(req);
    if (decoded.role !== 'owner') {
      res.status(403).json({ error: 'Apenas o proprietário pode enviar notificações.' });
      return;
    }

    if (!titulo || !corpo) {
      res.status(400).json({ error: 'Título e corpo são obrigatórios.' });
      return;
    }

    const tokensSnap = await admin.firestore().collection('fcmTokens').get();
    const tokens = tokensSnap.docs.map(d => d.id).filter(Boolean);

    if (tokens.length === 0) {
      res.status(400).json({ error: 'Nenhum dispositivo inscrito para receber notificações.' });
      return;
    }

    // Usar sendMulticast para compatibilidade com firebase-admin v12
    const message = {
      notification: { title: titulo, body: corpo },
      webpush: {
        notification: {
          icon: 'https://via.placeholder.com/192?text=E',
          badge: 'https://via.placeholder.com/72?text=E',
        },
        fcmOptions: { link: link || '/' }
      },
      tokens: tokens,
    };

    let response;
    try {
      // Tentar sendEachForMulticast (v11.4+)
      response = await admin.messaging().sendEachForMulticast(message);
    } catch (e) {
      // Fallback para sendMulticast (versões antigas)
      response = await admin.messaging().sendMulticast(message);
    }

    const invalidTokens = [];
    response.responses.forEach((resp, idx) => {
      if (!resp.success) {
        const errCode = resp.error?.code || resp.error?.message;
        if (errCode && (errCode.includes('invalid-registration') || errCode.includes('not-registered'))) {
          invalidTokens.push(tokens[idx]);
        }
      }
    });

    if (invalidTokens.length > 0) {
      const batch = admin.firestore().batch();
      invalidTokens.forEach(t => batch.delete(admin.firestore().doc('fcmTokens/' + t)));
      await batch.commit();
    }

    res.status(200).json({
      ok: true,
      enviados: response.successCount,
      falhas: response.failureCount,
      removidos: invalidTokens.length,
      total: tokens.length
    });
  } catch (err) {
    console.error('Erro em /api/enviar-notificacao:', err);
    res.status(err.status || 500).json({ error: err.message || 'Erro interno.' });
  }
};
