// ============================================================================
// /api/notificar-pedido.js
// ============================================================================
// Chamada pelo painel admin (autenticado) sempre que o status de um pedido
// muda. Envia push só pro token FCM daquele pedido específico — diferente
// de /api/enviar-notificacao, que faz broadcast pra todo mundo inscrito.
// ============================================================================

const admin = require('firebase-admin');

function inicializarAdmin() {
  if (admin.apps.length) return;
  const raw = process.env.FIREBASE_SERVICE_ACCOUNT;
  if (!raw) throw new Error('FIREBASE_SERVICE_ACCOUNT não configurada nas variáveis de ambiente da Vercel.');
  let serviceAccount;
  try { serviceAccount = JSON.parse(raw); }
  catch (e) { throw new Error('FIREBASE_SERVICE_ACCOUNT não é um JSON válido.'); }
  admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
}

async function pegarUsuarioAutenticado(req) {
  const authHeader = req.headers.authorization || '';
  const idToken = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
  if (!idToken) {
    const erro = new Error('Token de autenticação ausente.');
    erro.status = 401;
    throw erro;
  }
  try {
    return await admin.auth().verifyIdToken(idToken);
  } catch (err) {
    const erro = new Error('Token inválido ou expirado. Faça login novamente.');
    erro.status = 401;
    throw erro;
  }
}

const MENSAGENS = {
  frete_definido: { titulo: 'Frete definido! 📦', corpo: 'Já calculamos sua entrega — finalize o pagamento pra seguirmos com o pedido.' },
  pago: { titulo: 'Pagamento confirmado! 🎉', corpo: 'Recebemos seu pagamento — já estamos preparando seu pedido.' },
  despachado: { titulo: 'Pedido a caminho! 🚚', corpo: 'Seu pedido saiu para entrega.' },
  entregue: { titulo: 'Pedido entregue! ✨', corpo: 'Esperamos que você ame seu novo perfume.' },
};

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Método não permitido.' });
    return;
  }

  try {
    inicializarAdmin();
  } catch (err) {
    console.error('Erro ao inicializar Firebase Admin:', err);
    res.status(500).json({ error: err.message });
    return;
  }

  try {
    const decoded = await pegarUsuarioAutenticado(req);
    if (decoded.role !== 'owner' && decoded.role !== 'operador') {
      res.status(403).json({ error: 'Sem permissão para essa operação.' });
      return;
    }

    let body = req.body;
    if (typeof body === 'string') {
      try { body = JSON.parse(body); } catch (e) { body = {}; }
    }
    const { pedidoId, status } = body || {};
    if (!pedidoId || !MENSAGENS[status]) {
      res.status(400).json({ error: 'Dados inválidos.' });
      return;
    }

    const db = admin.firestore();
    const snap = await db.collection('pedidos').doc(pedidoId).get();
    if (!snap.exists) {
      res.status(404).json({ error: 'Pedido não encontrado.' });
      return;
    }
    const token = snap.data().fcmToken;
    if (!token) {
      res.status(200).json({ ok: true, enviado: false, motivo: 'Cliente não ativou notificações para este pedido.' });
      return;
    }

    const msg = MENSAGENS[status];
    try {
      await admin.messaging().send({
        token,
        notification: { title: msg.titulo, body: msg.corpo },
        data: { pedidoId, status },
      });
      res.status(200).json({ ok: true, enviado: true });
    } catch (err) {
      console.warn('Falha ao enviar push (token pode estar inválido/expirado):', err.message);
      res.status(200).json({ ok: true, enviado: false, motivo: 'Token inválido ou expirado.' });
    }
  } catch (err) {
    const status = err.status || 500;
    console.error('Erro em /api/notificar-pedido:', err);
    res.status(status).json({ error: err.message || 'Erro interno.' });
  }
};
