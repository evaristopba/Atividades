// ============================================================================
// /api/gerenciar-admin.js
// ============================================================================
// Função serverless da Vercel (Node.js). É o ÚNICO lugar do sistema com
// permissão para criar logins de administrador, excluir contas e definir
// o papel (owner/operador) de cada um — usando o Firebase Admin SDK com
// uma credencial de conta de serviço.
//
// Isso é o que torna a separação de papéis "de verdade": o papel vira um
// "custom claim" dentro do próprio token de autenticação do Firebase, e
// só quem tem essa credencial de servidor consegue escrever nele. Nenhum
// código rodando no navegador do usuário (nem via DevTools) tem esse poder.
//
// Requer a variável de ambiente FIREBASE_SERVICE_ACCOUNT configurada na
// Vercel (ver README.md para o passo a passo de como gerar).
// ============================================================================

const admin = require('firebase-admin');

function inicializarAdmin() {
  if (admin.apps.length) return;
  const raw = process.env.FIREBASE_SERVICE_ACCOUNT;
  if (!raw) {
    throw new Error('FIREBASE_SERVICE_ACCOUNT não configurada nas variáveis de ambiente da Vercel.');
  }
  let serviceAccount;
  try {
    serviceAccount = JSON.parse(raw);
  } catch (e) {
    throw new Error('FIREBASE_SERVICE_ACCOUNT não é um JSON válido. Confira se colou o conteúdo completo do arquivo gerado pelo Firebase.');
  }
  admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
}

async function pegarUsuarioAutenticado(req) {
  const authHeader = req.headers.authorization || '';
  const idToken = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
  if (!idToken) {
    const erro = new Error('Token de autenticação ausente.');
    erro.status = 401;
    throw erro;
  }
  try {
    return await admin.auth().verifyIdToken(idToken);
  } catch (err) {
    const erro = new Error('Token inválido ou expirado. Faça login novamente.');
    erro.status = 401;
    throw erro;
  }
}

function exigirOwner(decoded) {
  if (decoded.role !== 'owner') {
    const erro = new Error('Apenas o proprietário pode fazer essa operação.');
    erro.status = 403;
    throw erro;
  }
}

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Método não permitido.' });
    return;
  }

  try {
    inicializarAdmin();
  } catch (err) {
    console.error('Erro ao inicializar Firebase Admin:', err);
    res.status(500).json({ error: err.message });
    return;
  }

  let body = req.body;
  if (typeof body === 'string') {
    try { body = JSON.parse(body); } catch (e) { body = {}; }
  }
  const { action, payload } = body || {};

  try {
    const decoded = await pegarUsuarioAutenticado(req);

    // BOOTSTRAP: só funciona se ainda não existir NENHUM owner no projeto.
    // É assim que o primeiro administrador (criado manualmente no Console
    // do Firebase) vira "proprietário" sem precisar de intervenção manual.
    if (action === 'bootstrap') {
      const { users } = await admin.auth().listUsers(1000);
      const jaTemOwner = users.some(u => u.customClaims && u.customClaims.role === 'owner');
      if (jaTemOwner) {
        res.status(403).json({
          error: 'Já existe um proprietário configurado neste projeto. Peça para ele te atribuir um papel na aba Administradores.'
        });
        return;
      }
      await admin.auth().setCustomUserClaims(decoded.uid, { role: 'owner' });
      res.status(200).json({ ok: true, role: 'owner' });
      return;
    }

    // Todas as ações abaixo exigem que quem está chamando já seja owner.
    if (action === 'listar') {
      exigirOwner(decoded);
      const { users } = await admin.auth().listUsers(1000);
      const lista = users.map(u => ({
        uid: u.uid,
        email: u.email,
        nome: u.displayName || (u.email ? u.email.split('@')[0] : 'Sem nome'),
        role: (u.customClaims && u.customClaims.role) || 'sem-papel',
        criadoEm: u.metadata.creationTime,
      }));
      res.status(200).json({ ok: true, admins: lista });
      return;
    }

    if (action === 'criar') {
      exigirOwner(decoded);
      const { nome, email, senha, role } = payload || {};
      if (!nome || !email || !senha || !role) {
        res.status(400).json({ error: 'Preencha nome, e-mail, senha e nível de acesso.' });
        return;
      }
      // Endurecido (auditoria de segurança): contas de admin têm acesso a
      // dados de clientes/fornecedores e à própria gestão de outros admins
      // — o mínimo de 6 caracteres do Firebase Auth é baixo demais para
      // esse nível de privilégio.
      if (senha.length < 10) {
        res.status(400).json({ error: 'A senha precisa ter pelo menos 10 caracteres.' });
        return;
      }
      if (role !== 'owner' && role !== 'operador') {
        res.status(400).json({ error: 'Nível de acesso inválido.' });
        return;
      }
      let novoUsuario;
      try {
        novoUsuario = await admin.auth().createUser({ email, password: senha, displayName: nome });
      } catch (err) {
        const map = {
          'auth/email-already-exists': 'Esse e-mail já está cadastrado como administrador.',
          'auth/invalid-email': 'E-mail inválido.',
        };
        res.status(400).json({ error: map[err.code] || 'Não foi possível criar o usuário.' });
        return;
      }
      await admin.auth().setCustomUserClaims(novoUsuario.uid, { role });
      res.status(200).json({ ok: true, uid: novoUsuario.uid });
      return;
    }

    if (action === 'atualizarPapel') {
      exigirOwner(decoded);
      const { uid, role } = payload || {};
      if (!uid || !role) {
        res.status(400).json({ error: 'uid e role são obrigatórios.' });
        return;
      }
      if (role !== 'owner' && role !== 'operador') {
        res.status(400).json({ error: 'Nível de acesso inválido.' });
        return;
      }
      if (uid === decoded.uid) {
        res.status(400).json({ error: 'Você não pode alterar seu próprio nível de acesso — peça para outro proprietário fazer isso.' });
        return;
      }
      await admin.auth().setCustomUserClaims(uid, { role });
      res.status(200).json({ ok: true });
      return;
    }

    if (action === 'excluir') {
      exigirOwner(decoded);
      const { uid } = payload || {};
      if (!uid) {
        res.status(400).json({ error: 'uid é obrigatório.' });
        return;
      }
      if (uid === decoded.uid) {
        res.status(400).json({ error: 'Você não pode excluir a própria conta por aqui.' });
        return;
      }
      await admin.auth().deleteUser(uid);
      res.status(200).json({ ok: true });
      return;
    }

    res.status(400).json({ error: 'Ação desconhecida.' });
  } catch (err) {
    const status = err.status || 500;
    console.error('Erro em /api/gerenciar-admin:', err);
    res.status(status).json({ error: err.message || 'Erro interno.' });
  }
};
