// ============================================================================
// /api/criar-pedido.js
// ============================================================================
// Login agora é OBRIGATÓRIO pra fechar pedido — este endpoint exige e
// verifica o token de autenticação do cliente (não é mais opcional).
// Continua com o mesmo cuidado de sempre: o valor de cada item é lido do
// Firestore aqui no servidor, nunca aceito do que o navegador envia — isso
// torna impossível adulterar o preço editando o carrinho no DevTools.
// ============================================================================

const admin = require('firebase-admin');

// Mesma regra usada em js/promocao.js (não dá pra compartilhar o módulo
// direto porque este arquivo é CommonJS e aquele é ES module — mantenha os
// dois em sincronia se um dia mudar a regra de promoção). Este é o cálculo
// que REALMENTE decide quanto o cliente paga; a exibição no catálogo é só
// cosmética e nunca é confiada aqui.
function precoEfetivoProduto(produto) {
  const precoOriginal = Number(produto.valorAVista) || 0;
  const promo = Number(produto.valorPromocional);
  const emPromocao = produto.emPromocao === true &&
    Number.isFinite(promo) && promo > 0 && promo < precoOriginal;
  return emPromocao ? promo : precoOriginal;
}

function inicializarAdmin() {
  if (admin.apps.length) return;
  const raw = process.env.FIREBASE_SERVICE_ACCOUNT;
  if (!raw) throw new Error('FIREBASE_SERVICE_ACCOUNT não configurada nas variáveis de ambiente da Vercel.');
  let serviceAccount;
  try { serviceAccount = JSON.parse(raw); }
  catch (e) { throw new Error('FIREBASE_SERVICE_ACCOUNT não é um JSON válido.'); }
  admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
}

async function pegarClienteAutenticado(req) {
  const authHeader = req.headers.authorization || '';
  const idToken = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
  if (!idToken) {
    const erro = new Error('É preciso estar logado para finalizar um pedido.');
    erro.status = 401;
    throw erro;
  }
  try {
    return await admin.auth().verifyIdToken(idToken);
  } catch (err) {
    const erro = new Error('Sessão expirada. Faça login de novo.');
    erro.status = 401;
    throw erro;
  }
}

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Método não permitido.' });
    return;
  }

  try {
    inicializarAdmin();
  } catch (err) {
    console.error('Erro ao inicializar Firebase Admin:', err);
    res.status(500).json({ error: err.message });
    return;
  }

  let body = req.body;
  if (typeof body === 'string') {
    try { body = JSON.parse(body); } catch (e) { body = {}; }
  }
  const { comprador, itens, fcmToken } = body || {};

  try {
    const decoded = await pegarClienteAutenticado(req);

    if (!comprador || !String(comprador.nome || '').trim() || !String(comprador.telefone || '').trim()) {
      res.status(400).json({ error: 'Informe nome e telefone.' });
      return;
    }
    if (!['entrega', 'retirada'].includes(comprador.tipoEntrega)) {
      res.status(400).json({ error: 'Escolha entrega ou retirada.' });
      return;
    }
    if (comprador.tipoEntrega === 'entrega' && !String(comprador.endereco || '').trim()) {
      res.status(400).json({ error: 'Informe o endereço de entrega.' });
      return;
    }
    if (!Array.isArray(itens) || itens.length === 0) {
      res.status(400).json({ error: 'Carrinho vazio.' });
      return;
    }
    if (itens.length > 30) {
      res.status(400).json({ error: 'Carrinho com itens demais em um único pedido.' });
      return;
    }

    const db = admin.firestore();
    const itensValidados = [];
    let valorTotal = 0;

    for (const it of itens) {
      const quantidade = Number(it?.quantidade);
      if (!it?.produtoId || !Number.isFinite(quantidade) || quantidade < 1 || quantidade > 50) {
        res.status(400).json({ error: 'Item inválido no carrinho.' });
        return;
      }
      const snap = await db.collection('produtos').doc(it.produtoId).get();
      if (!snap.exists || snap.data().ativo !== true) {
        res.status(400).json({ error: 'Um dos produtos do carrinho não está mais disponível. Atualize a página e tente de novo.' });
        return;
      }
      const produto = snap.data();
      const estoque = produto.estoque ?? 0;
      if (estoque < quantidade) {
        res.status(400).json({ error: `"${produto.nome}" só tem ${estoque} em estoque no momento.` });
        return;
      }
      const valorUnitario = precoEfetivoProduto(produto);
      itensValidados.push({ produtoId: it.produtoId, nome: produto.nome, quantidade, valorUnitario });
      valorTotal += valorUnitario * quantidade;
    }

    valorTotal = Number(valorTotal.toFixed(2));

    // ✅ EXTRAI OS IDs DOS PRODUTOS PARA CONSULTA REVERSA
    const produtoIds = itensValidados.map(i => i.produtoId);

    // Entrega passa por uma etapa extra: o frete é combinado com o
    // vendedor DEPOIS do pedido criado (não dá pra gerar PIX com um
    // valor que ainda não foi definido). Retirada pula direto pra
    // aguardando_pagamento, como sempre.
    const precisaFrete = comprador.tipoEntrega === 'entrega';

    const pedidoRef = db.collection('pedidos').doc();
    await pedidoRef.set({
      compradorUid: decoded.uid,
      comprador: {
        nome: String(comprador.nome).slice(0, 100),
        telefone: String(comprador.telefone).replace(/\D/g, '').slice(0, 15),
        tipoEntrega: comprador.tipoEntrega,
        endereco: comprador.tipoEntrega === 'entrega' ? String(comprador.endereco || '').slice(0, 300) : null,
      },
      itens: itensValidados,
      produtoIds,  // ← NOVO CAMPO
      subtotalItens: valorTotal,
      frete: precisaFrete ? null : 0,
      valorTotal,
      status: precisaFrete ? 'aguardando_frete' : 'aguardando_pagamento',
      fcmToken: fcmToken || null,
      criadoEm: admin.firestore.FieldValue.serverTimestamp(),
    });

    res.status(200).json({ ok: true, id: pedidoRef.id, valorTotal, itens: itensValidados, aguardandoFrete: precisaFrete });
  } catch (err) {
    const status = err.status || 500;
    if (status >= 500) console.error('Erro em /api/criar-pedido:', err);
    res.status(status).json({ error: status >= 500 ? 'Erro ao criar o pedido. Tente novamente em instantes.' : err.message });
  }
};