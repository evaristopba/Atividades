// ============================================================================
// js/pix.js
// ============================================================================
// Gera o payload "Pix Copia e Cola" (padrão BR Code / EMV QR Code do Banco
// Central) inteiramente no navegador — sem chamar nenhuma API externa, sem
// gateway de pagamento, sem custo. A confirmação de que o pagamento caiu
// continua sendo manual (o admin marca a parcela como paga depois de
// conferir no aplicativo do banco) — isso é intencional, ver README.
// ============================================================================

function removerAcentosEMaiusculas(str, max) {
  const semAcento = (str || '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .toUpperCase()
    .replace(/[^A-Z0-9 ]/g, '');
  return semAcento.slice(0, max).trim() || '';
}

function campoEMV(id, valor) {
  const tamanho = String(valor.length).padStart(2, '0');
  return `${id}${tamanho}${valor}`;
}

// CRC-16/CCITT-FALSE (polinômio 0x1021, valor inicial 0xFFFF) — é o
// checksum exigido no final do payload do Pix.
function crc16(payload) {
  let crc = 0xFFFF;
  for (let i = 0; i < payload.length; i++) {
    crc ^= payload.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) {
      crc = (crc & 0x8000) ? ((crc << 1) ^ 0x1021) & 0xFFFF : (crc << 1) & 0xFFFF;
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, '0');
}

/**
 * Monta o payload Pix Copia e Cola.
 * @param {Object} p
 * @param {string} p.chave - chave Pix (CPF/CNPJ, e-mail, telefone ou chave aleatória)
 * @param {string} p.nomeRecebedor - nome do recebedor (máx. 25 caracteres úteis)
 * @param {string} p.cidadeRecebedor - cidade do recebedor (máx. 15 caracteres úteis)
 * @param {number} [p.valor] - valor da cobrança; se omitido, o pagador digita o valor no banco
 * @param {string} [p.identificador] - identificador da cobrança (txid), até 25 caracteres
 */
export function gerarPayloadPix({ chave, nomeRecebedor, cidadeRecebedor, valor, identificador }) {
  if (!chave || !chave.trim()) {
    throw new Error('Chave PIX não configurada. Cadastre em Configurações antes de gerar uma cobrança.');
  }

  const nome = removerAcentosEMaiusculas(nomeRecebedor, 25) || 'LOJA';
  const cidade = removerAcentosEMaiusculas(cidadeRecebedor, 15) || 'BRASIL';
  const txid = removerAcentosEMaiusculas(identificador, 25) || '***';

  const merchantAccountInfo =
    campoEMV('00', 'br.gov.bcb.pix') +
    campoEMV('01', chave.trim());

  let payload =
    campoEMV('00', '01') +                       // Payload Format Indicator
    campoEMV('26', merchantAccountInfo) +         // Merchant Account Info (Pix)
    campoEMV('52', '0000') +                      // Merchant Category Code
    campoEMV('53', '986');                        // Moeda: Real (BRL)

  if (valor && Number(valor) > 0) {
    payload += campoEMV('54', Number(valor).toFixed(2)); // Valor (opcional)
  }

  payload +=
    campoEMV('58', 'BR') +                        // País
    campoEMV('59', nome) +                        // Nome do recebedor
    campoEMV('60', cidade) +                      // Cidade do recebedor
    campoEMV('62', campoEMV('05', txid));          // Identificador da cobrança

  payload += '6304'; // ID + tamanho do campo do CRC (valor calculado a seguir)
  return payload + crc16(payload);
}
