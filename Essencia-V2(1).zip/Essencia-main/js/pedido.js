import { db, doc, getDoc, updateDoc, serverTimestamp, messaging, getToken } from './firebase-config.js';
import { gerarPayloadPix } from './pix.js';
import { aoMudarAuthCliente, usuarioAtual, carregarMeusPedidos, carregarPerfilCliente, salvarEndereco, montarFormularioEndereco, formatarEndereco, abrirModalLoginCliente, confirmarAcaoPublica } from './conta-cliente.js';
import { escapeHtml, isDataUriComprovanteValida } from './seguranca.js';

const root = document.getElementById('pedidoConteudo');
const VAPID_KEY = 'BHf5W_1xv23Me-Fv-ebUbNXLQZ6It071U0KxPYrL3RwXc9wQX23yDPC80InpPK6jlbjv3wPtZNxz13U3KSfGCBs';
const PRAZO_PAGAMENTO_HORAS = 24;

function formatBRL(value) {
  return Number(value || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function mostrarToast(msg, erro = false) {
  const el = document.createElement('div');
  el.className = 'toast' + (erro ? ' error' : '');
  el.innerHTML = `<span class="dot"></span>${msg}`;
  document.body.appendChild(el);
  requestAnimationFrame(() => el.classList.add('show'));
  setTimeout(() => { el.classList.remove('show'); setTimeout(() => el.remove(), 300); }, 3200);
}

const ETAPAS = [
  { chave: 'aguardando_frete', label: 'Aguardando frete' },
  { chave: 'aguardando_pagamento', label: 'Aguardando pagamento' },
  { chave: 'pago', label: 'Pagamento confirmado' },
  { chave: 'despachado', label: 'A caminho' },
  { chave: 'entregue', label: 'Entregue' },
];

const COMPROVANTE_LADO_MAX = 900;
const COMPROVANTE_QUALIDADE = 0.8;
const COMPROVANTE_TAMANHO_MAX_BYTES = 850000;

function comprimirImagem(file) {
  return new Promise((resolve, reject) => {
    const leitor = new FileReader();
    leitor.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;
        if (width > height && width > COMPROVANTE_LADO_MAX) {
          height = Math.round(height * (COMPROVANTE_LADO_MAX / width));
          width = COMPROVANTE_LADO_MAX;
        } else if (height > COMPROVANTE_LADO_MAX) {
          width = Math.round(width * (COMPROVANTE_LADO_MAX / height));
          height = COMPROVANTE_LADO_MAX;
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        canvas.getContext('2d').drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', COMPROVANTE_QUALIDADE));
      };
      img.onerror = () => reject(new Error('Não foi possível ler a imagem.'));
      img.src = e.target.result;
    };
    leitor.onerror = () => reject(new Error('Não foi possível ler o arquivo.'));
    leitor.readAsDataURL(file);
  });
}

function lerPdfComoBase64(file) {
  return new Promise((resolve, reject) => {
    const leitor = new FileReader();
    leitor.onload = (e) => resolve(e.target.result);
    leitor.onerror = () => reject(new Error('Não foi possível ler o arquivo.'));
    leitor.readAsDataURL(file);
  });
}

async function lerArquivoComprovante(file) {
  if (file.type === 'application/pdf') {
    const base64 = await lerPdfComoBase64(file);
    if (base64.length > COMPROVANTE_TAMANHO_MAX_BYTES) {
      throw new Error('Esse PDF é grande demais. Tente exportar/salvar com menor qualidade, ou envie um print (imagem) do comprovante em vez do PDF.');
    }
    return base64;
  }
  return comprimirImagem(file);
}

function renderPreviewComprovante(base64) {
  // Antes de usar o valor como src/href, confirma que é mesmo um data-URI
  // de imagem/PDF (mesma checagem das regras do Firestore). Isso é
  // defesa em profundidade: mesmo que algo grave um valor fora do formato
  // esperado no campo comprovanteUrl, ele nunca vira HTML/JS executado aqui.
  if (!isDataUriComprovanteValida(base64)) {
    return `<p class="hint" style="color:var(--danger);">⚠️ Não foi possível exibir este comprovante (formato inesperado).</p>`;
  }
  if (base64.startsWith('data:application/pdf')) {
    return `
      <div style="display:flex;align-items:center;gap:10px;justify-content:center;padding:10px 4px;">
        <span style="font-size:26px;">📄</span>
        <a href="${base64}" target="_blank" rel="noopener" data-abrir-comprovante="1" style="font-size:13px;">Abrir comprovante (PDF)</a>
      </div>`;
  }
  return `<img src="${base64}">`;
}

function renderTimeline(status, tipoEntrega) {
  if (status === 'cancelado') {
    return `<div class="badge badge-out" style="font-size:13px;padding:8px 16px;">Pedido cancelado</div>`;
  }
  const etapas = tipoEntrega === 'entrega' ? ETAPAS : ETAPAS.filter(e => e.chave !== 'aguardando_frete');
  const idxAtual = etapas.findIndex(e => e.chave === status);
  return `
    <div class="pedido-timeline">
      ${etapas.map((e, i) => `
        <div class="pedido-etapa ${i <= idxAtual ? 'feita' : ''} ${i === idxAtual ? 'atual' : ''}">
          <div class="pedido-etapa-ponto"></div>
          <div class="pedido-etapa-label">${e.label}</div>
        </div>
      `).join('')}
    </div>`;
}

async function renderListaPedidos() {
  const user = usuarioAtual();

  if (!user) {
    root.innerHTML = `
      <h1 style="font-family:var(--font-display);font-size:32px;margin-bottom:8px;">Meus pedidos</h1>
      <p style="color:var(--muted);margin-bottom:24px;">Entre na sua conta pra ver todos os seus pedidos automaticamente.</p>
      <button type="button" class="btn btn-gold" id="btnEntrarPedidos" style="margin-bottom:28px;">Entrar / Criar conta</button>
      <div class="divider"><span class="diamond">◆</span></div>
      <div class="field">
        <label>Ou cole o link de um pedido específico</label>
        <div style="display:flex;gap:10px;">
          <input type="text" id="buscaPedidoInput" placeholder="Cole aqui o link recebido na confirmação">
          <button type="button" class="btn btn-ghost" id="buscaPedidoBtn">Ver</button>
        </div>
      </div>
    `;
    document.getElementById('btnEntrarPedidos').addEventListener('click', () => {
      abrirModalLoginCliente({
        mensagem: 'Entre pra ver todos os seus pedidos automaticamente.',
        aoAutenticar: () => renderListaPedidos(),
      });
    });
    wireBuscaPedido();
    return;
  }

  root.innerHTML = `
    <h1 style="font-family:var(--font-display);font-size:32px;margin-bottom:8px;">Meus pedidos</h1>
    <p style="color:var(--muted);margin-bottom:28px;">${user.email || ''}</p>
    <div id="listaPedidosReal"><div class="loading-row"><div class="spinner" style="margin:0 auto;"></div></div></div>
    <div class="divider"><span class="diamond">◆</span></div>
    <div class="field">
      <label>Tem o link de um pedido específico? Cole aqui</label>
      <div style="display:flex;gap:10px;">
        <input type="text" id="buscaPedidoInput" placeholder="Cole aqui o link">
        <button type="button" class="btn btn-ghost" id="buscaPedidoBtn">Ver</button>
      </div>
    </div>
  `;
  wireBuscaPedido();

  const pedidos = await carregarMeusPedidos(user.uid);
  const wrap = document.getElementById('listaPedidosReal');
  if (!pedidos.length) {
    wrap.innerHTML = `<p class="cell-muted">Você ainda não fez nenhum pedido.</p>`;
    return;
  }
  wrap.innerHTML = pedidos.map(p => `
    <a href="pedido.html?id=${p.id}" class="product-card" style="display:block;padding:16px 18px;margin-bottom:10px;text-decoration:none;">
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <div>
          <div style="color:var(--ivory);font-family:var(--font-display);font-size:18px;">${formatBRL(p.valorTotal)}</div>
          <div class="cell-muted" style="font-size:12px;">${(p.itens || []).length} item(ns)</div>
        </div>
        <span class="badge ${p.status === 'cancelado' ? 'badge-out' : p.status === 'entregue' ? 'badge-ok' : ''}">${ETAPAS.find(e => e.chave === p.status)?.label || p.status}</span>
      </div>
    </a>
  `).join('');
}

function wireBuscaPedido() {
  document.getElementById('buscaPedidoBtn').addEventListener('click', () => {
    const valor = document.getElementById('buscaPedidoInput').value.trim();
    const idMatch = valor.match(/id=([A-Za-z0-9]+)/);
    const id = idMatch ? idMatch[1] : valor;
    if (!id) { mostrarToast('Cole o link ou código do pedido.', true); return; }
    window.location.href = `pedido.html?id=${id}`;
  });
}

async function renderPedido(id) {
  let snap;
  try {
    snap = await getDoc(doc(db, 'pedidos', id));
  } catch (err) {
    root.innerHTML = `<div class="empty-state"><div class="diamond">◆</div><h3>Não foi possível carregar esse pedido</h3><p>Confira se o link está completo e correto.</p></div>`;
    return;
  }
  if (!snap.exists()) {
    root.innerHTML = `<div class="empty-state"><div class="diamond">◆</div><h3>Pedido não encontrado</h3><p>Confira se o link está completo e correto.</p></div>`;
    return;
  }
  const p = snap.data();

  if (['aguardando_frete', 'aguardando_pagamento'].includes(p.status) && p.criadoEm?.toDate) {
    const prazoMs = PRAZO_PAGAMENTO_HORAS * 60 * 60 * 1000;
    if (Date.now() - p.criadoEm.toDate().getTime() > prazoMs) {
      try {
        await updateDoc(doc(db, 'pedidos', id), { status: 'cancelado', canceladoEm: serverTimestamp(), canceladoPor: 'expiracao_automatica' });
        p.status = 'cancelado';
      } catch (err) { console.warn('Não foi possível expirar automaticamente:', err.message); }
    }
  }

  const itensHtml = (p.itens || []).map(i => `
    <div class="price-row" style="margin-top:8px;">
      <span class="label">${i.quantidade}× ${escapeHtml(i.nome)}</span>
      <span class="value">${formatBRL(i.quantidade * i.valorUnitario)}</span>
    </div>`).join('');

  let pixHtml = '';
  let prazoHtml = '';

  if (p.status === 'aguardando_frete') {
    if (p.criadoEm?.toDate) {
      const prazoDate = new Date(p.criadoEm.toDate().getTime() + PRAZO_PAGAMENTO_HORAS * 60 * 60 * 1000);
      prazoHtml = `<p style="font-size:12px;color:var(--muted-2);margin-top:10px;">Se a loja não definir o frete até ${prazoDate.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}, o pedido é cancelado automaticamente.</p>`;
    }
    pixHtml = `
      <div class="divider"><span class="diamond">◆</span></div>
      <h3 style="font-size:18px;margin-bottom:8px;">Aguardando o valor do frete</h3>
      <p style="font-size:13px;color:var(--muted);">A loja está combinando o valor da entrega — assim que estiver definido, o pagamento (PIX) é liberado aqui e você é avisado.</p>
      ${prazoHtml}
    `;
  } else if (p.status === 'aguardando_pagamento') {
    if (p.criadoEm?.toDate) {
      const prazoDate = new Date(p.criadoEm.toDate().getTime() + PRAZO_PAGAMENTO_HORAS * 60 * 60 * 1000);
      const faltamMs = prazoDate.getTime() - Date.now();
      const faltamHoras = Math.max(0, Math.floor(faltamMs / (60 * 60 * 1000)));
      const faltamMin = Math.max(0, Math.floor((faltamMs % (60 * 60 * 1000)) / (60 * 1000)));
      prazoHtml = `
        <p style="font-size:13px;color:var(--gold);margin-top:4px;">
          ⏱ Pague em até ${faltamHoras}h${String(faltamMin).padStart(2, '0')} (prazo: ${prazoDate.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}) ou o pedido é cancelado automaticamente.
        </p>`;
    }
    try {
      const configSnap = await getDoc(doc(db, 'configuracoes', 'geral'));
      const config = configSnap.exists() ? configSnap.data() : {};
      if (config.pixChave) {
        const payload = gerarPayloadPix({
          chave: config.pixChave,
          nomeRecebedor: config.pixNome,
          cidadeRecebedor: config.pixCidade,
          valor: p.valorTotal,
          identificador: `PEDIDO${id.slice(0, 10).toUpperCase()}`,
        });
        pixHtml = `
          <div class="divider"><span class="diamond">◆</span></div>
          <h3 style="font-size:18px;margin-bottom:14px;">Pagar via PIX</h3>
          ${prazoHtml}
          <div id="pixQrPedido" style="display:flex;justify-content:center;margin:14px 0;"></div>
          <textarea readonly rows="3" id="pixCopiaColaPedido" style="width:100%;font-family:var(--font-mono);font-size:11px;resize:none;">${payload}</textarea>
          <button type="button" class="btn btn-gold" id="copiarPixPedidoBtn" style="width:100%;justify-content:center;margin-top:10px;">Copiar código PIX</button>
          <p style="font-size:12px;color:var(--muted-2);margin-top:10px;">Depois de pagar, a loja confirma manualmente — o status muda pra "Pagamento confirmado" assim que verificado.</p>
        `;
      } else {
        pixHtml = `<div class="divider"><span class="diamond">◆</span></div>${prazoHtml}`;
      }
    } catch (e) { pixHtml = `<div class="divider"><span class="diamond">◆</span></div>${prazoHtml}`; }
  }

  const comprovanteHtml = p.status === 'aguardando_pagamento' ? `
    <div class="divider"><span class="diamond">◆</span></div>
    <h3 style="font-size:18px;margin-bottom:8px;">Comprovante de pagamento</h3>
    <p style="font-size:13px;color:var(--muted);margin-bottom:14px;">
      ${p.comprovanteUrl ? 'Comprovante enviado — a loja vai conferir e confirmar seu pagamento.' : 'Opcional, mas ajuda a agilizar a confirmação. Envie um print, foto ou PDF do comprovante do PIX.'}
    </p>
    <label class="photo-upload" id="comprovanteUploadWrap">
      <div id="comprovanteConteudo">
        ${p.comprovanteUrl
          ? `${renderPreviewComprovante(p.comprovanteUrl)}<div class="hint">Clique para trocar o comprovante</div>`
          : `<div class="hint">Clique para enviar o comprovante (print, foto ou PDF)</div>`}
      </div>
      <input type="file" id="comprovanteInput" accept="image/*,application/pdf" style="display:none;">
    </label>
  ` : '';

  const cancelamentoHtml = renderBlocoCancelamento(p);
  const mostrarBreakdownFrete = p.comprador?.tipoEntrega === 'entrega';
  const breakdownFreteHtml = mostrarBreakdownFrete ? `
    <div class="price-row" style="margin-top:8px;"><span class="label">Subtotal itens</span><span class="value">${formatBRL(p.subtotalItens ?? p.valorTotal)}</span></div>
    <div class="price-row" style="margin-top:4px;"><span class="label">Frete</span><span class="value">${p.frete === null || p.frete === undefined ? 'A combinar' : formatBRL(p.frete)}</span></div>
  ` : '';

  root.innerHTML = `
    <h1 style="font-family:var(--font-display);font-size:32px;margin-bottom:20px;">Seu pedido</h1>
    ${p.status === 'aguardando_frete' ? '<p class="cell-muted" style="margin-bottom:12px;font-size:13px;">Assim que o frete for definido, seu pedido segue o fluxo normal de pagamento e entrega.</p>' : ''}
    ${renderTimeline(p.status, p.comprador?.tipoEntrega)}
    <div class="divider"><span class="diamond">◆</span></div>

    <h3 style="font-size:16px;margin-bottom:6px;">Itens</h3>
    ${itensHtml}
    ${breakdownFreteHtml}
    <div class="price-row avista" style="margin-top:14px;padding-top:14px;border-top:1px solid var(--border-soft);">
      <span class="label">Total</span><span class="value">${formatBRL(p.valorTotal)}</span>
    </div>

    <div class="divider"><span class="diamond">◆</span></div>
    <h3 style="font-size:16px;margin-bottom:6px;">${p.comprador?.tipoEntrega === 'entrega' ? 'Entrega' : 'Retirada'}</h3>
    <p class="cell-muted">${p.comprador?.tipoEntrega === 'entrega' ? escapeHtml(p.comprador?.endereco || '—') : 'Retirar na loja'}</p>
    <div id="trocarEnderecoWrap"></div>

    ${pixHtml}
    ${comprovanteHtml}
    ${cancelamentoHtml}

    <div class="divider"><span class="diamond">◆</span></div>
    <div id="notifWrap"></div>
  `;

  if (pixHtml) {
    const payloadEl = document.getElementById('pixCopiaColaPedido');
    if (window.QRCode && payloadEl) {
      new QRCode(document.getElementById('pixQrPedido'), { text: payloadEl.value, width: 200, height: 200, colorDark: '#14100f', colorLight: '#f4ece3' });
    }
    const btnCopiar = document.getElementById('copiarPixPedidoBtn');
    if (btnCopiar) {
      btnCopiar.addEventListener('click', () => {
        navigator.clipboard.writeText(payloadEl.value).then(() => mostrarToast('Código PIX copiado.'));
      });
    }
  }

  const comprovanteInput = document.getElementById('comprovanteInput');
  const conteudoComprovante = document.getElementById('comprovanteConteudo');
  if (conteudoComprovante) {
    conteudoComprovante.addEventListener('click', (e) => {
      const linkPdf = e.target.closest('[data-abrir-comprovante]');
      if (e.target.tagName === 'IMG') { e.preventDefault(); window.open(e.target.src, '_blank'); }
      else if (linkPdf) { e.preventDefault(); e.stopPropagation(); window.open(linkPdf.href, '_blank'); }
    });
  }
  if (comprovanteInput) {
    comprovanteInput.addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const conteudo = document.getElementById('comprovanteConteudo');
      conteudo.innerHTML = `<div class="hint">Enviando comprovante...</div>`;
      try {
        const base64 = await lerArquivoComprovante(file);
        await updateDoc(doc(db, 'pedidos', id), { comprovanteUrl: base64 });
        conteudo.innerHTML = `${renderPreviewComprovante(base64)}<div class="hint">Comprovante enviado — clique para trocar</div>`;
        mostrarToast('Comprovante enviado! A loja vai conferir e confirmar seu pagamento.');
      } catch (err) {
        console.error(err);
        conteudo.innerHTML = `<div class="hint" style="color:var(--danger);">${err.message || 'Não foi possível enviar. Tente um arquivo menor.'}</div>`;
        mostrarToast('Erro ao enviar o comprovante.', true);
      }
    });
  }

  const btnCancelar = document.getElementById('btnCancelarPedido');
  if (btnCancelar) {
    btnCancelar.addEventListener('click', () => {
      confirmarAcaoPublica({
        titulo: 'Cancelar pedido?',
        mensagem: 'Não é possível desfazer essa ação.',
        textoBotao: 'Cancelar pedido',
        aoConfirmar: async () => {
          await updateDoc(doc(db, 'pedidos', id), { status: 'cancelado', canceladoEm: serverTimestamp(), canceladoPor: 'cliente' });
          mostrarToast('Pedido cancelado.');
          renderPedido(id);
        },
      });
    });
  }
  const btnSolicitar = document.getElementById('btnSolicitarCancelamento');
  if (btnSolicitar) {
    btnSolicitar.addEventListener('click', () => abrirFormSolicitarCancelamento(id));
  }

  renderTrocaEndereco(p, id);
  renderBotaoNotificacao(id, p.fcmToken);
}

function renderTrocaEndereco(p, id) {
  const wrap = document.getElementById('trocarEnderecoWrap');
  if (!wrap) return;

  const usuario = usuarioAtual();
  const souDono = usuario && usuario.uid === p.compradorUid;
  const pagamentoJaEnviado = !!p.comprovanteUrl;
  const podeEditar = souDono && !pagamentoJaEnviado && p.comprador?.tipoEntrega === 'entrega' &&
    ['aguardando_frete', 'aguardando_pagamento'].includes(p.status);

  if (podeEditar) {
    wrap.innerHTML = `<button type="button" class="btn btn-ghost btn-sm" id="btnTrocarEndereco" style="margin-top:8px;">Trocar endereço</button>`;
    document.getElementById('btnTrocarEndereco').addEventListener('click', async () => {
      const perfil = (await carregarPerfilCliente(usuario.uid)) || { enderecos: [] };
      abrirSeletorEnderecoPedido(p, id, perfil);
    });
    return;
  }

  // Explica por que a troca não está mais disponível, em vez de simplesmente
  // esconder o botão sem dizer nada — o comprovante já foi enviado, então
  // trocar o endereço agora poderia mudar o frete sem ajuste do valor pago.
  wrap.innerHTML = (souDono && pagamentoJaEnviado && p.comprador?.tipoEntrega === 'entrega' &&
    ['aguardando_frete', 'aguardando_pagamento'].includes(p.status))
    ? `<p class="cell-muted" style="font-size:12px;margin-top:8px;">Endereço não pode mais ser alterado — comprovante já enviado. Se precisar mudar, fale com a loja.</p>`
    : '';
}

function abrirSeletorEnderecoPedido(p, id, perfil) {
  const enderecos = perfil.enderecos || [];
  let mostrandoNovo = enderecos.length === 0;

  root.insertAdjacentHTML('beforeend', `
    <div class="modal-overlay" id="trocaEnderecoOverlay">
      <div class="modal" style="max-width:440px;">
        <div class="modal-form">
          <button class="modal-close" id="closeTrocaEndereco">✕</button>
          <h2 style="font-size:22px;margin-bottom:6px;">Trocar endereço</h2>
          ${p.status === 'aguardando_pagamento' ? `<p style="font-size:12px;color:var(--danger);margin-bottom:16px;">O frete já foi cotado pro endereço atual — trocar agora volta o pedido pra "Aguardando frete" pra loja recalcular.</p>` : '<div style="margin-bottom:16px;"></div>'}
          <div id="trocaEnderecoConteudo"></div>
          <div class="modal-actions">
            <button class="btn btn-ghost" id="cancelarTrocaEndereco">Cancelar</button>
            <button class="btn btn-gold" id="confirmarTrocaEndereco">Confirmar</button>
          </div>
        </div>
      </div>
    </div>`);

  const overlay = document.getElementById('trocaEnderecoOverlay');
  document.getElementById('closeTrocaEndereco').addEventListener('click', () => overlay.remove());
  document.getElementById('cancelarTrocaEndereco').addEventListener('click', () => overlay.remove());

  let formNovoEndereco = null;

  function renderConteudo() {
    const conteudo = document.getElementById('trocaEnderecoConteudo');
    if (mostrandoNovo || enderecos.length === 0) {
      conteudo.innerHTML = `
        <div id="trocaFormEnderecoEstruturado"></div>
        <label style="display:flex;align-items:center;gap:8px;margin-top:8px;font-size:12px;">
          <input type="checkbox" id="salvarEnderecoTroca" checked style="width:14px;height:14px;"> Salvar no meu perfil
        </label>
        ${enderecos.length > 0 ? `<button type="button" class="btn btn-ghost btn-sm" id="voltarSalvosTroca" style="margin-top:8px;">← Usar um endereço salvo</button>` : ''}
      `;
      formNovoEndereco = montarFormularioEndereco(document.getElementById('trocaFormEnderecoEstruturado'), {});
      const voltar = document.getElementById('voltarSalvosTroca');
      if (voltar) voltar.addEventListener('click', () => { mostrandoNovo = false; formNovoEndereco = null; renderConteudo(); });
    } else {
      formNovoEndereco = null;
      const enderecoAtualBate = enderecos.some(e => e.endereco === p.comprador?.endereco);
      conteudo.innerHTML = enderecos.map(e => {
        const marcado = enderecoAtualBate ? e.endereco === p.comprador?.endereco : e.principal;
        return `
        <label style="display:flex;gap:10px;align-items:flex-start;padding:10px;border:1px solid var(--border);border-radius:var(--radius);margin-bottom:8px;cursor:pointer;">
          <input type="radio" name="enderecoTrocaRadio" value="${e.id}" ${marcado ? 'checked' : ''} style="margin-top:3px;">
          <div>
            <strong style="font-size:13px;color:var(--ivory);">${e.label || 'Endereço'}</strong>
            ${e.principal ? ' <span class="cell-muted">(principal)</span>' : ''}
            <div class="cell-muted" style="font-size:12px;">${e.endereco}</div>
          </div>
        </label>`;
      }).join('') + `<button type="button" class="btn btn-ghost btn-sm" id="novoEnderecoTrocaBtn">+ Usar um novo endereço</button>`;
      document.getElementById('novoEnderecoTrocaBtn').addEventListener('click', () => { mostrandoNovo = true; renderConteudo(); });
    }
  }
  renderConteudo();

  document.getElementById('confirmarTrocaEndereco').addEventListener('click', async () => {
    const btn = document.getElementById('confirmarTrocaEndereco');
    let novoEndereco = '';

    const radioMarcado = overlay.querySelector('input[name="enderecoTrocaRadio"]:checked');
    if (radioMarcado && !mostrandoNovo) {
      novoEndereco = enderecos.find(e => e.id === radioMarcado.value)?.endereco || '';
    } else if (formNovoEndereco) {
      const erro = formNovoEndereco.validar();
      if (erro) { mostrarToast(erro, true); return; }
      const dados = formNovoEndereco.ler();
      novoEndereco = formatarEndereco(dados);
      const salvar = document.getElementById('salvarEnderecoTroca')?.checked;
      if (salvar) {
        try { await salvarEndereco(usuarioAtual().uid, perfil.enderecos, dados); }
        catch (err) { console.warn('Não foi possível salvar o endereço:', err.message); }
      }
    }

    if (!novoEndereco) { mostrarToast('Escolha ou informe um endereço.', true); return; }

    btn.disabled = true;
    btn.textContent = 'Salvando...';
    try {
      const dados = { comprador: { ...p.comprador, endereco: novoEndereco } };
      if (p.status === 'aguardando_pagamento') {
        dados.status = 'aguardando_frete';
        dados.frete = null;
        dados.valorTotal = p.subtotalItens ?? p.valorTotal;
      }
      await updateDoc(doc(db, 'pedidos', id), dados);
      overlay.remove();
      mostrarToast(p.status === 'aguardando_pagamento' ? 'Endereço atualizado — a loja vai recalcular o frete.' : 'Endereço atualizado.');
      renderPedido(id);
    } catch (err) {
      console.error(err);
      mostrarToast('Não foi possível atualizar o endereço.', true);
      btn.disabled = false;
      btn.textContent = 'Confirmar';
    }
  });
}

function renderBlocoCancelamento(p) {
  const pagamentoJaEnviado = !!p.comprovanteUrl;

  // Comprovante já enviado, mas admin ainda não confirmou o pagamento
  // (status ainda 'aguardando_frete'/'aguardando_pagamento'): nem o
  // autocancelamento (bloqueado na regra assim que há comprovante) nem o
  // "solicitar cancelamento" (que só existe depois de status == 'pago')
  // se aplicam aqui — é uma janela intermediária que precisa de contato
  // direto com a loja, em vez de mostrar um botão que a regra recusaria.
  if (pagamentoJaEnviado && (p.status === 'aguardando_frete' || p.status === 'aguardando_pagamento')) {
    return `
      <div class="divider"><span class="diamond">◆</span></div>
      <p class="cell-muted" style="font-size:13px;">Comprovante enviado — aguardando a loja confirmar o pagamento. Para cancelar agora, fale diretamente com a loja.</p>`;
  }

  // Cliente pode cancelar ANTES de pagar
  if (p.status === 'aguardando_frete' || p.status === 'aguardando_pagamento') {
    return `
      <div style="margin-top:18px;">
        <button type="button" class="btn btn-ghost" id="btnCancelarPedido" style="color:var(--danger);">Cancelar meu pedido</button>
      </div>`;
  }

  // Se já foi despachado ou entregue, NÃO pode solicitar cancelamento
  if (p.status === 'despachado' || p.status === 'entregue') {
    return `
      <div class="divider"><span class="diamond">◆</span></div>
      <p class="cell-muted" style="font-size:13px;">Pedido já foi despachado. Entre em contato com a loja para mais informações.</p>`;
  }

  // Se está pago (mas ainda não despachado), pode solicitar cancelamento
  if (p.status === 'pago') {
    if (p.cancelamentoSolicitado) {
      return `
        <div class="divider"><span class="diamond">◆</span></div>
        <p class="cell-muted" style="font-size:13px;">Cancelamento solicitado — a loja vai entrar em contato para combinar o reembolso.</p>`;
    }
    return `
      <div class="divider"><span class="diamond">◆</span></div>
      <button type="button" class="btn btn-ghost" id="btnSolicitarCancelamento" style="color:var(--danger);">Solicitar cancelamento</button>
      <p style="font-size:11px;color:var(--muted-2);margin-top:8px;">Como o pagamento já foi confirmado, o cancelamento passa por uma revisão da loja (o reembolso é feito manualmente).</p>`;
  }

  return '';
}

function abrirFormSolicitarCancelamento(id) {
  root.insertAdjacentHTML('beforeend', `
    <div class="modal-overlay" id="cancelReqOverlay">
      <div class="modal" style="max-width:420px;">
        <div class="modal-form">
          <h2 style="font-size:22px;">Solicitar cancelamento</h2>
          <p style="margin:10px 0 14px;font-size:13px;color:var(--muted);">Conte rapidamente o motivo (opcional) — ajuda a loja a agilizar.</p>
          <textarea id="motivoCancelamentoInput" rows="3" placeholder="Ex: pedi por engano, mudei de ideia..."></textarea>
          <div class="modal-actions">
            <button class="btn btn-ghost" id="cancelReqFechar">Voltar</button>
            <button class="btn btn-danger" id="cancelReqEnviar">Enviar solicitação</button>
          </div>
        </div>
      </div>
    </div>`);
  const overlay = document.getElementById('cancelReqOverlay');
  document.getElementById('cancelReqFechar').addEventListener('click', () => overlay.remove());
  document.getElementById('cancelReqEnviar').addEventListener('click', async () => {
    const btn = document.getElementById('cancelReqEnviar');
    btn.disabled = true;
    btn.textContent = 'Enviando...';
    try {
      await updateDoc(doc(db, 'pedidos', id), {
        cancelamentoSolicitado: true,
        motivoCancelamento: document.getElementById('motivoCancelamentoInput').value.trim().slice(0, 300),
      });
      overlay.remove();
      mostrarToast('Solicitação enviada — a loja vai entrar em contato.');
      renderPedido(id);
    } catch (err) {
      console.error(err);
      mostrarToast('Não foi possível enviar. Tente de novo.', true);
      btn.disabled = false;
      btn.textContent = 'Enviar solicitação';
    }
  });
}

function renderBotaoNotificacao(pedidoId, tokenJaSalvo) {
  const wrap = document.getElementById('notifWrap');
  if (!wrap) return;

  if (!messaging || !('Notification' in window)) {
    wrap.innerHTML = '';
    return;
  }
  if (tokenJaSalvo) {
    wrap.innerHTML = `<p class="cell-muted" style="font-size:13px;">🔔 Notificações ativadas para este pedido.</p>`;
    return;
  }
  if (Notification.permission === 'denied') {
    wrap.innerHTML = `<p class="cell-muted" style="font-size:13px;">Notificações bloqueadas no navegador. Para ativar, mude a permissão do site nas configurações do navegador.</p>`;
    return;
  }

  wrap.innerHTML = `<button type="button" class="btn btn-ghost" id="ativarNotifBtn">🔔 Avisar quando o status mudar</button>`;
  document.getElementById('ativarNotifBtn').addEventListener('click', async () => {
    const btn = document.getElementById('ativarNotifBtn');
    btn.disabled = true;
    btn.textContent = 'Ativando...';
    try {
      const permissao = await Notification.requestPermission();
      if (permissao !== 'granted') {
        wrap.innerHTML = `<p class="cell-muted" style="font-size:13px;">Sem problema — você ainda pode voltar nesta página quando quiser conferir o status.</p>`;
        return;
      }
      const token = await getToken(messaging, { vapidKey: VAPID_KEY, serviceWorkerRegistration: await navigator.serviceWorker.ready });
      if (token) {
        await updateDoc(doc(db, 'pedidos', pedidoId), { fcmToken: token });
        wrap.innerHTML = `<p class="cell-muted" style="font-size:13px;">🔔 Notificações ativadas para este pedido.</p>`;
      }
    } catch (err) {
      console.error(err);
      mostrarToast('Não foi possível ativar as notificações agora.', true);
      btn.disabled = false;
      btn.textContent = '🔔 Avisar quando o status mudar';
    }
  });
}

const params = new URLSearchParams(location.search);
const pedidoId = params.get('id');
if (pedidoId) {
  renderPedido(pedidoId);
} else {
  aoMudarAuthCliente(() => renderListaPedidos());
}

/* ============================================================================
   TOAST / NOTIFICAÇÃO RÁPIDA (fallback - usado pelo admin.js via showToast)
   ============================================================================ */
function showToast(msg) {
  const root = document.getElementById('toastRoot');
  if (!root) return;
  const el = document.createElement('div');
  el.style.cssText = `
    background: var(--surface); color: var(--text); border: 1px solid var(--border);
    padding: 12px 20px; border-radius: var(--radius); font-size: 13px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.3); margin-bottom: 10px;
    opacity: 0; transform: translateY(10px); transition: all 0.3s ease;
    pointer-events: none; max-width: 320px;
  `;
  el.textContent = msg;
  root.appendChild(el);
  requestAnimationFrame(() => { el.style.opacity = '1'; el.style.transform = 'translateY(0)'; });
  setTimeout(() => {
    el.style.opacity = '0'; el.style.transform = 'translateY(10px)';
    setTimeout(() => el.remove(), 300);
  }, 3000);
}