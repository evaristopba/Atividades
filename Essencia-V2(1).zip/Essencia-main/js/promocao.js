// ============================================================================
// js/promocao.js
// ============================================================================
// Regra única de "o produto está em promoção de verdade?", usada tanto no
// catálogo público quanto no painel admin. O servidor (api/criar-pedido.js)
// aplica a MESMA validação (duplicada ali por ser CommonJS, não ES module —
// mantenha as duas em sincronia se um dia mudar a regra), porque é ele quem
// decide o preço cobrado de verdade; isso aqui é só para exibição.
//
// Um produto só é considerado "em promoção" se TODAS as condições valerem:
//   - emPromocao === true (o admin marcou a caixa)
//   - valorPromocional é um número válido, maior que zero
//   - valorPromocional é menor que valorAVista (nunca "promoção" mais cara)
// Isso evita, por exemplo, mostrar um preço promocional quebrado se o admin
// marcar a caixa e esquecer de preencher o valor.
// ============================================================================

export function precoEfetivo(produto) {
  const precoOriginal = Number(produto?.valorAVista) || 0;
  const promo = Number(produto?.valorPromocional);
  const emPromocao = produto?.emPromocao === true &&
    Number.isFinite(promo) && promo > 0 && promo < precoOriginal;

  return {
    preco: emPromocao ? promo : precoOriginal,
    precoOriginal,
    emPromocao,
    percentualDesconto: emPromocao ? Math.round((1 - promo / precoOriginal) * 100) : 0,
  };
}
