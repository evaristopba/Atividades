import { auth, verifyPasswordResetCode, confirmPasswordReset } from './firebase-config.js';

const conteudo = document.getElementById('redefinirConteudo');

// Pegar os parâmetros da URL (o Firebase adiciona automaticamente)
const params = new URLSearchParams(window.location.search);
const mode = params.get('mode');
const oobCode = params.get('oobCode');

function mostrarToast(msg, erro = false) {
  const el = document.createElement('div');
  el.className = 'toast' + (erro ? ' error' : '');
  el.innerHTML = `<span class="dot"></span>${msg}`;
  document.body.appendChild(el);
  requestAnimationFrame(() => el.classList.add('show'));
  setTimeout(() => { el.classList.remove('show'); setTimeout(() => el.remove(), 300); }, 3200);
}

async function handleRedefinirSenha() {
  // Verifica se o código existe e se é de redefinição de senha
  if (!oobCode || mode !== 'resetPassword') {
    conteudo.innerHTML = `
      <div class="empty-state">
        <div class="diamond">◆</div>
        <h3>Link inválido</h3>
        <p>O link de redefinição de senha é inválido ou expirou.</p>
        <a href="index.html" class="btn btn-gold" style="margin-top:20px;">Voltar ao catálogo</a>
      </div>
    `;
    return;
  }

  try {
    // Verifica se o código é válido e recupera o e-mail
    const email = await verifyPasswordResetCode(auth, oobCode);

    // Exibe o formulário
    conteudo.innerHTML = `
      <h1 style="font-family:var(--font-display);font-size:28px;margin-bottom:6px;">Redefinir senha</h1>
      <p class="cell-muted" style="margin-bottom:24px;">${email}</p>
      <form id="formRedefinirSenha">
        <div class="field">
          <label>Nova senha *</label>
          <input type="password" id="novaSenha" required minlength="6">
        </div>
        <div class="field">
          <label>Confirmar nova senha *</label>
          <input type="password" id="confirmarSenha" required>
        </div>
        <button type="submit" class="btn btn-gold" style="width:100%;justify-content:center;">Redefinir senha</button>
      </form>
    `;

    // Evento do formulário
    document.getElementById('formRedefinirSenha').addEventListener('submit', async (e) => {
      e.preventDefault();
      const novaSenha = document.getElementById('novaSenha').value;
      const confirmar = document.getElementById('confirmarSenha').value;

      if (novaSenha !== confirmar) {
        mostrarToast('As senhas não coincidem.', true);
        return;
      }
      if (novaSenha.length < 6) {
        mostrarToast('A senha precisa ter pelo menos 6 caracteres.', true);
        return;
      }

      const btn = e.target.querySelector('button[type="submit"]');
      btn.disabled = true;
      btn.textContent = 'Alterando...';

      try {
        await confirmPasswordReset(auth, oobCode, novaSenha);
        conteudo.innerHTML = `
          <div class="empty-state">
            <div class="diamond">◆</div>
            <h3>Senha alterada! 🎉</h3>
            <p>Sua senha foi redefinida com sucesso.</p>
            <a href="index.html" class="btn btn-gold" style="margin-top:20px;">Voltar ao catálogo</a>
          </div>
        `;
      } catch (err) {
        console.error('Erro ao redefinir senha:', err);
        mostrarToast('Erro ao redefinir senha. Tente novamente.', true);
        btn.disabled = false;
        btn.textContent = 'Redefinir senha';
      }
    });

  } catch (err) {
    console.error('Erro ao verificar código:', err);
    conteudo.innerHTML = `
      <div class="empty-state">
        <div class="diamond">◆</div>
        <h3>Link inválido ou expirado</h3>
        <p>O link de redefinição de senha não é mais válido. Solicite um novo.</p>
        <a href="index.html" class="btn btn-gold" style="margin-top:20px;">Voltar ao catálogo</a>
      </div>
    `;
  }
}

handleRedefinirSenha();