import { db, collection, getDocs, query, where, doc, getDoc, setDoc, updateDoc, serverTimestamp, messaging, getToken, onMessage } from './firebase-config.js';
import { gerarPayloadPix } from './pix.js';
import { aoMudarAuthCliente, carregarPerfilCliente, salvarPerfilCliente, abrirModalLoginCliente, abrirModalMinhaConta, enderecoPrincipal, salvarEndereco, montarFormularioEndereco, formatarEndereco, confirmarAcaoPublica } from './conta-cliente.js';
import { precoEfetivo } from './promocao.js';

const grid = document.getElementById('catalogGrid');
const searchInput = document.getElementById('searchInput');
const categoryFilter = document.getElementById('categoryFilter');
const sortFilter = document.getElementById('sortFilter');
const modalRoot = document.getElementById('modalRoot');
const whatsappFabRoot = document.getElementById('whatsappFabRoot');
const cartFabRoot = document.getElementById('cartFabRoot');
const contaAreaRoot = document.getElementById('contaAreaRoot');

const ICONE_WHATSAPP = `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.472-.148-.67.15-.198.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/><path d="M12.001 2C6.478 2 2 6.477 2 12c0 1.986.579 3.836 1.578 5.395L2 22l4.735-1.539A9.958 9.958 0 0012.001 22C17.524 22 22 17.523 22 12S17.524 2 12.001 2zm0 18.2a8.169 8.169 0 01-4.166-1.14l-.299-.177-3.104 1.01 1.024-3.028-.194-.31A8.19 8.19 0 013.8 12c0-4.522 3.679-8.2 8.201-8.2 4.521 0 8.2 3.678 8.2 8.2 0 4.522-3.679 8.2-8.2 8.2z"/></svg>`;
const ICONE_SACOLA = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>`;

let allProducts = [];
let allCategories = [];
let configuracoes = { contatos: [], mensagemPadrao: 'Olá! Vim pelo catálogo online e gostaria de mais informações.', pixChave: '', pixNome: '', pixCidade: '' };
let tokenFcmAtual = null;
let clienteAtual = null;
let perfilClienteAtual = null;

function formatBRL(value) {
  const n = Number(value || 0);
  return n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function linkWhatsapp(numero, mensagem) {
  const n = (numero || '').replace(/\D/g, '');
  return `https://wa.me/${n}?text=${encodeURIComponent(mensagem || configuracoes.mensagemPadrao)}`;
}

/* ============================================================================
   CONTA DO CLIENTE
   ============================================================================ */
function renderContaArea() {
  if (!contaAreaRoot) return;
  if (clienteAtual) {
    const rotulo = perfilClienteAtual?.nome || clienteAtual.email || 'Minha conta';
    contaAreaRoot.innerHTML = `<button type="button" class="btn btn-ghost" id="btnMinhaConta">${rotulo}</button>`;
    document.getElementById('btnMinhaConta').addEventListener('click', () => {
      abrirModalMinhaConta({
        aoSalvarPerfil: (dados) => { perfilClienteAtual = { ...perfilClienteAtual, ...dados }; renderContaArea(); mostrarToastPublico('Dados salvos.'); },
        aoAbrirPedidos: () => { window.location.href = 'pedido.html'; },
      });
    });
  } else {
    contaAreaRoot.innerHTML = `<button type="button" class="btn btn-ghost" id="btnEntrarConta">Entrar</button>`;
    document.getElementById('btnEntrarConta').addEventListener('click', () => abrirModalLoginCliente({}));
  }
}

aoMudarAuthCliente(async (user) => {
  clienteAtual = user;
  perfilClienteAtual = user ? await carregarPerfilCliente(user.uid) : null;
  renderContaArea();
});

/* ============================================================================
   CONFIGURAÇÕES
   ============================================================================ */
async function carregarConfiguracoes() {
  try {
    const snap = await getDoc(doc(db, 'configuracoes', 'geral'));
    if (snap.exists()) {
      const data = snap.data();
      if (Array.isArray(data.contatos) && data.contatos.length) configuracoes.contatos = data.contatos;
      if (data.mensagemPadrao) configuracoes.mensagemPadrao = data.mensagemPadrao;
      configuracoes.pixChave = data.pixChave || '';
      configuracoes.pixNome = data.pixNome || '';
      configuracoes.pixCidade = data.pixCidade || '';
    }
  } catch (err) {
    console.error('Erro ao carregar configurações:', err);
  }
  renderWhatsappFab();
}

function renderWhatsappFab() {
  if (!whatsappFabRoot) return;
  const contatos = configuracoes.contatos;

  if (!contatos.length) {
    whatsappFabRoot.innerHTML = '';
    return;
  }

  if (contatos.length === 1) {
    const c = contatos[0];
    whatsappFabRoot.innerHTML = `
      <a href="${linkWhatsapp(c.numero, configuracoes.mensagemPadrao)}" class="whatsapp-fab" target="_blank" rel="noopener">
        ${ICONE_WHATSAPP}<span class="label">Falar no WhatsApp</span>
      </a>`;
    return;
  }

  whatsappFabRoot.innerHTML = `
    <div class="whatsapp-fab-wrap">
      <div class="whatsapp-menu" id="whatsappMenu">
        ${contatos.map(c => `<a href="${linkWhatsapp(c.numero, configuracoes.mensagemPadrao)}" target="_blank" rel="noopener">${c.label}</a>`).join('')}
      </div>
      <button class="whatsapp-fab" id="whatsappToggle" type="button">
        ${ICONE_WHATSAPP}<span class="label">Falar no WhatsApp</span>
      </button>
    </div>`;

  const menu = document.getElementById('whatsappMenu');
  document.getElementById('whatsappToggle').addEventListener('click', () => {
    menu.classList.toggle('open');
  });
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.whatsapp-fab-wrap')) menu.classList.remove('open');
  });
}

/* ============================================================================
   CATEGORIAS PARA O FILTRO
   ============================================================================ */
async function carregarCategorias() {
  try {
    const snap = await getDocs(collection(db, 'categorias'));
    allCategories = snap.docs.map(d => ({ id: d.id, ...d.data() }));
  } catch (err) {
    console.error('Erro ao carregar categorias:', err);
    allCategories = [];
  }
}

function populateCategories() {
  const cats = allCategories.map(c => c.nome).filter(Boolean).sort();
  categoryFilter.innerHTML = '<option value="">Todas as categorias</option>' +
    cats.map(c => `<option value="${c}">${c}</option>`).join('');
}

/* ============================================================================
   PRODUTOS
   ============================================================================ */
async function loadProducts() {
  try {
    const q = query(collection(db, 'produtos'), where('ativo', '==', true));
    const snap = await getDocs(q);
    allProducts = snap.docs.map(d => ({ id: d.id, ...d.data() }));
  } catch (err) {
    console.error('Erro ao carregar produtos:', err);
    grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1;">
        <div class="diamond">◆</div>
        <h3>Não foi possível carregar o catálogo</h3>
        <p>Verifique a configuração do Firebase em js/firebase-config.js e as regras do Firestore.</p>
      </div>`;
    return;
  }
  populateCategories();
  render();
}

function getFiltered() {
  const term = searchInput.value.trim().toLowerCase();
  const cat = categoryFilter.value;
  let list = allProducts.filter(p => {
    const matchesTerm = !term ||
      (p.nome || '').toLowerCase().includes(term) ||
      (p.marca || '').toLowerCase().includes(term) ||
      (p.categoriaNome || '').toLowerCase().includes(term);
    const matchesCat = !cat || (p.categoriaNome || '') === cat;
    return matchesTerm && matchesCat;
  });

  const sort = sortFilter.value;
  if (sort === 'az') list.sort((a, b) => (a.nome || '').localeCompare(b.nome || ''));
  else if (sort === 'menor') list.sort((a, b) => precoEfetivo(a).preco - precoEfetivo(b).preco);
  else if (sort === 'maior') list.sort((a, b) => precoEfetivo(b).preco - precoEfetivo(a).preco);
  else list.sort((a, b) => (b.criadoEm?.seconds || 0) - (a.criadoEm?.seconds || 0));

  return list;
}

function render() {
  const list = getFiltered();
  if (list.length === 0) {
    grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1;">
        <div class="diamond">◆</div>
        <h3>Nenhum produto encontrado</h3>
        <p>Tente ajustar a busca ou o filtro de categoria.</p>
      </div>`;
    return;
  }

  grid.innerHTML = list.map(p => {
    const semEstoque = (p.estoque ?? 0) <= 0;
    const { preco, precoOriginal, emPromocao, percentualDesconto } = precoEfetivo(p);
    return `
    <div class="product-card" data-id="${p.id}">
      <div class="product-photo">
        ${emPromocao ? `<span class="badge-promo" style="position:absolute;top:10px;left:10px;background:var(--danger);color:#fff;font-size:11px;padding:3px 8px;border-radius:4px;z-index:1;">-${percentualDesconto}%</span>` : ''}
        ${Array.isArray(p.fotos) && p.fotos.length > 1 ? `<span style="position:absolute;bottom:10px;right:10px;background:rgba(0,0,0,.55);color:#fff;font-size:11px;padding:2px 7px;border-radius:10px;z-index:1;">📷 ${p.fotos.length}</span>` : ''}
        ${p.fotoUrl
          ? `<img src="${p.fotoUrl}" alt="${p.nome}" loading="lazy">`
          : `<span class="placeholder">◆</span>`}
      </div>
      ${p.fotoUrl ? `<div class="photo-caption">Imagem meramente ilustrativa</div>` : ''}
      <div class="product-info">
        <div class="brand-name">${p.marca || 'Sem marca'}</div>
        <h3>${p.nome || 'Sem nome'}</h3>
        <div class="cat">${p.categoriaNome || ''} ${p.volume ? '· ' + p.volume : ''}</div>
        <div class="price-block">
          <div class="price-row avista">
            <span class="label">À vista</span>
            <span class="value">
              ${emPromocao ? `<span style="text-decoration:line-through;color:var(--muted-2);font-size:12px;margin-right:6px;">${formatBRL(precoOriginal)}</span>` : ''}${formatBRL(preco)}
            </span>
          </div>
          <div class="price-row">
            <span class="label">A prazo${p.parcelas ? ' · ' + p.parcelas + 'x' : ''}</span>
            <span class="value">${formatBRL(p.valorPrazo)}</span>
          </div>
        </div>
        <button type="button" class="btn-add-cart" data-add-cart="${p.id}" ${semEstoque ? 'disabled' : ''}>
          ${semEstoque ? 'Sob encomenda' : 'Adicionar ao carrinho'}
        </button>
      </div>
    </div>
  `;
  }).join('');

  grid.querySelectorAll('.product-card').forEach(card => {
    card.addEventListener('click', (e) => {
      if (e.target.closest('[data-add-cart]')) return;
      openModal(card.dataset.id);
    });
  });
  grid.querySelectorAll('[data-add-cart]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      adicionarAoCarrinho(btn.dataset.addCart);
    });
  });
}

// Lightbox simples: mostra a foto em tela cheia, por cima de tudo (inclusive
// do modal de produto), com navegação entre fotos e fechamento por clique
// fora, no X, ou tecla Esc. Anexado direto no <body> em vez do #modalRoot
// porque precisa ficar acima do modal de produto que já está aberto.
function abrirLightboxGaleria(fotos, indiceInicial) {
  if (!fotos.length) return;
  let indice = indiceInicial;

  const el = document.createElement('div');
  el.id = 'lightboxGaleria';
  el.style.cssText = 'position:fixed;inset:0;background:rgba(10,8,6,.94);z-index:9999;display:flex;align-items:center;justify-content:center;';
  el.innerHTML = `
    <button type="button" id="lightboxFechar" aria-label="Fechar" style="position:absolute;top:16px;right:16px;background:none;border:none;color:#fff;font-size:28px;cursor:pointer;line-height:1;">✕</button>
    <img id="lightboxImg" src="${fotos[indice]}" style="max-width:92vw;max-height:88vh;object-fit:contain;">
    ${fotos.length > 1 ? `
      <button type="button" id="lightboxPrev" aria-label="Foto anterior" style="position:absolute;left:16px;top:50%;transform:translateY(-50%);background:rgba(255,255,255,.12);color:#fff;border:none;width:44px;height:44px;border-radius:50%;font-size:24px;cursor:pointer;">‹</button>
      <button type="button" id="lightboxNext" aria-label="Próxima foto" style="position:absolute;right:16px;top:50%;transform:translateY(-50%);background:rgba(255,255,255,.12);color:#fff;border:none;width:44px;height:44px;border-radius:50%;font-size:24px;cursor:pointer;">›</button>
      <div style="position:absolute;bottom:16px;left:0;right:0;text-align:center;color:#fff;font-size:13px;">${indice + 1} / ${fotos.length}</div>
    ` : ''}
  `;
  document.body.appendChild(el);
  // AJUSTADO: `overflow: hidden` no body não trava o scroll por toque no
  // Safari do iOS (bug antigo do WebKit) — o dedo ainda consegue "arrastar"
  // a página por trás da lightbox, e ao fechar a posição de rolagem podia
  // pular. A técnica robusta é fixar o body no lugar exato onde ele estava
  // (position: fixed + top negativo) e, ao fechar, tirar o fixed e rolar de
  // volta pra esse mesmo ponto — funciona em iOS, Android e desktop.
  const scrollYAtual = window.scrollY;
  document.body.style.position = 'fixed';
  document.body.style.top = `-${scrollYAtual}px`;
  document.body.style.left = '0';
  document.body.style.right = '0';

  function fechar() {
    el.remove();
    document.body.style.position = '';
    document.body.style.top = '';
    document.body.style.left = '';
    document.body.style.right = '';
    window.scrollTo(0, scrollYAtual);
    document.removeEventListener('keydown', aoTeclar);
  }
  function mostrar(i) {
    indice = ((i % fotos.length) + fotos.length) % fotos.length;
    document.getElementById('lightboxImg').src = fotos[indice];
    const contador = el.querySelector('div');
    if (contador) contador.textContent = `${indice + 1} / ${fotos.length}`;
  }
  function aoTeclar(e) {
    if (e.key === 'Escape') fechar();
    else if (e.key === 'ArrowLeft') mostrar(indice - 1);
    else if (e.key === 'ArrowRight') mostrar(indice + 1);
  }

  el.addEventListener('click', (e) => { if (e.target === el) fechar(); });
  document.getElementById('lightboxFechar').addEventListener('click', fechar);
  document.getElementById('lightboxPrev')?.addEventListener('click', () => mostrar(indice - 1));
  document.getElementById('lightboxNext')?.addEventListener('click', () => mostrar(indice + 1));
  document.addEventListener('keydown', aoTeclar);
}

function openModal(id) {
  const p = allProducts.find(x => x.id === id);
  if (!p) return;

  const precoModal = precoEfetivo(p);

  const estoqueBadge = (p.estoque ?? 0) > 0
    ? `<span class="badge badge-ok">Em estoque · ${p.estoque}</span>`
    : `<span class="badge badge-out">Sob encomenda</span>`;

  const mensagemProduto = `Olá! Tenho interesse no perfume "${p.nome}"${p.marca ? ' (' + p.marca + ')' : ''}. Poderia me passar mais informações?`;

  const botaoWhatsapp = configuracoes.contatos.length === 0 ? '' :
    configuracoes.contatos.length === 1
      ? `<button class="whatsapp-inline" id="btnWhatsappProduto" data-numero="${configuracoes.contatos[0].numero}">
           ${ICONE_WHATSAPP} Consultar este produto no WhatsApp
         </button>`
      : `<div class="field" style="margin-top:18px;">
           <label>Consultar este produto</label>
           <div style="display:flex;flex-direction:column;gap:8px;">
             ${configuracoes.contatos.map(c => `
               <a class="whatsapp-inline" style="text-decoration:none;" target="_blank" rel="noopener"
                  href="${linkWhatsapp(c.numero, mensagemProduto)}">${ICONE_WHATSAPP} ${c.label}</a>
             `).join('')}
           </div>
         </div>`;

  // Compatibilidade: produtos cadastrados antes desta funcionalidade só têm
  // `fotoUrl` (uma foto só). Nesse caso a "galeria" tem 1 item só — mesmo
  // resultado visual de antes, sem setas/miniaturas.
  const fotosGaleria = Array.isArray(p.fotos) && p.fotos.length ? p.fotos : (p.fotoUrl ? [p.fotoUrl] : []);
  let indiceFotoAtual = 0;

  const miniaturasHtml = fotosGaleria.length > 1 ? `
    <div id="galeriaMiniaturas" style="display:flex;gap:6px;margin-top:8px;flex-wrap:wrap;">
      ${fotosGaleria.map((f, i) => `
        <button type="button" class="galeria-thumb" data-thumb-idx="${i}"
          style="width:48px;height:48px;border-radius:4px;overflow:hidden;border:2px solid ${i === 0 ? 'var(--gold-bright)' : 'transparent'};padding:0;cursor:pointer;background:none;">
          <img src="${f}" style="width:100%;height:100%;object-fit:cover;display:block;">
        </button>`).join('')}
    </div>` : '';

  modalRoot.innerHTML = `
    <div class="modal-overlay" id="overlay">
      <div class="modal">
        <div class="modal-product" style="position:relative;">
          <button class="modal-close" id="closeModal">✕</button>
          <div class="modal-photo-col">
            <div class="product-photo" style="position:relative;">
              ${fotosGaleria.length
                ? `<img src="${fotosGaleria[0]}" alt="${p.nome}" id="imgGaleriaPrincipal" style="cursor:zoom-in;">`
                : `<span class="placeholder">◆</span>`}
              ${fotosGaleria.length > 1 ? `
                <button type="button" id="galeriaPrev" aria-label="Foto anterior"
                  style="position:absolute;left:6px;top:50%;transform:translateY(-50%);background:rgba(0,0,0,.5);color:#fff;border:none;width:30px;height:30px;border-radius:50%;font-size:18px;cursor:pointer;">‹</button>
                <button type="button" id="galeriaNext" aria-label="Próxima foto"
                  style="position:absolute;right:6px;top:50%;transform:translateY(-50%);background:rgba(0,0,0,.5);color:#fff;border:none;width:30px;height:30px;border-radius:50%;font-size:18px;cursor:pointer;">›</button>
              ` : ''}
            </div>
            ${fotosGaleria.length ? `<div class="photo-caption">Imagem meramente ilustrativa · clique para ampliar</div>` : ''}
            ${miniaturasHtml}
          </div>
          <div class="modal-body-content">
            <div class="brand-name">${p.marca || 'Sem marca'}</div>
            <h2 style="font-size:32px;margin-top:6px;">${p.nome}</h2>
            <div class="cat" style="margin-top:4px;">${p.categoriaNome || ''} ${p.volume ? '· ' + p.volume : ''}</div>
            <div style="margin-top:14px;">${estoqueBadge}</div>
            <p style="margin-top:18px;">${p.descricao || 'Sem descrição disponível.'}</p>
            <div class="divider"><span class="diamond">◆</span></div>
            <div class="price-row avista"><span class="label">À vista</span><span class="value">${precoModal.emPromocao ? `<span style="text-decoration:line-through;color:var(--muted-2);font-size:13px;margin-right:6px;">${formatBRL(precoModal.precoOriginal)}</span>` : ''}${formatBRL(precoModal.preco)}</span></div>
            <div class="price-row" style="margin-top:10px;"><span class="label">A prazo${p.parcelas ? ' em ' + p.parcelas + 'x' : ''}</span><span class="value">${formatBRL(p.valorPrazo)}</span></div>
            <button type="button" class="btn-add-cart" id="btnAddCartModal" data-add-cart="${p.id}" style="margin-top:16px;" ${(p.estoque ?? 0) <= 0 ? 'disabled' : ''}>
              ${(p.estoque ?? 0) <= 0 ? 'Sob encomenda' : 'Adicionar ao carrinho'}
            </button>
            ${botaoWhatsapp}
          </div>
        </div>
      </div>
    </div>
  `;

  function mostrarFotoGaleria(i) {
    if (!fotosGaleria.length) return;
    indiceFotoAtual = ((i % fotosGaleria.length) + fotosGaleria.length) % fotosGaleria.length;
    const imgEl = document.getElementById('imgGaleriaPrincipal');
    if (imgEl) imgEl.src = fotosGaleria[indiceFotoAtual];
    document.querySelectorAll('.galeria-thumb').forEach((btn, idx) => {
      btn.style.borderColor = idx === indiceFotoAtual ? 'var(--gold-bright)' : 'transparent';
    });
  }
  document.getElementById('galeriaPrev')?.addEventListener('click', () => mostrarFotoGaleria(indiceFotoAtual - 1));
  document.getElementById('galeriaNext')?.addEventListener('click', () => mostrarFotoGaleria(indiceFotoAtual + 1));
  document.querySelectorAll('.galeria-thumb').forEach(btn => {
    btn.addEventListener('click', () => mostrarFotoGaleria(Number(btn.dataset.thumbIdx)));
  });
  document.getElementById('imgGaleriaPrincipal')?.addEventListener('click', () => abrirLightboxGaleria(fotosGaleria, indiceFotoAtual));

  const overlay = document.getElementById('overlay');
  document.getElementById('closeModal').addEventListener('click', () => modalRoot.innerHTML = '');
  overlay.addEventListener('click', (e) => { if (e.target === overlay) modalRoot.innerHTML = ''; });

  const btnUnico = document.getElementById('btnWhatsappProduto');
  if (btnUnico) {
    btnUnico.addEventListener('click', () => {
      window.open(linkWhatsapp(btnUnico.dataset.numero, mensagemProduto), '_blank');
    });
  }
  const btnAddModal = document.getElementById('btnAddCartModal');
  if (btnAddModal) {
    btnAddModal.addEventListener('click', () => adicionarAoCarrinho(p.id));
  }
}

searchInput.addEventListener('input', render);
categoryFilter.addEventListener('change', render);
sortFilter.addEventListener('change', render);

/* ============================================================================
   CARRINHO
   ============================================================================ */
let carrinho = [];

function carregarCarrinhoDoStorage() {
  try {
    const salvo = localStorage.getItem('essencia_carrinho');
    carrinho = salvo ? JSON.parse(salvo) : [];
  } catch (e) {
    carrinho = [];
  }
}

function salvarCarrinhoNoStorage() {
  try { localStorage.setItem('essencia_carrinho', JSON.stringify(carrinho)); } catch (e) { /* storage indisponível */ }
}

function adicionarAoCarrinho(produtoId) {
  const produto = allProducts.find(p => p.id === produtoId);
  if (!produto) return;
  const existente = carrinho.find(i => i.produtoId === produtoId);
  const estoqueDisponivel = produto.estoque ?? 0;
  if (existente) {
    if (existente.quantidade >= estoqueDisponivel) {
      mostrarToastPublico('Não há mais estoque disponível desse produto.', true);
      return;
    }
    existente.quantidade += 1;
  } else {
    carrinho.push({ produtoId, nome: produto.nome, valorUnitario: precoEfetivo(produto).preco, quantidade: 1 });
  }
  salvarCarrinhoNoStorage();
  renderCartFab();
  mostrarToastPublico(`"${produto.nome}" adicionado ao carrinho.`);
}

function alterarQuantidadeCarrinho(produtoId, delta) {
  const linha = carrinho.find(i => i.produtoId === produtoId);
  if (!linha) return;
  const produto = allProducts.find(p => p.id === produtoId);
  const estoqueDisponivel = produto?.estoque ?? 99;
  linha.quantidade = Math.max(1, Math.min(estoqueDisponivel, linha.quantidade + delta));
  salvarCarrinhoNoStorage();
  abrirCarrinho();
  renderCartFab();
}

function removerDoCarrinho(produtoId) {
  carrinho = carrinho.filter(i => i.produtoId !== produtoId);
  salvarCarrinhoNoStorage();
  abrirCarrinho();
  renderCartFab();
}

function totalCarrinho() {
  return carrinho.reduce((soma, i) => soma + i.quantidade * i.valorUnitario, 0);
}

function renderCartFab() {
  if (!cartFabRoot) return;
  const qtd = carrinho.reduce((s, i) => s + i.quantidade, 0);
  if (qtd === 0) { cartFabRoot.innerHTML = ''; return; }
  cartFabRoot.innerHTML = `
    <button type="button" class="cart-fab" id="cartFabBtn">
      ${ICONE_SACOLA}
      <span class="cart-fab-badge">${qtd}</span>
    </button>`;
  document.getElementById('cartFabBtn').addEventListener('click', abrirCarrinho);
}

function abrirCarrinho() {
  if (carrinho.length === 0) {
    modalRoot.innerHTML = '';
    return;
  }
  const linhas = carrinho.map(i => `
    <div class="cart-line" data-id="${i.produtoId}">
      <div class="cart-line-info">
        <div class="cart-line-nome">${i.nome}</div>
        <div class="cell-mono cart-line-preco">${formatBRL(i.valorUnitario)}</div>
      </div>
      <div class="cart-line-qtd">
        <button type="button" data-qtd-menos="${i.produtoId}">−</button>
        <span>${i.quantidade}</span>
        <button type="button" data-qtd-mais="${i.produtoId}">+</button>
      </div>
      <button type="button" class="cart-line-remover" data-remover="${i.produtoId}">✕</button>
    </div>
  `).join('');

  modalRoot.innerHTML = `
    <div class="modal-overlay" id="cartOverlay">
      <div class="modal" style="max-width:480px;">
        <div class="modal-form">
          <button class="modal-close" id="closeCart">✕</button>
          <h2 style="font-size:24px;margin-bottom:18px;">Seu carrinho</h2>
          <div id="cartLines">${linhas}</div>
          <div class="divider"><span class="diamond">◆</span></div>
          <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:20px;">
            <span class="cell-muted">Total (à vista)</span>
            <span style="font-family:var(--font-mono);font-size:22px;color:var(--gold-bright);">${formatBRL(totalCarrinho())}</span>
          </div>
          <button type="button" class="btn btn-gold" id="btnIrCheckout" style="width:100%;justify-content:center;">Finalizar pedido</button>
          <button type="button" class="btn btn-ghost" id="btnLimparCarrinho" style="width:100%;justify-content:center;margin-top:8px;color:var(--danger);">Limpar carrinho</button>
          <p style="font-size:12px;color:var(--muted-2);margin-top:10px;text-align:center;">Pagamento à vista via PIX. Confirmação de recebimento é feita manualmente pela loja.</p>
        </div>
      </div>
    </div>`;

  const overlay = document.getElementById('cartOverlay');
  document.getElementById('closeCart').addEventListener('click', () => modalRoot.innerHTML = '');
  overlay.addEventListener('click', (e) => { if (e.target === overlay) modalRoot.innerHTML = ''; });

  overlay.querySelectorAll('[data-qtd-mais]').forEach(b => b.addEventListener('click', () => alterarQuantidadeCarrinho(b.dataset.qtdMais, 1)));
  overlay.querySelectorAll('[data-qtd-menos]').forEach(b => b.addEventListener('click', () => alterarQuantidadeCarrinho(b.dataset.qtdMenos, -1)));
  overlay.querySelectorAll('[data-remover]').forEach(b => b.addEventListener('click', () => removerDoCarrinho(b.dataset.remover)));
  document.getElementById('btnIrCheckout').addEventListener('click', irParaCheckout);
  document.getElementById('btnLimparCarrinho').addEventListener('click', () => {
    confirmarAcaoPublica({
      titulo: 'Esvaziar carrinho?',
      mensagem: 'Todos os itens serão removidos.',
      textoBotao: 'Esvaziar',
      aoConfirmar: () => {
        carrinho = [];
        salvarCarrinhoNoStorage();
        renderCartFab();
        modalRoot.innerHTML = '';
        mostrarToastPublico('Carrinho esvaziado.');
      },
    });
  });
}

function irParaCheckout() {
  if (!clienteAtual) {
    abrirModalLoginCliente({
      mensagem: 'Crie uma conta ou entre para finalizar seu pedido — é rápido, e a próxima compra vem com seus dados já preenchidos.',
      aoAutenticar: async (user) => {
        clienteAtual = user;
        perfilClienteAtual = await carregarPerfilCliente(user.uid);
        renderContaArea();
        abrirCheckout();
      },
    });
    return;
  }
  abrirCheckout();
}

function abrirCheckout() {
  const nomeSalvo = perfilClienteAtual?.nome || '';
  const telefoneSalvo = perfilClienteAtual?.telefone || '';
  modalRoot.innerHTML = `
    <div class="modal-overlay" id="checkoutOverlay">
      <div class="modal" style="max-width:480px;">
        <div class="modal-form">
          <button class="modal-close" id="closeCheckout">✕</button>
          <h2 style="font-size:24px;margin-bottom:4px;">Finalizar pedido</h2>
          <p class="cell-muted" style="margin-bottom:18px;">${clienteAtual.email || ''}</p>
          <form id="checkoutForm">
            <div class="field">
              <label>Nome *</label>
              <input type="text" id="chkNome" required value="${nomeSalvo}">
            </div>
            <div class="field">
              <label>Telefone / WhatsApp *</label>
              <input type="text" id="chkTelefone" required placeholder="(11) 99999-0000" value="${telefoneSalvo}">
            </div>
            <div class="field">
              <label>Entrega *</label>
              <div class="pill-toggle" id="chkTipoEntrega">
                <button type="button" data-tipo="retirada" class="active">Retirar na loja</button>
                <button type="button" data-tipo="entrega">Entrega</button>
              </div>
            </div>
            <div class="field" id="chkEnderecoWrap" style="display:none;">
              <label>Endereço de entrega *</label>
              <div id="chkEnderecoConteudo"></div>
              <p style="font-size:12px;color:var(--muted-2);margin-top:6px;">O frete não está incluso no valor abaixo — a loja combina o valor com você depois do pedido e libera o pagamento em seguida.</p>
            </div>
            <div class="divider"><span class="diamond">◆</span></div>
            <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:20px;">
              <span class="cell-muted" id="chkTotalLabel">Total (à vista)</span>
              <span style="font-family:var(--font-mono);font-size:22px;color:var(--gold-bright);">${formatBRL(totalCarrinho())}</span>
            </div>
            <button type="submit" class="btn btn-gold" id="btnConfirmarPedido" style="width:100%;justify-content:center;">Confirmar pedido</button>
          </form>
        </div>
      </div>
    </div>`;

  const overlay = document.getElementById('checkoutOverlay');
  document.getElementById('closeCheckout').addEventListener('click', () => modalRoot.innerHTML = '');
  overlay.addEventListener('click', (e) => { if (e.target === overlay) modalRoot.innerHTML = ''; });

  let tipoEntrega = 'retirada';
  let mostrandoFormNovoEndereco = false;
  let formNovoEndereco = null;

  function renderSeletorEndereco() {
    const enderecos = perfilClienteAtual?.enderecos || [];
    const conteudo = document.getElementById('chkEnderecoConteudo');
    if (!conteudo) return;

    if (mostrandoFormNovoEndereco || enderecos.length === 0) {
      conteudo.innerHTML = `
        <div id="chkFormEnderecoEstruturado"></div>
        <label style="display:flex;align-items:center;gap:8px;margin-top:8px;font-size:12px;">
          <input type="checkbox" id="chkSalvarEndereco" ${enderecos.length === 0 ? 'checked disabled' : 'checked'} style="width:14px;height:14px;">
          Salvar este endereço no meu perfil
        </label>
        ${enderecos.length > 0 ? `<button type="button" class="btn btn-ghost btn-sm" id="chkUsarSalvoBtn" style="margin-top:8px;">← Usar um endereço salvo</button>` : ''}
      `;
      formNovoEndereco = montarFormularioEndereco(document.getElementById('chkFormEnderecoEstruturado'), {});
      const voltarBtn = document.getElementById('chkUsarSalvoBtn');
      if (voltarBtn) voltarBtn.addEventListener('click', () => { mostrandoFormNovoEndereco = false; formNovoEndereco = null; renderSeletorEndereco(); });
    } else {
      formNovoEndereco = null;
      const principal = enderecoPrincipal(perfilClienteAtual);
      conteudo.innerHTML = enderecos.map(e => `
        <label style="display:flex;gap:10px;align-items:flex-start;padding:10px;border:1px solid var(--border);border-radius:var(--radius);margin-bottom:8px;cursor:pointer;">
          <input type="radio" name="chkEnderecoRadio" value="${e.id}" ${e.id === principal?.id ? 'checked' : ''} style="margin-top:3px;">
          <div>
            <strong style="font-size:13px;color:var(--ivory);">${e.label || 'Endereço'}</strong>
            ${e.principal ? ' <span class="cell-muted">(principal)</span>' : ''}
            <div class="cell-muted" style="font-size:12px;">${e.endereco}</div>
          </div>
        </label>
      `).join('') + `<button type="button" class="btn btn-ghost btn-sm" id="chkNovoEnderecoBtn">+ Usar um novo endereço</button>`;
      document.getElementById('chkNovoEnderecoBtn').addEventListener('click', () => { mostrandoFormNovoEndereco = true; renderSeletorEndereco(); });
    }
  }

  overlay.querySelectorAll('#chkTipoEntrega button').forEach(btn => {
    btn.addEventListener('click', () => {
      overlay.querySelectorAll('#chkTipoEntrega button').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      tipoEntrega = btn.dataset.tipo;
      document.getElementById('chkEnderecoWrap').style.display = tipoEntrega === 'entrega' ? 'block' : 'none';
      document.getElementById('chkTotalLabel').textContent = tipoEntrega === 'entrega' ? 'Subtotal (frete à parte)' : 'Total (à vista)';
      if (tipoEntrega === 'entrega') renderSeletorEndereco();
    });
  });

  async function resolverEnderecoEscolhido() {
    const radioMarcado = overlay.querySelector('input[name="chkEnderecoRadio"]:checked');
    if (radioMarcado && !mostrandoFormNovoEndereco) {
      const e = (perfilClienteAtual?.enderecos || []).find(x => x.id === radioMarcado.value);
      return e ? e.endereco : null;
    }
    if (!formNovoEndereco) { mostrarToastPublico('Escolha ou informe um endereço de entrega.', true); return null; }
    const erro = formNovoEndereco.validar();
    if (erro) { mostrarToastPublico(erro, true); return null; }
    const dados = formNovoEndereco.ler();
    const enderecoFormatado = formatarEndereco(dados);
    const salvar = document.getElementById('chkSalvarEndereco')?.checked;
    if (salvar) {
      try {
        const { lista } = await salvarEndereco(clienteAtual.uid, perfilClienteAtual?.enderecos, dados);
        perfilClienteAtual = { ...perfilClienteAtual, enderecos: lista };
      } catch (err) { console.warn('Não foi possível salvar o endereço no perfil:', err.message); }
    }
    return enderecoFormatado;
  }

  document.getElementById('checkoutForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = document.getElementById('btnConfirmarPedido');
    if (!clienteAtual) {
      mostrarToastPublico('Sua sessão expirou — faça login de novo.', true);
      return;
    }
    let endereco = '';
    if (tipoEntrega === 'entrega') {
      endereco = await resolverEnderecoEscolhido();
      if (endereco === null) return;
    }
    btn.disabled = true;
    btn.textContent = 'Enviando...';
    try {
      const nome = document.getElementById('chkNome').value.trim();
      const telefone = document.getElementById('chkTelefone').value.trim();
      const idToken = await clienteAtual.getIdToken();
      const resp = await fetch('/api/criar-pedido', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${idToken}` },
        body: JSON.stringify({
          comprador: { nome, telefone, tipoEntrega, endereco: tipoEntrega === 'entrega' ? endereco : null },
          itens: carrinho.map(i => ({ produtoId: i.produtoId, quantidade: i.quantidade })),
          fcmToken: tokenFcmAtual,
        }),
      });
      const data = await resp.json().catch(() => ({}));
      if (!resp.ok) throw new Error(data.error || 'Não foi possível criar o pedido.');

      salvarPerfilCliente(clienteAtual.uid, { nome, telefone }).catch(() => {});
      perfilClienteAtual = { ...perfilClienteAtual, nome, telefone };

      salvarPedidoLocal(data.id);
      carrinho = [];
      salvarCarrinhoNoStorage();
      renderCartFab();
      mostrarConfirmacaoPedido(data.id, data.valorTotal, data.aguardandoFrete);
    } catch (err) {
      console.error(err);
      mostrarToastPublico(err.message, true);
      btn.disabled = false;
      btn.textContent = 'Confirmar pedido';
    }
  });
}

function salvarPedidoLocal(id) {
  try {
    const lista = JSON.parse(localStorage.getItem('essencia_meus_pedidos') || '[]');
    lista.unshift({ id, criadoEm: new Date().toISOString() });
    localStorage.setItem('essencia_meus_pedidos', JSON.stringify(lista.slice(0, 20)));
  } catch (e) { /* storage indisponível */ }
}

function mostrarConfirmacaoPedido(pedidoId, valorTotal, aguardandoFrete) {
  const linkAcompanhamento = `pedido.html?id=${pedidoId}`;

  let payloadPix = '';
  let corpoHtml;

  if (aguardandoFrete) {
    corpoHtml = `
      <p class="cell-muted" style="margin-bottom:20px;">Subtotal dos itens: ${formatBRL(valorTotal)}</p>
      <p style="font-size:13px;">A loja vai combinar o valor do frete com você (fica de olho no WhatsApp) e liberar o pagamento assim que definido — acompanhe por este link.</p>
    `;
  } else {
    try {
      if (configuracoes.pixChave) {
        payloadPix = gerarPayloadPix({
          chave: configuracoes.pixChave,
          nomeRecebedor: configuracoes.pixNome,
          cidadeRecebedor: configuracoes.pixCidade,
          valor: valorTotal,
          identificador: `PEDIDO${pedidoId.slice(0, 10).toUpperCase()}`,
        });
      }
    } catch (e) { /* segue sem PIX */ }

    corpoHtml = `
      <p class="cell-muted" style="margin-bottom:20px;">${formatBRL(valorTotal)} — pague via PIX para confirmar</p>
      ${payloadPix ? `<div id="pixQrPublico" style="display:flex;justify-content:center;margin-bottom:16px;"></div>
      <textarea readonly rows="3" id="pixCopiaColaPublico" style="width:100%;font-family:var(--font-mono);font-size:11px;resize:none;">${payloadPix}</textarea>
      <button type="button" class="btn btn-gold" id="btnCopiarPixPublico" style="width:100%;justify-content:center;margin-top:10px;">Copiar código PIX</button>`
      : `<p style="color:var(--danger);font-size:13px;">A loja ainda não configurou o recebimento via PIX — entre em contato pelo WhatsApp pra combinar o pagamento.</p>`}
    `;
  }

  modalRoot.innerHTML = `
    <div class="modal-overlay" id="confirmPedidoOverlay">
      <div class="modal" style="max-width:460px;">
        <div class="modal-form" style="text-align:center;">
          <h2 style="font-size:26px;margin-bottom:6px;">Pedido feito! 🎉</h2>
          ${corpoHtml}
          <div class="divider"><span class="diamond">◆</span></div>
          <p style="font-size:13px;">Acompanhe seu pedido a qualquer momento por este link:</p>
          <a href="${linkAcompanhamento}" style="display:block;word-break:break-all;font-size:12px;margin:8px 0 16px;">${location.origin}${location.pathname.replace('index.html', '')}${linkAcompanhamento}</a>
          <a href="${linkAcompanhamento}" class="btn btn-gold" style="width:100%;justify-content:center;">Ver status do meu pedido</a>
        </div>
      </div>
    </div>`;

  if (payloadPix && window.QRCode) {
    new QRCode(document.getElementById('pixQrPublico'), { text: payloadPix, width: 180, height: 180, colorDark: '#14100f', colorLight: '#f4ece3' });
  }
  const btnCopiar = document.getElementById('btnCopiarPixPublico');
  if (btnCopiar) {
    btnCopiar.addEventListener('click', () => {
      navigator.clipboard.writeText(payloadPix).then(() => mostrarToastPublico('Código PIX copiado.'));
    });
  }
}

function mostrarToastPublico(msg, erro = false) {
  const el = document.createElement('div');
  el.className = 'toast' + (erro ? ' error' : '');
  el.innerHTML = `<span class="dot"></span>${msg}`;
  document.body.appendChild(el);
  requestAnimationFrame(() => el.classList.add('show'));
  setTimeout(() => { el.classList.remove('show'); setTimeout(() => el.remove(), 300); }, 3200);
}

carregarCarrinhoDoStorage();
renderCartFab();

/* ============================================================================
   NOTIFICAÇÕES PUSH (FCM)
   ============================================================================ */
const VAPID_KEY = 'BHf5W_1xv23Me-Fv-ebUbNXLQZ6It071U0KxPYrL3RwXc9wQX23yDPC80InpPK6jlbjv3wPtZNxz13U3KSfGCBs';

async function registrarNotificacoesPush() {
  if (!messaging) return;
  if (!('Notification' in window) || !navigator.serviceWorker) return;

  const permissao = await Notification.requestPermission();
  if (permissao !== 'granted') {
    console.log('Permissão de notificação negada pelo usuário.');
    return;
  }

  try {
    const tokenAtual = await getToken(messaging, { 
      vapidKey: VAPID_KEY,
      serviceWorkerRegistration: await navigator.serviceWorker.ready 
    });

    if (tokenAtual) {
      tokenFcmAtual = tokenAtual;
      await setDoc(doc(db, 'fcmTokens', tokenAtual), {
        token: tokenAtual,
        plataforma: navigator.platform,
        userAgent: navigator.userAgent.slice(0, 100),
        criadoEm: serverTimestamp(),
        ultimoAcesso: serverTimestamp(),
      });
      console.log('Token FCM registrado:', tokenAtual.slice(0, 20) + '...');
    }
  } catch (err) {
    console.error('Erro ao registrar notificações push:', err);
  }
}

if (messaging) {
  onMessage(messaging, (payload) => {
    const { title, body, icon } = payload.notification || {};
    if (Notification.permission === 'granted') {
      new Notification(title || 'Essência Perfumaria', {
        body: body || '',
        icon: icon || '/icon-192.png',
        data: payload.data || {},
      });
    }
  });
}

// Carregar tudo
async function init() {
  await carregarCategorias();
  await loadProducts();
  await carregarConfiguracoes();
  await registrarNotificacoesPush();
}

init();