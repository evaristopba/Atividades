// ============================================================================
// js/sw-register.js
// ============================================================================
// Registro do Service Worker de notificações push (FCM). Isolado em arquivo
// próprio (em vez de <script> inline no HTML) para permitir uma
// Content-Security-Policy sem 'unsafe-inline' em script-src — script inline
// é exatamente o que um XSS injetado precisaria para executar, então manter
// só scripts externos com origem própria (self) é uma barreira a mais.
// ============================================================================
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/firebase-messaging-sw.js')
    .then(reg => console.log('SW registrado:', reg.scope))
    .catch(err => console.error('Erro ao registrar SW:', err));
}
