// ============================================================================
// js/conta-cliente.js
// ============================================================================
// Login/cadastro do CLIENTE (diferente do admin — aqui qualquer pessoa
// pode criar conta livremente, é assim que deve ser). Usa o mesmo projeto
// Firebase Auth do admin, mas contas de cliente nunca recebem custom claim
// de papel (owner/operador) — por isso, mesmo autenticadas, elas não têm
// nenhum acesso a produtos/clientes/fornecedores (as regras do Firestore
// exigem o papel, não só "estar logado" — ver firestore.rules).
// ============================================================================

import {
  auth, db, doc, getDoc, setDoc, collection, query, where, getDocs,
  signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, onAuthStateChanged,
  sendPasswordResetEmail, googleProvider, signInWithPopup, reauthenticateWithCredential, EmailAuthProvider, updatePassword,
  onAuthStateChanged as onAuthChanged
} from './firebase-config.js';

export function aoMudarAuthCliente(callback) {
  return onAuthChanged(auth, callback);
}

export function usuarioAtual() {
  return auth.currentUser;
}

export function sairDaConta() {
  return signOut(auth);
}

export async function carregarPerfilCliente(uid) {
  try {
    const snap = await getDoc(doc(db, 'contasClientes', uid));
    return snap.exists() ? snap.data() : null;
  } catch (e) {
    console.error('Erro ao carregar perfil:', e);
    return null;
  }
}

export async function salvarPerfilCliente(uid, dados) {
  await setDoc(doc(db, 'contasClientes', uid), dados, { merge: true });
}

/* ============================================================================
   ENDEREÇOS SALVOS
   ============================================================================ */
export const UF_LIST = [
  ['AC', 'Acre'], ['AL', 'Alagoas'], ['AP', 'Amapá'], ['AM', 'Amazonas'],
  ['BA', 'Bahia'], ['CE', 'Ceará'], ['DF', 'Distrito Federal'], ['ES', 'Espírito Santo'],
  ['GO', 'Goiás'], ['MA', 'Maranhão'], ['MT', 'Mato Grosso'], ['MS', 'Mato Grosso do Sul'],
  ['MG', 'Minas Gerais'], ['PA', 'Pará'], ['PB', 'Paraíba'], ['PR', 'Paraná'],
  ['PE', 'Pernambuco'], ['PI', 'Piauí'], ['RJ', 'Rio de Janeiro'], ['RN', 'Rio Grande do Norte'],
  ['RS', 'Rio Grande do Sul'], ['RO', 'Rondônia'], ['RR', 'Roraima'], ['SC', 'Santa Catarina'],
  ['SP', 'São Paulo'], ['SE', 'Sergipe'], ['TO', 'Tocantins']
];

function gerarIdEndereco() {
  return (typeof crypto !== 'undefined' && crypto.randomUUID)
    ? crypto.randomUUID()
    : 'end_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);
}

export function formatarEndereco({ rua, numero, complemento, bairro, cidade, uf, cep }) {
  const linha1 = [rua, numero].filter(Boolean).join(', ');
  const partes = [linha1, complemento, bairro, [cidade, uf].filter(Boolean).join('/')].filter(Boolean);
  const cepFmt = cep ? `CEP ${cep}` : '';
  return [partes.join(' - '), cepFmt].filter(Boolean).join(' · ');
}

async function carregarCidadesEndereco(uf, cidadeParaSelecionar, selectEl) {
  if (!uf) {
    selectEl.innerHTML = '<option value="">Selecione o UF primeiro</option>';
    selectEl.disabled = true;
    return;
  }
  selectEl.disabled = true;
  selectEl.innerHTML = '<option value="">Carregando cidades...</option>';
  try {
    const resp = await fetch(`https://servicodados.ibge.gov.br/api/v1/localidades/estados/${uf}/municipios`);
    if (!resp.ok) throw new Error('Falha ao consultar o IBGE.');
    const municipios = await resp.json();
    const nomes = municipios.map(m => m.nome).sort((a, b) => a.localeCompare(b, 'pt-BR'));
    selectEl.innerHTML = '<option value="">Selecione a cidade</option>' +
      nomes.map(n => `<option value="${n}" ${n === cidadeParaSelecionar ? 'selected' : ''}>${n}</option>`).join('');
    selectEl.disabled = false;
  } catch (err) {
    console.error('Erro ao carregar cidades do IBGE:', err);
    selectEl.innerHTML = `<option value="${cidadeParaSelecionar || ''}">${cidadeParaSelecionar || 'Não foi possível carregar as cidades'}</option>`;
    selectEl.disabled = false;
  }
}

export function montarFormularioEndereco(container, valores = {}) {
  const labelPadrao = valores.label && !['Casa', 'Trabalho'].includes(valores.label) ? 'Outro' : (valores.label || 'Casa');

  container.innerHTML = `
    <div class="field-row">
      <div class="field" style="flex:0 0 140px;">
        <label>CEP</label>
        <input type="text" class="end-cep" maxlength="9" placeholder="00000-000" value="${valores.cep || ''}">
        <span class="field-hint end-cep-hint"></span>
      </div>
      <div class="field" style="flex:1;">
        <label>Rua / Logradouro</label>
        <input type="text" class="end-rua" value="${valores.rua || ''}">
      </div>
    </div>
    <div class="field-row">
      <div class="field" style="flex:0 0 110px;">
        <label>Número</label>
        <input type="text" class="end-numero" value="${valores.numero || ''}">
      </div>
      <div class="field" style="flex:1;">
        <label>Complemento</label>
        <input type="text" class="end-complemento" placeholder="Apto, bloco... (opcional)" value="${valores.complemento || ''}">
      </div>
    </div>
    <div class="field">
      <label>Bairro</label>
      <input type="text" class="end-bairro" value="${valores.bairro || ''}">
    </div>
    <div class="field-row">
      <div class="field" style="flex:0 0 90px;">
        <label>UF</label>
        <select class="end-uf">
          <option value="">UF</option>
          ${UF_LIST.map(([sigla]) => `<option value="${sigla}" ${sigla === valores.uf ? 'selected' : ''}>${sigla}</option>`).join('')}
        </select>
      </div>
      <div class="field" style="flex:1;">
        <label>Cidade</label>
        <select class="end-cidade" disabled>
          <option value="">${valores.uf ? 'Carregando...' : 'Selecione o UF primeiro'}</option>
        </select>
      </div>
    </div>
    <div class="field">
      <label>Identificar como</label>
      <div class="pill-toggle end-label-toggle">
        <button type="button" data-label="Casa" class="${labelPadrao === 'Casa' ? 'active' : ''}">Casa</button>
        <button type="button" data-label="Trabalho" class="${labelPadrao === 'Trabalho' ? 'active' : ''}">Trabalho</button>
        <button type="button" data-label="Outro" class="${labelPadrao === 'Outro' ? 'active' : ''}">Outro</button>
      </div>
      <input type="text" class="end-label-outro" placeholder="Nome do endereço" value="${labelPadrao === 'Outro' ? (valores.label || '') : ''}"
        style="margin-top:8px;display:${labelPadrao === 'Outro' ? 'block' : 'none'};">
    </div>
  `;

  const cepInput = container.querySelector('.end-cep');
  const cepHint = container.querySelector('.end-cep-hint');
  const ufSelect = container.querySelector('.end-uf');
  const cidadeSelect = container.querySelector('.end-cidade');
  const ruaInput = container.querySelector('.end-rua');
  const bairroInput = container.querySelector('.end-bairro');

  cepInput.addEventListener('input', () => {
    let v = cepInput.value.replace(/\D/g, '').slice(0, 8);
    if (v.length > 5) v = v.slice(0, 5) + '-' + v.slice(5);
    cepInput.value = v;
  });
  const buscarCep = async () => {
    const cep = cepInput.value.replace(/\D/g, '');
    if (cep.length !== 8) return;
    cepHint.textContent = 'Buscando endereço pelo CEP...';
    cepHint.classList.remove('error');
    try {
      const resp = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
      const data = await resp.json();
      if (data.erro) {
        cepHint.textContent = 'CEP não encontrado — preencha manualmente.';
        cepHint.classList.add('error');
        return;
      }
      if (data.logradouro) ruaInput.value = data.logradouro;
      if (data.bairro) bairroInput.value = data.bairro;
      if (data.uf) { ufSelect.value = data.uf; await carregarCidadesEndereco(data.uf, data.localidade, cidadeSelect); }
      cepHint.textContent = 'Endereço preenchido a partir do CEP — confira antes de salvar.';
      cepHint.classList.remove('error');
    } catch (err) {
      cepHint.textContent = 'Não foi possível consultar o CEP agora — preencha manualmente.';
      cepHint.classList.add('error');
    }
  };
  cepInput.addEventListener('blur', buscarCep);
  cepInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); buscarCep(); } });

  ufSelect.addEventListener('change', () => carregarCidadesEndereco(ufSelect.value, null, cidadeSelect));
  if (valores.uf) carregarCidadesEndereco(valores.uf, valores.cidade, cidadeSelect);

  container.querySelectorAll('.end-label-toggle button').forEach(btn => {
    btn.addEventListener('click', () => {
      container.querySelectorAll('.end-label-toggle button').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const outroInput = container.querySelector('.end-label-outro');
      outroInput.style.display = btn.dataset.label === 'Outro' ? 'block' : 'none';
    });
  });

  function ler() {
    const labelAtivo = container.querySelector('.end-label-toggle button.active')?.dataset.label || 'Casa';
    const label = labelAtivo === 'Outro' ? (container.querySelector('.end-label-outro').value.trim() || 'Outro') : labelAtivo;
    return {
      cep: cepInput.value.trim(),
      rua: ruaInput.value.trim(),
      numero: container.querySelector('.end-numero').value.trim(),
      complemento: container.querySelector('.end-complemento').value.trim(),
      bairro: bairroInput.value.trim(),
      cidade: cidadeSelect.value,
      uf: ufSelect.value,
      label,
    };
  }

  return {
    ler,
    validar() {
      const v = ler();
      if (!v.rua || !v.numero || !v.bairro || !v.cidade || !v.uf) {
        return 'Preencha rua, número, bairro, cidade e UF.';
      }
      return null;
    },
  };
}

export function enderecoPrincipal(perfil) {
  const lista = perfil?.enderecos || [];
  return lista.find(e => e.principal) || lista[0] || null;
}

export async function salvarEndereco(uid, enderecosAtuais, dados) {
  let lista = [...(enderecosAtuais || [])];
  let idFinal = dados.id;
  const enderecoFormatado = formatarEndereco(dados);
  const camposEndereco = {
    label: dados.label || 'Casa',
    cep: dados.cep || '',
    rua: dados.rua || '',
    numero: dados.numero || '',
    complemento: dados.complemento || '',
    bairro: dados.bairro || '',
    cidade: dados.cidade || '',
    uf: dados.uf || '',
    endereco: enderecoFormatado,
  };

  if (idFinal) {
    lista = lista.map(e => e.id === idFinal ? { ...e, ...camposEndereco } : e);
  } else {
    idFinal = gerarIdEndereco();
    const ehPrimeiro = lista.length === 0;
    const viraPrincipal = ehPrimeiro || !!dados.principal;
    if (viraPrincipal) lista = lista.map(e => ({ ...e, principal: false }));
    lista.push({ id: idFinal, ...camposEndereco, principal: viraPrincipal });
  }

  await salvarPerfilCliente(uid, { enderecos: lista });
  return { lista, id: idFinal };
}

export async function definirEnderecoPrincipal(uid, enderecosAtuais, enderecoId) {
  const lista = (enderecosAtuais || []).map(e => ({ ...e, principal: e.id === enderecoId }));
  await salvarPerfilCliente(uid, { enderecos: lista });
  return lista;
}

export async function removerEndereco(uid, enderecosAtuais, enderecoId) {
  const original = enderecosAtuais || [];
  const eraPrincipal = original.find(e => e.id === enderecoId)?.principal;
  let lista = original.filter(e => e.id !== enderecoId);
  if (eraPrincipal && lista.length > 0 && !lista.some(e => e.principal)) {
    lista = lista.map((e, i) => i === 0 ? { ...e, principal: true } : e);
  }
  await salvarPerfilCliente(uid, { enderecos: lista });
  return lista;
}

export async function carregarMeusPedidos(uid) {
  const q = query(collection(db, 'pedidos'), where('compradorUid', '==', uid));
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() }))
    .sort((a, b) => (b.criadoEm?.seconds || 0) - (a.criadoEm?.seconds || 0));
}

function traduzErroAuth(code) {
  const map = {
    'auth/invalid-credential': 'E-mail ou senha incorretos.',
    'auth/email-already-in-use': 'Esse e-mail já está cadastrado — tente entrar em vez de criar conta.',
    'auth/weak-password': 'Senha muito fraca (mínimo 6 caracteres).',
    'auth/invalid-email': 'E-mail inválido.',
    'auth/too-many-requests': 'Muitas tentativas. Aguarde um instante.',
    'auth/popup-closed-by-user': 'Login cancelado.',
    'auth/wrong-password': 'Senha atual incorreta.',
    'auth/requires-recent-login': 'É necessário fazer login novamente para esta operação.',
    'auth/network-request-failed': 'Falha de conexão. Verifique sua internet.',
  };
  return map[code] || 'Não foi possível concluir. Tente de novo.';
}

/* ============================================================================
   REDEFINIÇÃO DE SENHA (Esqueci minha senha)
   ============================================================================ */
export async function enviarLinkRedefinicaoSenha(email) {
  try {
    await sendPasswordResetEmail(auth, email, {
      url: `${window.location.origin}/index.html`,
      handleCodeInApp: false,
    });
    return { sucesso: true, mensagem: 'Enviamos um link de redefinição de senha para seu e-mail.' };
  } catch (err) {
    console.error('Erro ao enviar link de redefinição:', err);
    return { sucesso: false, mensagem: traduzErroAuth(err.code) };
  }
}

/* ============================================================================
   TROCA DE SENHA (usuário logado)
   ============================================================================ */
export async function trocarSenha(usuario, senhaAtual, novaSenha) {
  try {
    const credential = EmailAuthProvider.credential(usuario.email, senhaAtual);
    await reauthenticateWithCredential(usuario, credential);
    await updatePassword(usuario, novaSenha);
    return { sucesso: true, mensagem: 'Senha alterada com sucesso!' };
  } catch (err) {
    console.error('Erro ao trocar senha:', err);
    return { sucesso: false, mensagem: traduzErroAuth(err.code) };
  }
}

export function confirmarAcaoPublica({ titulo, mensagem, textoBotao = 'Confirmar', classeBotao = 'btn-danger', aoConfirmar }) {
  const root = document.getElementById('modalRoot');
  root.insertAdjacentHTML('beforeend', `
    <div class="modal-overlay" id="confirmAcaoPublicaOverlay">
      <div class="modal" style="max-width:400px;">
        <div class="modal-form">
          <h2 style="font-size:22px;">${titulo}</h2>
          <p style="margin-top:10px;">${mensagem}</p>
          <div class="modal-actions">
            <button class="btn btn-ghost" id="confirmAcaoPublicaCancelar">Cancelar</button>
            <button class="btn ${classeBotao}" id="confirmAcaoPublicaOk">${textoBotao}</button>
          </div>
        </div>
      </div>
    </div>`);

  const overlay = document.getElementById('confirmAcaoPublicaOverlay');
  document.getElementById('confirmAcaoPublicaCancelar').addEventListener('click', () => overlay.remove());
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.getElementById('confirmAcaoPublicaOk').addEventListener('click', async () => {
    const btn = document.getElementById('confirmAcaoPublicaOk');
    btn.disabled = true;
    btn.textContent = 'Aguarde...';
    try {
      await aoConfirmar();
      overlay.remove();
    } catch (err) {
      console.error(err);
      btn.disabled = false;
      btn.textContent = textoBotao;
    }
  });
}

/* ============================================================================
   MODAL DE LOGIN DO CLIENTE (com "Esqueci minha senha")
   ============================================================================ */
export function abrirModalLoginCliente({ mensagem, aoAutenticar } = {}) {
  const root = document.getElementById('modalRoot');
  let modoCadastro = false;

  function mostrarMsg(msg, ehErro = true) {
    const el = document.getElementById('loginClienteErro');
    if (!el) return;
    el.textContent = msg;
    el.style.display = 'block';
    el.style.color = ehErro ? 'var(--danger)' : 'var(--gold-bright)';
  }

  function render() {
    root.innerHTML = `
      <div class="modal-overlay" id="loginClienteOverlay">
        <div class="modal" style="max-width:420px;">
          <div class="modal-form">
            <button class="modal-close" id="closeLoginCliente">✕</button>
            <h2 style="font-size:24px;margin-bottom:6px;">${modoCadastro ? 'Criar conta' : 'Entrar'}</h2>
            ${mensagem ? `<p class="cell-muted" style="margin-bottom:18px;">${mensagem}</p>` : '<div style="margin-bottom:18px;"></div>'}
            <div class="login-error" id="loginClienteErro" style="display:none;"></div>
            <form id="loginClienteForm">
              <div class="field">
                <label>E-mail</label>
                <input type="email" id="loginClienteEmail" required>
              </div>
              <div class="field">
                <label>Senha</label>
                <input type="password" id="loginClienteSenha" required minlength="6">
              </div>
              <button type="submit" class="btn btn-gold" style="width:100%;justify-content:center;" id="loginClienteSubmitBtn">
                ${modoCadastro ? 'Criar conta' : 'Entrar'}
              </button>
            </form>
            <button type="button" class="btn btn-ghost" id="googleClienteBtn" style="width:100%;justify-content:center;margin-top:10px;">Continuar com Google</button>
            <p style="text-align:center;font-size:12px;margin-top:16px;">
              ${modoCadastro
                ? 'Já tem conta? <a href="#" id="toggleParaLogin">Entrar</a>'
                : 'Ainda não tem conta? <a href="#" id="toggleParaCadastro">Criar conta</a>'}
            </p>
            ${!modoCadastro ? `
              <p style="text-align:center;font-size:12px;margin-top:6px;">
                <a href="#" id="esqueciSenhaCliente">Esqueci minha senha</a>
              </p>
            ` : ''}
          </div>
        </div>
      </div>`;

    const overlay = document.getElementById('loginClienteOverlay');
    document.getElementById('closeLoginCliente').addEventListener('click', () => root.innerHTML = '');

    const toggleCadastro = document.getElementById('toggleParaCadastro');
    if (toggleCadastro) toggleCadastro.addEventListener('click', (e) => { e.preventDefault(); modoCadastro = true; render(); });
    const toggleLogin = document.getElementById('toggleParaLogin');
    if (toggleLogin) toggleLogin.addEventListener('click', (e) => { e.preventDefault(); modoCadastro = false; render(); });

    // Esqueci minha senha
    const esqueciSenha = document.getElementById('esqueciSenhaCliente');
    if (esqueciSenha) {
      esqueciSenha.addEventListener('click', async (e) => {
        e.preventDefault();
        const email = document.getElementById('loginClienteEmail').value.trim();
        if (!email) { mostrarMsg('Digite seu e-mail no campo acima primeiro.'); return; }
        try {
          await sendPasswordResetEmail(auth, email);
          mostrarMsg(`Enviamos um link de redefinição de senha para ${email}.`, false);
        } catch (err) { mostrarMsg(traduzErroAuth(err.code)); }
      });
    }

    document.getElementById('googleClienteBtn').addEventListener('click', async () => {
      try {
        const cred = await signInWithPopup(auth, googleProvider);
        root.innerHTML = '';
        if (aoAutenticar) aoAutenticar(cred.user);
      } catch (err) {
        mostrarMsg(traduzErroAuth(err.code));
      }
    });

    document.getElementById('loginClienteForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const btn = document.getElementById('loginClienteSubmitBtn');
      btn.disabled = true;
      btn.textContent = modoCadastro ? 'Criando...' : 'Entrando...';
      const email = document.getElementById('loginClienteEmail').value.trim();
      const senha = document.getElementById('loginClienteSenha').value;
      try {
        const cred = modoCadastro
          ? await createUserWithEmailAndPassword(auth, email, senha)
          : await signInWithEmailAndPassword(auth, email, senha);
        root.innerHTML = '';
        if (aoAutenticar) aoAutenticar(cred.user);
      } catch (err) {
        mostrarMsg(traduzErroAuth(err.code));
        btn.disabled = false;
        btn.textContent = modoCadastro ? 'Criar conta' : 'Entrar';
      }
    });
  }

  render();
}

/* ============================================================================
   MODAL "MINHA CONTA" (com troca de senha)
   ============================================================================ */
export async function abrirModalMinhaConta({ aoSalvarPerfil, aoAbrirPedidos } = {}) {
  const user = auth.currentUser;
  if (!user) return;
  const root = document.getElementById('modalRoot');
  let perfil = (await carregarPerfilCliente(user.uid)) || { nome: '', telefone: '', enderecos: [] };
  let formEnderecoAberto = null;
  let instanciaFormEndereco = null;

  function blocoEnderecos() {
    const lista = perfil.enderecos || [];
    const listaHtml = lista.map(e => `
      <div style="border:1px solid var(--border-soft);border-radius:var(--radius);padding:10px 12px;margin-bottom:8px;">
        <strong style="font-size:13px;color:var(--ivory);">${e.label || 'Endereço'}</strong>
        ${e.principal ? '<span class="badge badge-ok" style="margin-left:6px;">Principal</span>' : ''}
        <div class="cell-muted" style="font-size:12px;margin-top:2px;">${e.endereco}</div>
        <div style="display:flex;gap:8px;margin-top:8px;flex-wrap:wrap;">
          ${!e.principal ? `<button type="button" class="btn btn-ghost btn-sm" data-tornar-principal="${e.id}">Tornar principal</button>` : ''}
          <button type="button" class="btn btn-ghost btn-sm" data-editar-endereco="${e.id}">Editar</button>
          <button type="button" class="btn btn-ghost btn-sm" style="color:var(--danger);" data-remover-endereco="${e.id}">Remover</button>
        </div>
      </div>
    `).join('');

    return `
      <div id="enderecosLista">${listaHtml || '<p class="cell-muted" style="font-size:13px;">Nenhum endereço salvo ainda.</p>'}</div>
      ${formEnderecoAberto ? `
        <div style="margin-top:10px;">
          <div class="login-error" id="erroEnderecoMinhaConta" style="display:none;"></div>
          <div id="formEnderecoEstruturadoMinhaConta"></div>
          <button type="button" class="btn btn-gold btn-sm" id="btnSalvarEndereco" style="margin-top:8px;">Salvar endereço</button>
          <button type="button" class="btn btn-ghost btn-sm" id="btnCancelarEndereco">Cancelar</button>
        </div>
      ` : `<button type="button" class="btn btn-ghost btn-sm" id="btnAddEndereco" style="margin-top:4px;">+ Adicionar endereço</button>`}
    `;
  }

  function render() {
    root.innerHTML = `
      <div class="modal-overlay" id="minhaContaOverlay">
        <div class="modal" style="max-width:520px;">
          <div class="modal-form">
            <button class="modal-close" id="closeMinhaConta">✕</button>
            <h2 style="font-size:24px;margin-bottom:4px;">Minha conta</h2>
            <p class="cell-muted" style="margin-bottom:20px;">${user.email || ''}</p>
            <form id="perfilClienteForm">
              <div class="field">
                <label>Nome</label>
                <input type="text" id="perfilNome" value="${perfil.nome || ''}">
              </div>
              <div class="field">
                <label>Telefone / WhatsApp</label>
                <input type="text" id="perfilTelefone" value="${perfil.telefone || ''}">
              </div>
              <button type="submit" class="btn btn-gold" style="width:100%;justify-content:center;">Salvar dados</button>
            </form>

            <div class="divider"><span class="diamond">◆</span></div>
            <h3 style="font-size:15px;margin-bottom:10px;">Meus endereços</h3>
            <div id="blocoEnderecosWrap">${blocoEnderecos()}</div>

            <div class="divider"><span class="diamond">◆</span></div>
            <h3 style="font-size:15px;margin-bottom:10px;">Alterar senha</h3>
            <form id="formTrocaSenha">
              <div class="field">
                <label>Senha atual *</label>
                <input type="password" id="senhaAtual" required>
              </div>
              <div class="field">
                <label>Nova senha *</label>
                <input type="password" id="novaSenha" required minlength="6">
              </div>
              <div class="field">
                <label>Confirmar nova senha *</label>
                <input type="password" id="confirmarSenha" required>
              </div>
              <button type="submit" class="btn btn-gold" style="width:100%;justify-content:center;">Alterar senha</button>
            </form>

            <div class="divider"><span class="diamond">◆</span></div>
            <button type="button" class="btn btn-ghost" id="btnMeusPedidosConta" style="width:100%;justify-content:center;">Meus pedidos</button>
            <button type="button" class="btn btn-ghost" id="btnSairConta" style="width:100%;justify-content:center;margin-top:8px;color:var(--danger);">Sair da conta</button>
          </div>
        </div>
      </div>`;

    wireEventos();
  }

  function rerenderEnderecos() {
    document.getElementById('blocoEnderecosWrap').innerHTML = blocoEnderecos();
    wireEventosEnderecos();
  }

  function wireEventosEnderecos() {
    const btnAdd = document.getElementById('btnAddEndereco');
    if (btnAdd) btnAdd.addEventListener('click', () => { formEnderecoAberto = 'novo'; rerenderEnderecos(); });

    const btnCancelar = document.getElementById('btnCancelarEndereco');
    if (btnCancelar) btnCancelar.addEventListener('click', () => { formEnderecoAberto = null; instanciaFormEndereco = null; rerenderEnderecos(); });

    const containerForm = document.getElementById('formEnderecoEstruturadoMinhaConta');
    if (containerForm) {
      const editando = formEnderecoAberto !== 'novo' ? (perfil.enderecos || []).find(e => e.id === formEnderecoAberto) : null;
      instanciaFormEndereco = montarFormularioEndereco(containerForm, editando || {});
    }

    const btnSalvar = document.getElementById('btnSalvarEndereco');
    if (btnSalvar) {
      btnSalvar.addEventListener('click', async () => {
        if (!instanciaFormEndereco) return;
        const erroEl = document.getElementById('erroEnderecoMinhaConta');
        const erro = instanciaFormEndereco.validar();
        if (erro) {
          erroEl.textContent = erro;
          erroEl.style.display = 'block';
          return;
        }
        erroEl.style.display = 'none';
        const dados = instanciaFormEndereco.ler();
        btnSalvar.disabled = true;
        btnSalvar.textContent = 'Salvando...';
        const idParaEditar = formEnderecoAberto !== 'novo' ? formEnderecoAberto : null;
        try {
          const { lista } = await salvarEndereco(user.uid, perfil.enderecos, { id: idParaEditar, ...dados });
          perfil = { ...perfil, enderecos: lista };
          formEnderecoAberto = null;
          instanciaFormEndereco = null;
          rerenderEnderecos();
        } catch (err) {
          console.error(err);
          erroEl.textContent = 'Não foi possível salvar. Tente de novo.';
          erroEl.style.display = 'block';
          btnSalvar.disabled = false;
          btnSalvar.textContent = 'Salvar endereço';
        }
      });
    }

    document.querySelectorAll('[data-tornar-principal]').forEach(btn => {
      btn.addEventListener('click', async () => {
        const lista = await definirEnderecoPrincipal(user.uid, perfil.enderecos, btn.dataset.tornarPrincipal);
        perfil = { ...perfil, enderecos: lista };
        rerenderEnderecos();
      });
    });
    document.querySelectorAll('[data-remover-endereco]').forEach(btn => {
      btn.addEventListener('click', () => {
        confirmarAcaoPublica({
          titulo: 'Remover endereço?',
          mensagem: 'Essa ação não pode ser desfeita.',
          textoBotao: 'Remover',
          aoConfirmar: async () => {
            const lista = await removerEndereco(user.uid, perfil.enderecos, btn.dataset.removerEndereco);
            perfil = { ...perfil, enderecos: lista };
            rerenderEnderecos();
          },
        });
      });
    });
    document.querySelectorAll('[data-editar-endereco]').forEach(btn => {
      btn.addEventListener('click', () => { formEnderecoAberto = btn.dataset.editarEndereco; rerenderEnderecos(); });
    });
  }

  function wireEventos() {
    const overlay = document.getElementById('minhaContaOverlay');
    document.getElementById('closeMinhaConta').addEventListener('click', () => root.innerHTML = '');
    overlay.addEventListener('click', (e) => { if (e.target === overlay) root.innerHTML = ''; });

    document.getElementById('perfilClienteForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const dados = {
        nome: document.getElementById('perfilNome').value.trim(),
        telefone: document.getElementById('perfilTelefone').value.trim(),
      };
      await salvarPerfilCliente(user.uid, dados);
      root.innerHTML = '';
      if (aoSalvarPerfil) aoSalvarPerfil(dados);
    });

    // Troca de senha
    document.getElementById('formTrocaSenha').addEventListener('submit', async (e) => {
      e.preventDefault();
      const senhaAtual = document.getElementById('senhaAtual').value;
      const novaSenha = document.getElementById('novaSenha').value;
      const confirmar = document.getElementById('confirmarSenha').value;

      if (novaSenha !== confirmar) {
        mostrarToast('As senhas não coincidem.', true);
        return;
      }
      if (novaSenha.length < 6) {
        mostrarToast('A senha precisa ter pelo menos 6 caracteres.', true);
        return;
      }

      try {
        const credential = EmailAuthProvider.credential(user.email, senhaAtual);
        await reauthenticateWithCredential(user, credential);
        await updatePassword(user, novaSenha);
        mostrarToast('Senha alterada com sucesso!');
        document.getElementById('senhaAtual').value = '';
        document.getElementById('novaSenha').value = '';
        document.getElementById('confirmarSenha').value = '';
      } catch (err) {
        console.error('Erro ao trocar senha:', err);
        if (err.code === 'auth/wrong-password') {
          mostrarToast('Senha atual incorreta.', true);
        } else if (err.code === 'auth/requires-recent-login') {
          mostrarToast('É necessário fazer login novamente para esta operação.', true);
        } else {
          mostrarToast('Erro ao alterar senha. Tente novamente.', true);
        }
      }
    });

    document.getElementById('btnSairConta').addEventListener('click', async () => {
      await sairDaConta();
      root.innerHTML = '';
      window.location.reload();
    });

    document.getElementById('btnMeusPedidosConta').addEventListener('click', () => {
      root.innerHTML = '';
      if (aoAbrirPedidos) aoAbrirPedidos();
    });

    wireEventosEnderecos();
  }

  function mostrarToast(msg, erro = false) {
    const el = document.createElement('div');
    el.className = 'toast' + (erro ? ' error' : '');
    el.innerHTML = `<span class="dot"></span>${msg}`;
    document.body.appendChild(el);
    requestAnimationFrame(() => el.classList.add('show'));
    setTimeout(() => { el.classList.remove('show'); setTimeout(() => el.remove(), 300); }, 3200);
  }

  render();
}