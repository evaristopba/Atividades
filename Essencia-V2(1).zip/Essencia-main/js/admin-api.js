import { auth } from './firebase-config.js';

async function chamarApiAdmin(action, payload) {
  const user = auth.currentUser;
  if (!user) throw new Error('Sessão expirada. Faça login novamente.');

  const idToken = await user.getIdToken();
  let resp;
  try {
    resp = await fetch('/api/gerenciar-admin', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${idToken}` },
      body: JSON.stringify({ action, payload }),
    });
  } catch (err) {
    throw new Error('Não foi possível contatar o servidor. Verifique sua conexão e tente novamente.');
  }

  // 404 aqui quase sempre significa que a função serverless /api/gerenciar-admin
  // não está disponível neste ambiente — isso acontece quando o site é aberto
  // direto de um servidor estático local (ex: "python -m http.server") ou
  // publicado fora da Vercel. Ver README.md, seção "Testando localmente".
  if (resp.status === 404) {
    throw new Error('Função de administradores não encontrada (404). Isso acontece quando o site não está rodando na Vercel — em ambiente local, use "vercel dev" em vez de um servidor estático simples. Se já estiver publicado, confirme que a pasta api/ foi enviada ao repositório.');
  }

  let data = {};
  try { data = await resp.json(); } catch (e) { /* resposta vazia */ }

  if (!resp.ok) {
    throw new Error(data.error || `Erro ao comunicar com o servidor (${resp.status}).`);
  }
  return data;
}

async function chamarApiComToken(url, payload) {
  const user = auth.currentUser;
  if (!user) throw new Error('Sessão expirada. Faça login novamente.');
  const idToken = await user.getIdToken();
  const resp = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${idToken}` },
    body: JSON.stringify(payload),
  });
  let data = {};
  try { data = await resp.json(); } catch (e) { /* resposta vazia */ }
  if (!resp.ok) throw new Error(data.error || `Erro ao comunicar com o servidor (${resp.status}).`);
  return data;
}

export const adminApi = {
  bootstrap: () => chamarApiAdmin('bootstrap'),
  listar: () => chamarApiAdmin('listar'),
  criar: (payload) => chamarApiAdmin('criar', payload),
  atualizarPapel: (uid, role) => chamarApiAdmin('atualizarPapel', { uid, role }),
  excluir: (uid) => chamarApiAdmin('excluir', { uid }),
  enviarNotificacao: (payload) => chamarApiComToken('/api/enviar-notificacao', payload),
  notificarPedido: (pedidoId, status) => chamarApiComToken('/api/notificar-pedido', { pedidoId, status }),
};
