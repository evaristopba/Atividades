// ============================================================================
// js/admin.js - PAINEL ADMINISTRATIVO COMPLETO
// ============================================================================
// VERSÃO COM:
// - Campo produtoIds para consulta reversa
// - Verificação de integridade referencial corrigida
// - Scroll apenas na tabela
// - Botão EXCLUIR para vendas CANCELADAS (item.status === 'pendente' || item.status === 'cancelada')
// ============================================================================

import {
  db, auth, googleProvider,
  collection, getDocs, addDoc, updateDoc, deleteDoc, doc, getDoc, setDoc, serverTimestamp,
  query, where, limit, runTransaction,
  signInWithEmailAndPassword, signOut, onAuthStateChanged, sendPasswordResetEmail,
  signInWithPopup
} from './firebase-config.js';
import { adminApi } from './admin-api.js';
import { gerarPayloadPix } from './pix.js';
import { escapeHtml, isDataUriComprovanteValida } from './seguranca.js';
import { precoEfetivo } from './promocao.js';

/* ============================================================================
   AUTENTICAÇÃO
   ============================================================================ */
const loginScreen = document.getElementById('loginScreen');
const adminShell = document.getElementById('adminShell');
const loginForm = document.getElementById('loginForm');
const loginError = document.getElementById('loginError');
const loginInfo = document.getElementById('loginInfo');
const loginBtn = document.getElementById('loginBtn');
const userEmail = document.getElementById('userEmail');
const userRoleEl = document.getElementById('userRole');

let meuPapel = null;

loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  loginError.style.display = 'none';
  loginInfo.style.display = 'none';
  loginBtn.disabled = true;
  loginBtn.textContent = 'Entrando...';
  const email = document.getElementById('loginEmail').value.trim();
  const password = document.getElementById('loginPassword').value;
  try {
    await signInWithEmailAndPassword(auth, email, password);
  } catch (err) {
    console.error('Erro de login (e-mail/senha):', err.code, err.message);
    loginError.textContent = traduzErroAuth(err.code);
    loginError.style.display = 'block';
  } finally {
    loginBtn.disabled = false;
    loginBtn.textContent = 'Entrar';
  }
});

document.getElementById('googleLoginBtn').addEventListener('click', async () => {
  loginError.style.display = 'none';
  loginInfo.style.display = 'none';
  const btn = document.getElementById('googleLoginBtn');
  const originalText = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = 'Entrando...';
  try {
    await signInWithPopup(auth, googleProvider);
  } catch (err) {
    console.error('Erro de login (Google):', err.code, err.message);
    loginError.textContent = traduzErroAuth(err.code);
    loginError.style.display = 'block';
  } finally {
    btn.disabled = false;
    btn.innerHTML = originalText;
  }
});

document.getElementById('forgotPasswordLink').addEventListener('click', async (e) => {
  e.preventDefault();
  loginError.style.display = 'none';
  loginInfo.style.display = 'none';
  const email = document.getElementById('loginEmail').value.trim();
  if (!email) {
    loginError.textContent = 'Digite seu e-mail no campo acima primeiro, depois clique em "Esqueci minha senha".';
    loginError.style.display = 'block';
    return;
  }
  try {
    await sendPasswordResetEmail(auth, email);
    loginInfo.textContent = `Enviamos um link de redefinição de senha para ${email}. Confira também a caixa de spam.`;
    loginInfo.style.display = 'block';
  } catch (err) {
    loginError.textContent = traduzErroAuth(err.code);
    loginError.style.display = 'block';
  }
});

document.getElementById('logoutBtn').addEventListener('click', () => signOut(auth));
const logoutBtnMobile = document.getElementById('logoutBtnMobile');
if (logoutBtnMobile) logoutBtnMobile.addEventListener('click', () => signOut(auth));

function traduzErroAuth(code) {
  const map = {
    'auth/invalid-credential': 'E-mail ou senha incorretos.',
    'auth/user-not-found': 'Usuário não encontrado.',
    'auth/wrong-password': 'Senha incorreta.',
    'auth/too-many-requests': 'Muitas tentativas. Aguarde um instante.',
    'auth/invalid-email': 'E-mail inválido.',
    'auth/popup-closed-by-user': 'A janela de login foi fechada. Tente novamente.',
    'auth/cancelled-popup-request': 'Múltiplas janelas de login abertas. Tente novamente.',
    'auth/account-exists-with-different-credential': 'Já existe uma conta com este e-mail usando outro método de login.',
    'auth/popup-blocked': 'O navegador bloqueou a janela de login. Permita popups e tente novamente.',
    'auth/network-request-failed': 'Falha de conexão. Verifique sua internet.',
    'auth/internal-error': 'Erro interno do Firebase. Tente novamente.',
    'auth/invalid-api-key': 'Chave de API do Firebase inválida. Verifique js/firebase-config.js.',
    'auth/invalid-user-token': 'Sessão inválida. Limpe o cache e tente novamente.',
    'auth/user-disabled': 'Esta conta foi desativada.',
    'auth/operation-not-allowed': 'Login por e-mail/senha não está ativado no Firebase Console.',
    'auth/weak-password': 'Senha muito fraca.',
    'auth/email-already-in-use': 'Este e-mail já está em uso.',
    'auth/requires-recent-login': 'É necessário fazer login novamente para esta operação.'
  };
  return map[code] || `[${code}] Não foi possível concluir. Verifique os dados e tente novamente.`;
}

onAuthStateChanged(auth, async (user) => {
  if (user) {
    loginScreen.style.display = 'none';
    userEmail.textContent = user.email;
    const role = await resolverPapel(user);

    if (!role) {
      adminShell.style.display = 'none';
      document.getElementById('acessoNegadoEmail').textContent = user.email || '';
      document.getElementById('acessoNegadoScreen').style.display = 'flex';
      return;
    }

    document.getElementById('acessoNegadoScreen').style.display = 'none';
    adminShell.style.display = 'flex';
    initAdmin();
  } else {
    loginScreen.style.display = 'flex';
    adminShell.style.display = 'none';
    document.getElementById('acessoNegadoScreen').style.display = 'none';
    meuPapel = null;
  }
});

document.getElementById('acessoNegadoSairBtn').addEventListener('click', () => signOut(auth));

/* ============================================================================
   PAPEL (owner / operador)
   ============================================================================ */
async function resolverPapel(user) {
  let tokenResult = await user.getIdTokenResult(true);
  let role = tokenResult.claims.role || null;

  if (!role) {
    try {
      await adminApi.bootstrap();
      tokenResult = await user.getIdTokenResult(true);
      role = tokenResult.claims.role || null;
    } catch (err) {
      console.warn('Bootstrap não aplicado:', err.message);
    }
  }

  meuPapel = role;
  userRoleEl.textContent = role === 'owner' ? 'Proprietário' : role === 'operador' ? 'Operador' : 'Sem papel definido';

  document.getElementById('linkAdministradores').style.display = role === 'owner' ? '' : 'none';
  document.getElementById('linkConfiguracoes').style.display = role === 'owner' ? '' : 'none';
  document.getElementById('linkNotificacoes').style.display = role === 'owner' ? '' : 'none';

  return role;
}

/* ============================================================================
   ESTADOS BRASILEIROS
   ============================================================================ */
const UF_LIST = [
  ['AC', 'Acre'], ['AL', 'Alagoas'], ['AP', 'Amapá'], ['AM', 'Amazonas'],
  ['BA', 'Bahia'], ['CE', 'Ceará'], ['DF', 'Distrito Federal'], ['ES', 'Espírito Santo'],
  ['GO', 'Goiás'], ['MA', 'Maranhão'], ['MT', 'Mato Grosso'], ['MS', 'Mato Grosso do Sul'],
  ['MG', 'Minas Gerais'], ['PA', 'Pará'], ['PB', 'Paraíba'], ['PR', 'Paraná'],
  ['PE', 'Pernambuco'], ['PI', 'Piauí'], ['RJ', 'Rio de Janeiro'], ['RN', 'Rio Grande do Norte'],
  ['RS', 'Rio Grande do Sul'], ['RO', 'Rondônia'], ['RR', 'Roraima'], ['SC', 'Santa Catarina'],
  ['SP', 'São Paulo'], ['SE', 'Sergipe'], ['TO', 'Tocantins']
];

/* ============================================================================
   CONFIGURAÇÃO DAS ENTIDADES
   ============================================================================ */
const ENTIDADES = {
  categorias: {
    titulo: 'Categorias',
    tituloNovo: 'Nova categoria',
    colecao: 'categorias',
    colunas: [
      { key: 'nome', label: 'Nome' },
      { key: 'descricao', label: 'Descrição' }
    ],
    campos: [
      { key: 'nome', tipo: 'text', label: 'Nome', obrigatorio: true, largura: 'full' },
      { key: 'descricao', tipo: 'textarea', label: 'Descrição (opcional)', largura: 'full' }
    ],
    buscaCampos: ['nome', 'descricao']
  },
  produtos: {
    titulo: 'Produtos',
    tituloNovo: 'Novo produto',
    colecao: 'produtos',
    colunas: [
      { key: 'foto', label: '' },
      { key: 'nome', label: 'Produto' },
      { key: 'marca', label: 'Marca' },
      { key: 'categoriaNome', label: 'Categoria' },
      { key: 'preco', label: 'À vista / Prazo' },
      { key: 'estoque', label: 'Estoque' },
      { key: 'status', label: 'Status' }
    ],
    campos: [
      { key: 'fotos', tipo: 'galeria-fotos', label: 'Fotos do produto (até 4 — a primeira é a capa)' },
      { key: 'nome', tipo: 'text', label: 'Nome', obrigatorio: true, largura: 'full' },
      { key: 'marca', tipo: 'text', label: 'Marca' },
      { key: 'categoriaId', tipo: 'select-categoria', label: 'Categoria', obrigatorio: true },
      { key: 'volume', tipo: 'text', label: 'Volume', placeholder: 'Ex: 100ml' },
      { key: 'valorAVista', tipo: 'number', label: 'Valor à vista (R$)', obrigatorio: true },
      { key: 'emPromocao', tipo: 'checkbox', label: 'Produto em promoção', padrao: false },
      { key: 'valorPromocional', tipo: 'number', label: 'Valor promocional (R$)', placeholder: 'Deixe vazio se não estiver em promoção' },
      { key: 'valorPrazo', tipo: 'number', label: 'Valor a prazo (R$)' },
      { key: 'parcelas', tipo: 'number', label: 'Nº de parcelas' },
      { key: 'estoque', tipo: 'number', label: 'Estoque (unidades)' },
      { key: 'fornecedorId', tipo: 'select-fornecedor', label: 'Fornecedor' },
      { key: 'ativo', tipo: 'checkbox', label: 'Visível no catálogo público', padrao: true },
      { key: 'descricao', tipo: 'textarea', label: 'Descrição', largura: 'full' }
    ],
    buscaCampos: ['nome', 'marca', 'categoriaNome']
  },
  clientes: {
    titulo: 'Clientes',
    tituloNovo: 'Novo cliente',
    colecao: 'clientes',
    colunas: [
      { key: 'nome', label: 'Nome' },
      { key: 'telefone', label: 'Telefone' },
      { key: 'email', label: 'E-mail' },
      { key: 'cpf', label: 'CPF' },
      { key: 'cidadeUf', label: 'Cidade / UF' }
    ],
    campos: [
      { key: 'nome', tipo: 'text', label: 'Nome completo', obrigatorio: true, largura: 'full' },
      { key: 'telefone', tipo: 'text', label: 'Telefone', placeholder: '(11) 99999-0000' },
      { key: 'email', tipo: 'email', label: 'E-mail' },
      { key: 'cpf', tipo: 'text', label: 'CPF' },
      { key: 'cep', tipo: 'cep', label: 'CEP', placeholder: '00000-000' },
      { key: 'uf', tipo: 'uf', label: 'UF' },
      { key: 'cidade', tipo: 'cidade', label: 'Cidade' },
      { key: 'endereco', tipo: 'text', label: 'Endereço (rua, número, bairro)', largura: 'full' },
      { key: 'observacoes', tipo: 'textarea', label: 'Observações', largura: 'full' }
    ],
    buscaCampos: ['nome', 'email', 'telefone', 'cpf', 'cidade']
  },
  fornecedores: {
    titulo: 'Fornecedores',
    tituloNovo: 'Novo fornecedor',
    colecao: 'fornecedores',
    colunas: [
      { key: 'nome', label: 'Nome / Razão social' },
      { key: 'contato', label: 'Contato' },
      { key: 'telefone', label: 'Telefone' },
      { key: 'email', label: 'E-mail' },
      { key: 'cidadeUf', label: 'Cidade / UF' }
    ],
    campos: [
      { key: 'nome', tipo: 'text', label: 'Nome / Razão social', obrigatorio: true, largura: 'full' },
      { key: 'contato', tipo: 'text', label: 'Pessoa de contato' },
      { key: 'telefone', tipo: 'text', label: 'Telefone' },
      { key: 'email', tipo: 'email', label: 'E-mail' },
      { key: 'cnpj', tipo: 'text', label: 'CNPJ' },
      { key: 'cep', tipo: 'cep', label: 'CEP', placeholder: '00000-000' },
      { key: 'uf', tipo: 'uf', label: 'UF' },
      { key: 'cidade', tipo: 'cidade', label: 'Cidade' },
      { key: 'endereco', tipo: 'text', label: 'Endereço (rua, número, bairro)', largura: 'full' },
      { key: 'observacoes', tipo: 'textarea', label: 'Observações', largura: 'full' }
    ],
    buscaCampos: ['nome', 'contato', 'email', 'cidade']
  }
};

let abaAtual = 'categorias';
let dadosCache = { categorias: [], produtos: [], clientes: [], fornecedores: [] };
// Estado do formulário de produto em edição: array de fotos (data-URIs em
// base64), na ordem em que aparecem na galeria — a primeira é a capa
// (mesmo papel que fotoUrl sempre teve, mantido por compatibilidade — ver
// comentário em salvarEntidade).
let fotosSelecionadas = [];
const MAX_FOTOS_PRODUTO = 4;

/* ============================================================================
   COMPRESSÃO DE IMAGEM
   ============================================================================ */
// AJUSTADO: valores reduzidos em relação à versão de foto única, porque
// agora até MAX_FOTOS_PRODUTO fotos precisam caber juntas no limite de 1MB
// de um documento do Firestore (arquitetura atual: fotos ficam em base64
// dentro do próprio documento, sem serviço de storage separado — decisão
// consciente para não depender de um plano pago). 4 fotos × ~180KB ≈ 720KB,
// com folga para os demais campos do produto.
const FOTO_LADO_MAX = 480;
const FOTO_QUALIDADE_INICIAL = 0.65;
const FOTO_QUALIDADE_MIN = 0.35;
const FOTO_TAMANHO_ALVO_KB = 180;
const FOTO_TAMANHO_MAX_KB = 700;

function comprimirImagem(file) {
  return new Promise((resolve, reject) => {
    const leitor = new FileReader();
    leitor.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;
        if (width > height && width > FOTO_LADO_MAX) {
          height = Math.round(height * (FOTO_LADO_MAX / width));
          width = FOTO_LADO_MAX;
        } else if (height > FOTO_LADO_MAX) {
          width = Math.round(width * (FOTO_LADO_MAX / height));
          height = FOTO_LADO_MAX;
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        canvas.getContext('2d').drawImage(img, 0, 0, width, height);

        let qualidade = FOTO_QUALIDADE_INICIAL;
        let base64 = canvas.toDataURL('image/jpeg', qualidade);
        while (tamanhoBase64KB(base64) > FOTO_TAMANHO_ALVO_KB && qualidade > FOTO_QUALIDADE_MIN) {
          qualidade = Math.round((qualidade - 0.08) * 100) / 100;
          base64 = canvas.toDataURL('image/jpeg', qualidade);
        }
        resolve(base64);
      };
      img.onerror = () => reject(new Error('Não foi possível ler a imagem.'));
      img.src = e.target.result;
    };
    leitor.onerror = () => reject(new Error('Não foi possível ler o arquivo.'));
    leitor.readAsDataURL(file);
  });
}

function tamanhoBase64KB(base64) {
  return Math.round((base64.length * 0.75) / 1024);
}

/* ============================================================================
   ENDEREÇO: UF → cidades e CEP → endereço
   ============================================================================ */
async function carregarCidadesPorUf(uf, cidadeParaSelecionar, selectEl) {
  selectEl = selectEl || document.getElementById('campo_cidade');
  if (!selectEl) return;
  if (!uf) {
    selectEl.innerHTML = '<option value="">Selecione o UF primeiro</option>';
    selectEl.disabled = true;
    return;
  }
  selectEl.disabled = true;
  selectEl.innerHTML = '<option value="">Carregando cidades...</option>';
  try {
    const resp = await fetch(`https://servicodados.ibge.gov.br/api/v1/localidades/estados/${uf}/municipios`);
    if (!resp.ok) throw new Error('Falha ao consultar a lista de cidades do IBGE.');
    const municipios = await resp.json();
    const nomes = municipios.map(m => m.nome).sort((a, b) => a.localeCompare(b, 'pt-BR'));
    selectEl.innerHTML = '<option value="">Selecione a cidade</option>' +
      nomes.map(n => `<option value="${n}" ${n === cidadeParaSelecionar ? 'selected' : ''}>${n}</option>`).join('');
    selectEl.disabled = false;
  } catch (err) {
    console.error('Erro ao carregar cidades do IBGE:', err);
    selectEl.innerHTML = `<option value="${cidadeParaSelecionar || ''}">${cidadeParaSelecionar || 'Não foi possível carregar as cidades'}</option>`;
    selectEl.disabled = false;
  }
}

async function buscarEnderecoPorCep(cepDigitado, campos) {
  const cep = (cepDigitado || '').replace(/\D/g, '');
  const hint = document.getElementById('cepHint');
  if (cep.length !== 8) return;
  if (hint) { hint.textContent = 'Buscando endereço pelo CEP...'; hint.classList.remove('error'); }
  try {
    const resp = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
    const data = await resp.json();
    if (data.erro) {
      if (hint) { hint.textContent = 'CEP não encontrado — preencha manualmente.'; hint.classList.add('error'); }
      return;
    }
    if (campos.uf && data.uf) {
      campos.uf.value = data.uf;
      await carregarCidadesPorUf(data.uf, data.localidade, campos.cidade);
    }
    if (campos.endereco && !campos.endereco.value && data.logradouro) {
      campos.endereco.value = [data.logradouro, data.bairro].filter(Boolean).join(', ');
    }
    if (hint) { hint.textContent = 'Endereço preenchido a partir do CEP.'; hint.classList.remove('error'); }
  } catch (err) {
    console.error('Erro ao buscar CEP:', err);
    if (hint) { hint.textContent = 'Não foi possível consultar o CEP agora — preencha manualmente.'; hint.classList.add('error'); }
  }
}

/* ============================================================================
   NAVEGAÇÃO ENTRE ABAS
   ============================================================================ */
function initAdmin() {
  document.querySelectorAll('.side-link').forEach(link => {
    link.addEventListener('click', () => trocarAba(link.dataset.tab));
  });
  document.getElementById('addBtn').addEventListener('click', () => abrirFormulario(abaAtual, null));
  document.getElementById('adminSearch').addEventListener('input', renderTabela);
  document.getElementById('addAdminBtn').addEventListener('click', abrirFormNovoAdmin);
  document.getElementById('addVendaBtn').addEventListener('click', () => abrirFormMovimento('vendas'));
  document.getElementById('addCompraBtn').addEventListener('click', () => abrirFormMovimento('compras'));
  carregarTudo();
}

async function carregarTudo() {
  for (const chave of Object.keys(ENTIDADES)) {
    await carregarColecao(chave);
  }
  trocarAba('categorias');
}

async function carregarColecao(chave) {
  try {
    const snap = await getDocs(collection(db, ENTIDADES[chave].colecao));
    dadosCache[chave] = snap.docs.map(d => ({ id: d.id, ...d.data() }));
  } catch (err) {
    console.error(`Erro ao carregar ${chave}:`, err);
    if (err.code === 'permission-denied') {
      mostrarToast(`Sem permissão para acessar ${ENTIDADES[chave].titulo}. Se você acabou de ganhar acesso, saia e faça login de novo.`, true);
    } else {
      mostrarToast('Erro ao carregar dados. Verifique as regras do Firestore.', true);
    }
  }
}

function trocarAba(chave) {
  if ((chave === 'administradores' || chave === 'configuracoes' || chave === 'notificacoes') && meuPapel !== 'owner') {
    chave = 'categorias';
  }

  abaAtual = chave;
  document.querySelectorAll('.side-link').forEach(l => l.classList.toggle('active', l.dataset.tab === chave));
  document.getElementById('adminSearch').value = '';

  const ehConfiguracoes = chave === 'configuracoes';
  const ehAdministradores = chave === 'administradores';
  const ehNotificacoes = chave === 'notificacoes';
  const ehVendas = chave === 'vendas';
  const ehCompras = chave === 'compras';
  const ehPedidos = chave === 'pedidos';
  const ehFaturamento = chave === 'faturamento';
  const ehGenerica = !ehConfiguracoes && !ehAdministradores && !ehNotificacoes && !ehVendas && !ehCompras && !ehPedidos && !ehFaturamento;

  document.getElementById('tableWrap').style.display = ehGenerica ? '' : 'none';
  document.getElementById('filtersBar').style.display = ehGenerica ? '' : 'none';
  document.getElementById('addBtn').style.display = ehGenerica ? '' : 'none';
  document.getElementById('configPanel').style.display = ehConfiguracoes ? 'block' : 'none';
  document.getElementById('adminsPanel').style.display = ehAdministradores ? 'block' : 'none';
  document.getElementById('notificacoesPanel').style.display = ehNotificacoes ? 'block' : 'none';
  document.getElementById('vendasPanel').style.display = ehVendas ? 'block' : 'none';
  document.getElementById('comprasPanel').style.display = ehCompras ? 'block' : 'none';
  document.getElementById('pedidosPanel').style.display = ehPedidos ? 'block' : 'none';
  document.getElementById('faturamentoPanel').style.display = ehFaturamento ? 'block' : 'none';

  if (ehConfiguracoes) {
    document.getElementById('tabTitle').textContent = 'Configurações';
    document.getElementById('tabCount').textContent = 'Contato de WhatsApp e PIX exibidos/usados no catálogo público';
    carregarConfiguracoes();
    return;
  }

  if (ehAdministradores) {
    document.getElementById('tabTitle').textContent = 'Administradores';
    document.getElementById('tabCount').textContent = 'Gerenciado via função serverless — papéis não podem ser alterados direto pelo navegador';
    carregarAdmins();
    return;
  }

  if (ehNotificacoes) {
    document.getElementById('tabTitle').textContent = 'Notificações Push';
    document.getElementById('tabCount').textContent = '';
    carregarContadorNotificacoes();
    return;
  }

  if (ehVendas) {
    document.getElementById('tabTitle').textContent = 'Vendas';
    document.getElementById('tabCount').textContent = 'Registrar vendas, parcelas e receber via PIX';
    carregarMovimentos('vendas');
    return;
  }

  if (ehCompras) {
    document.getElementById('tabTitle').textContent = 'Compras';
    document.getElementById('tabCount').textContent = 'Registrar compras de fornecedores e controlar pagamentos';
    carregarMovimentos('compras');
    return;
  }

  if (ehPedidos) {
    document.getElementById('tabTitle').textContent = 'Pedidos';
    document.getElementById('tabCount').textContent = 'Pedidos feitos pelo carrinho público — confirme pagamento e despache';
    carregarPedidos();
    return;
  }

  if (ehFaturamento) {
    document.getElementById('tabTitle').textContent = 'Faturamento';
    document.getElementById('tabCount').textContent = 'Vendas confirmadas + pedidos já pagos, juntos — visão só de leitura';
    carregarFaturamento();
    return;
  }

  document.getElementById('tabTitle').textContent = ENTIDADES[chave].titulo;
  document.getElementById('addBtn').textContent = '+ ' + ENTIDADES[chave].tituloNovo;
  renderTabela();
}
/* ============================================================================
   CONFIGURAÇÕES
   ============================================================================ */
const CONFIG_DOC = () => doc(db, 'configuracoes', 'geral');
let configCache = { contatos: [], mensagemPadrao: '', pixChave: '', pixNome: '', pixCidade: '' };

async function carregarConfiguracoes() {
  const lista = document.getElementById('contatosList');
  lista.innerHTML = `<div class="loading-row"><div class="spinner" style="margin:0 auto;"></div></div>`;
  try {
    const snap = await getDoc(CONFIG_DOC());
    if (snap.exists()) {
      const data = snap.data();
      configCache.contatos = Array.isArray(data.contatos) && data.contatos.length
        ? data.contatos
        : [{ label: 'Vendas', numero: '' }];
      configCache.mensagemPadrao = data.mensagemPadrao || '';
      configCache.pixChave = data.pixChave || '';
      configCache.pixNome = data.pixNome || '';
      configCache.pixCidade = data.pixCidade || '';
    } else {
      configCache.contatos = [{ label: 'Vendas', numero: '' }];
      configCache.mensagemPadrao = 'Olá! Vim pelo catálogo online e gostaria de mais informações.';
    }
  } catch (err) {
    console.error('Erro ao carregar configurações:', err);
    mostrarToast('Erro ao carregar configurações.', true);
    configCache.contatos = [{ label: 'Vendas', numero: '' }];
  }
  document.getElementById('configMensagemPadrao').value = configCache.mensagemPadrao;
  document.getElementById('configPixChave').value = configCache.pixChave;
  document.getElementById('configPixNome').value = configCache.pixNome;
  document.getElementById('configPixCidade').value = configCache.pixCidade;
  renderContatosForm();

  const backupBtn = document.getElementById('btnBackupFirestore');
  if (backupBtn) {
    backupBtn.addEventListener('click', executarBackupFirestore);
  }
}

function renderContatosForm() {
  const lista = document.getElementById('contatosList');
  lista.innerHTML = configCache.contatos.map((c, i) => `
    <div class="field-row" style="align-items:flex-end;margin-bottom:12px;" data-idx="${i}">
      <div class="field" style="margin-bottom:0;flex:0 0 160px;">
        <label>Rótulo</label>
        <input type="text" class="campo-contato-label" value="${c.label || ''}" placeholder="Ex: Vendas">
      </div>
      <div class="field" style="margin-bottom:0;">
        <label>Número (DDI+DDD+número, só dígitos)</label>
        <input type="text" class="campo-contato-numero" value="${c.numero || ''}" placeholder="5511988887777">
      </div>
      <button type="button" class="btn btn-danger btn-sm" data-remove="${i}" style="margin-bottom:1px;" ${configCache.contatos.length === 1 ? 'disabled title="Deixe pelo menos um contato"' : ''}>✕</button>
    </div>
  `).join('');

  lista.querySelectorAll('[data-remove]').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = Number(btn.dataset.remove);
      configCache.contatos.splice(idx, 1);
      renderContatosForm();
    });
  });
}

document.addEventListener('click', (e) => {
  if (e.target.id === 'addContatoBtn') {
    configCache.contatos.push({ label: '', numero: '' });
    renderContatosForm();
  }
  if (e.target.id === 'saveConfigBtn') {
    salvarConfiguracoes();
  }
});

async function salvarConfiguracoes() {
  const saveBtn = document.getElementById('saveConfigBtn');
  const linhas = document.querySelectorAll('#contatosList .field-row');
  const contatos = [];

  for (const linha of linhas) {
    const label = linha.querySelector('.campo-contato-label').value.trim();
    const numero = linha.querySelector('.campo-contato-numero').value.replace(/\D/g, '');
    if (!label || !numero) continue;
    contatos.push({ label, numero });
  }

  if (contatos.length === 0) {
    mostrarToast('Cadastre pelo menos um contato com rótulo e número.', true);
    return;
  }

  saveBtn.disabled = true;
  saveBtn.textContent = 'Salvando...';
  try {
    await setDoc(CONFIG_DOC(), {
      contatos,
      mensagemPadrao: document.getElementById('configMensagemPadrao').value.trim(),
      pixChave: document.getElementById('configPixChave').value.trim(),
      pixNome: document.getElementById('configPixNome').value.trim(),
      pixCidade: document.getElementById('configPixCidade').value.trim(),
      atualizadoEm: serverTimestamp()
    });
    configCache.contatos = contatos;
    configCache.pixChave = document.getElementById('configPixChave').value.trim();
    configCache.pixNome = document.getElementById('configPixNome').value.trim();
    configCache.pixCidade = document.getElementById('configPixCidade').value.trim();
    mostrarToast('Configurações salvas com sucesso.');
  } catch (err) {
    console.error('Erro ao salvar configurações:', err);
    mostrarToast('Erro ao salvar. Verifique as regras do Firestore.', true);
  } finally {
    saveBtn.disabled = false;
    saveBtn.textContent = 'Salvar configurações';
  }
}

/* ============================================================================
   BACKUP FIRESTORE (via CDN)
   ============================================================================ */

async function executarBackupFirestore() {
  const btn = document.getElementById('btnBackupFirestore');
  const originalText = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = '⏳ Exportando...';

  try {
    const firebaseApp = await import('https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js');
    const firebaseFirestore = await import('https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js');

    const firebaseConfig = {
      apiKey: "AIzaSyDh_AqBiKhzuqmAdOuvux7aGvBvzl_6h2U",
      authDomain: "toque-zen.firebaseapp.com",
      projectId: "toque-zen",
      storageBucket: "toque-zen.firebasestorage.app",
      messagingSenderId: "778431982220",
      appId: "1:778431982220:web:df14feec23b50818d2e9a9"
    };

    const app = firebaseApp.initializeApp(firebaseConfig);
    const db = firebaseFirestore.getFirestore(app);
    const { collection, getDocs } = firebaseFirestore;

    const colecoes = [
      'produtos', 'categorias', 'clientes', 'fornecedores',
      'configuracoes', 'vendas', 'compras', 'pedidos',
      'contasClientes', 'fcmTokens'
    ];

    const backup = {};
    let totalDocs = 0;

    for (const nome of colecoes) {
      try {
        const snap = await getDocs(collection(db, nome));
        backup[nome] = snap.docs.map(d => ({ id: d.id, ...d.data() }));
        totalDocs += backup[nome].length;
      } catch (e) {
        backup[nome] = [];
      }
    }

    const json = JSON.stringify({
      exportadoEm: new Date().toISOString(),
      totalDocumentos: totalDocs,
      dados: backup
    }, null, 2);

    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `firestore-backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    mostrarToast(`✅ Backup concluído! ${totalDocs} documentos exportados.`);
  } catch (err) {
    console.error('Erro no backup:', err);
    mostrarToast('❌ Erro ao fazer backup. Verifique o console.', true);
  } finally {
    btn.disabled = false;
    btn.innerHTML = originalText;
  }
}

/* ============================================================================
   ADMINISTRADORES
   ============================================================================ */
let adminsCache = [];

async function carregarAdmins() {
  const tbody = document.getElementById('adminsTableBody');
  tbody.innerHTML = `<tr><td colspan="4" class="loading-row"><div class="spinner" style="margin:0 auto;"></div></td></tr>`;
  try {
    const { admins } = await adminApi.listar();
    adminsCache = admins;
    renderAdminsTable();
  } catch (err) {
    console.error('Erro ao listar administradores:', err);
    tbody.innerHTML = `<tr><td colspan="4" class="loading-row">${err.message}</td></tr>`;
  }
}

function renderAdminsTable() {
  const tbody = document.getElementById('adminsTableBody');
  const meuUid = auth.currentUser?.uid;

  tbody.innerHTML = adminsCache.map(a => {
    const souEu = a.uid === meuUid;
    return `
      <tr>
        <td>${a.nome}${souEu ? ' <span class="cell-muted">(você)</span>' : ''}</td>
        <td class="cell-mono">${a.email}</td>
        <td>
          <select class="campo-papel-admin" data-uid="${a.uid}" ${souEu ? 'disabled title="Você não pode alterar seu próprio nível de acesso"' : ''} style="padding:6px 10px;font-size:12px;">
            <option value="operador" ${a.role === 'operador' ? 'selected' : ''}>Operador</option>
            <option value="owner" ${a.role === 'owner' ? 'selected' : ''}>Proprietário</option>
            ${a.role === 'sem-papel' ? `<option value="sem-papel" selected disabled>Sem papel</option>` : ''}
          </select>
        </td>
        <td>
          <div class="row-actions">
            <button class="btn btn-sm btn-danger" data-excluir-admin="${a.uid}" ${souEu ? 'disabled title="Você não pode excluir a própria conta"' : ''}>Excluir</button>
          </div>
        </td>
      </tr>`;
  }).join('');

  tbody.querySelectorAll('.campo-papel-admin').forEach(sel => {
    sel.addEventListener('change', async () => {
      const uid = sel.dataset.uid;
      const novoPapel = sel.value;
      sel.disabled = true;
      try {
        await adminApi.atualizarPapel(uid, novoPapel);
        mostrarToast('Nível de acesso atualizado.');
        await carregarAdmins();
      } catch (err) {
        console.error(err);
        mostrarToast(err.message, true);
        await carregarAdmins();
      }
    });
  });

  tbody.querySelectorAll('[data-excluir-admin]').forEach(btn => {
    btn.addEventListener('click', () => confirmarExclusaoAdmin(btn.dataset.excluirAdmin));
  });
}

function abrirFormNovoAdmin() {
  document.getElementById('modalRoot').innerHTML = `
    <div class="modal-overlay" id="formAdminOverlay">
      <div class="modal" style="max-width:520px;">
        <div class="modal-form">
          <button class="modal-close" id="closeFormAdmin">✕</button>
          <h2 style="font-size:26px;margin-bottom:22px;">Novo administrador</h2>
          <form id="novoAdminForm">
            <div class="form-grid">
              <div class="field full">
                <label>Nome *</label>
                <input type="text" id="novoAdminNome" required>
              </div>
              <div class="field full">
                <label>E-mail de login *</label>
                <input type="email" id="novoAdminEmail" required>
              </div>
              <div class="field">
                <label>Senha provisória *</label>
                <input type="password" id="novoAdminSenha" required>
              </div>
              <div class="field">
                <label>Confirmar senha *</label>
                <input type="password" id="novoAdminSenhaConfirma" required>
              </div>
              <div class="field full">
                <label>Nível de acesso *</label>
                <select id="novoAdminPapel">
                  <option value="operador">Operador — produtos, clientes e fornecedores</option>
                  <option value="owner">Proprietário — acesso total, inclusive administradores</option>
                </select>
              </div>
            </div>
            <div class="modal-actions">
              <button type="button" class="btn btn-ghost" id="cancelFormAdmin">Cancelar</button>
              <button type="submit" class="btn btn-gold" id="saveAdminBtn">Cadastrar</button>
            </div>
          </form>
        </div>
      </div>
    </div>`;
  const overlay = document.getElementById('formAdminOverlay');
  document.getElementById('closeFormAdmin').addEventListener('click', () => overlay.remove());
  document.getElementById('cancelFormAdmin').addEventListener('click', () => overlay.remove());

  document.getElementById('novoAdminForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const nome = document.getElementById('novoAdminNome').value.trim();
    const email = document.getElementById('novoAdminEmail').value.trim();
    const senha = document.getElementById('novoAdminSenha').value;
    const confirma = document.getElementById('novoAdminSenhaConfirma').value;
    const role = document.getElementById('novoAdminPapel').value;
    const saveBtn = document.getElementById('saveAdminBtn');

    if (senha.length < 10) return mostrarToast('A senha precisa ter pelo menos 10 caracteres.', true);
    if (senha !== confirma) return mostrarToast('As senhas não coincidem.', true);

    saveBtn.disabled = true;
    saveBtn.textContent = 'Criando...';
    try {
      await adminApi.criar({ nome, email, senha, role });
      mostrarToast('Administrador criado com sucesso.');
      overlay.remove();
      await carregarAdmins();
    } catch (err) {
      console.error(err);
      mostrarToast(err.message, true);
    } finally {
      saveBtn.disabled = false;
      saveBtn.textContent = 'Cadastrar';
    }
  });
}

function confirmarExclusaoAdmin(uid) {
  const item = adminsCache.find(x => x.uid === uid);
  document.getElementById('modalRoot').innerHTML = `
    <div class="modal-overlay" id="delAdminOverlay">
      <div class="modal" style="max-width:400px;">
        <div class="modal-form">
          <h2 style="font-size:22px;">Excluir administrador?</h2>
          <p style="margin-top:10px;">Isso apaga de vez o login de <strong style="color:var(--ivory);">${item?.nome || 'este usuário'}</strong> — ele não vai mais conseguir entrar no painel. Essa ação não pode ser desfeita.</p>
          <div class="modal-actions">
            <button class="btn btn-ghost" id="cancelDelAdmin">Cancelar</button>
            <button class="btn btn-danger" id="confirmDelAdmin">Excluir</button>
          </div>
        </div>
      </div>
    </div>`;
  const overlay = document.getElementById('delAdminOverlay');
  document.getElementById('cancelDelAdmin').addEventListener('click', () => overlay.remove());
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.getElementById('confirmDelAdmin').addEventListener('click', async () => {
    try {
      await adminApi.excluir(uid);
      mostrarToast('Administrador excluído.');
      overlay.remove();
      await carregarAdmins();
    } catch (err) {
      console.error(err);
      mostrarToast(err.message, true);
    }
  });
}

/* ============================================================================
   VENDAS E COMPRAS
   ============================================================================ */
const MOVIMENTOS = {
  vendas: {
    colecao: 'vendas',
    entidadeRelacionada: 'clientes',
    campoRelacionado: 'clienteId',
    campoRelacionadoNome: 'clienteNome',
    rotuloRelacionado: 'Cliente',
    direcaoEstoque: -1,
    tituloNovo: 'Nova venda',
    tabelaBodyId: 'vendasTableBody',
    permitePix: true
  },
  compras: {
    colecao: 'compras',
    entidadeRelacionada: 'fornecedores',
    campoRelacionado: 'fornecedorId',
    campoRelacionadoNome: 'fornecedorNome',
    rotuloRelacionado: 'Fornecedor',
    direcaoEstoque: 1,
    tituloNovo: 'Nova compra',
    tabelaBodyId: 'comprasTableBody',
    permitePix: false
  }
};

let movimentosCache = { vendas: [], compras: [] };

function rotuloStatusMovimento(status) {
  return { pendente: 'Pendente', confirmada: 'Confirmada', cancelada: 'Cancelada' }[status] || status;
}

async function carregarMovimentos(tipo) {
  const tbody = document.getElementById(MOVIMENTOS[tipo].tabelaBodyId);
  tbody.innerHTML = `<tr><td colspan="6" class="loading-row"><div class="spinner" style="margin:0 auto;"></div></td></tr>`;
  try {
    const snap = await getDocs(collection(db, MOVIMENTOS[tipo].colecao));
    movimentosCache[tipo] = snap.docs.map(d => ({ id: d.id, ...d.data() }))
      .sort((a, b) => (b.criadoEm?.seconds || 0) - (a.criadoEm?.seconds || 0));
    renderMovimentosTable(tipo);
  } catch (err) {
    console.error(`Erro ao carregar ${tipo}:`, err);
    tbody.innerHTML = `<tr><td colspan="6" class="loading-row">Erro ao carregar. Confira se as regras do Firestore foram publicadas.</td></tr>`;
  }
}

function renderMovimentosTable(tipo) {
  const cfg = MOVIMENTOS[tipo];
  const lista = movimentosCache[tipo];
  const tbody = document.getElementById(cfg.tabelaBodyId);

  if (lista.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" class="loading-row">Nenhum registro ainda.</td></tr>`;
    return;
  }

  tbody.innerHTML = lista.map(mov => {
    const resumoItens = (mov.itens || []).map(i => `${i.quantidade}× ${i.nome}`).join(', ') || '—';
    const pagamento = mov.formaPagamento === 'parcelado'
      ? `Parcelado (${(mov.parcelas || []).length}x)`
      : 'À vista';
    const badgeStatus = { pendente: 'badge-out', confirmada: 'badge-ok', cancelada: '' }[mov.status] || '';
    return `<tr class="tabela-linha" data-id="${mov.id}">
      <td>${mov[cfg.campoRelacionadoNome] || '—'}</td>
      <td class="cell-muted" style="max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${resumoItens}</td>
      <td class="cell-mono">${formatBRL(mov.valorTotal)}</td>
      <td>${pagamento}</td>
      <td><span class="badge ${badgeStatus}">${rotuloStatusMovimento(mov.status)}</span></td>
      <td>
        <div class="row-actions">
          <button class="btn btn-sm btn-ghost" data-action="ver-mov" data-id="${mov.id}">${mov.status === 'pendente' ? 'Editar' : 'Ver'}</button>
        </div>
      </td>
    </tr>`;
  }).join('');

  tbody.querySelectorAll('.tabela-linha').forEach(tr => {
    tr.addEventListener('click', () => abrirFormMovimento(tipo, tr.dataset.id));
  });
}

function confirmarAcao({ titulo, mensagem, textoBotao, classeBotao = 'btn-gold', aoConfirmar }) {
  document.getElementById('modalRoot').innerHTML = `
    <div class="modal-overlay" id="confirmAcaoOverlay">
      <div class="modal" style="max-width:420px;">
        <div class="modal-form">
          <h2 style="font-size:22px;">${titulo}</h2>
          <p style="margin-top:10px;">${mensagem}</p>
          <div class="modal-actions">
            <button class="btn btn-ghost" id="confirmAcaoCancelar">Cancelar</button>
            <button class="btn ${classeBotao}" id="confirmAcaoOk">${textoBotao}</button>
          </div>
        </div>
      </div>
    </div>`;
  const overlay = document.getElementById('confirmAcaoOverlay');
  document.getElementById('confirmAcaoCancelar').addEventListener('click', () => overlay.remove());
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.getElementById('confirmAcaoOk').addEventListener('click', async () => {
    const btn = document.getElementById('confirmAcaoOk');
    btn.disabled = true;
    btn.textContent = 'Aguarde...';
    try {
      await aoConfirmar();
      overlay.remove();
    } catch (err) {
      console.error(err);
      mostrarToast(err.message || 'Erro ao processar.', true);
      btn.disabled = false;
      btn.textContent = textoBotao;
    }
  });
}

async function confirmarMovimento(tipo, id) {
  const cfg = MOVIMENTOS[tipo];
  const movRef = doc(db, cfg.colecao, id);

  await runTransaction(db, async (tx) => {
    const movSnap = await tx.get(movRef);
    if (!movSnap.exists()) throw new Error('Registro não encontrado.');
    const mov = movSnap.data();
    if (mov.status !== 'pendente') throw new Error('Só é possível confirmar um registro pendente.');

    const itens = mov.itens || [];
    const produtoIds = itens.map(i => i.produtoId).filter(Boolean);

    const produtoRefs = itens.map(i => doc(db, 'produtos', i.produtoId));
    const produtoSnaps = await Promise.all(produtoRefs.map(ref => tx.get(ref)));

    produtoSnaps.forEach((snap, i) => {
      if (!snap.exists()) return;
      const estoqueAtual = snap.data().estoque ?? 0;
      const novoEstoque = estoqueAtual + (cfg.direcaoEstoque * itens[i].quantidade);
      tx.update(produtoRefs[i], { estoque: novoEstoque });
    });

    tx.update(movRef, { 
      status: 'confirmada', 
      confirmadaEm: serverTimestamp(),
      produtoIds
    });
  });

  mostrarToast(tipo === 'vendas' ? 'Venda confirmada — estoque atualizado.' : 'Compra confirmada — estoque atualizado.');
  await carregarMovimentos(tipo);
  await carregarColecao('produtos');
}

async function cancelarMovimento(tipo, id) {
  const cfg = MOVIMENTOS[tipo];
  const movRef = doc(db, cfg.colecao, id);

  await runTransaction(db, async (tx) => {
    const movSnap = await tx.get(movRef);
    if (!movSnap.exists()) throw new Error('Registro não encontrado.');
    const mov = movSnap.data();
    if (mov.status === 'cancelada') throw new Error('Já está cancelado.');

    if (mov.status === 'confirmada') {
      const itens = mov.itens || [];
      const produtoRefs = itens.map(i => doc(db, 'produtos', i.produtoId));
      const produtoSnaps = await Promise.all(produtoRefs.map(ref => tx.get(ref)));
      produtoSnaps.forEach((snap, i) => {
        if (!snap.exists()) return;
        const estoqueAtual = snap.data().estoque ?? 0;
        const novoEstoque = estoqueAtual - (cfg.direcaoEstoque * itens[i].quantidade);
        tx.update(produtoRefs[i], { estoque: novoEstoque });
      });
    }

    tx.update(movRef, { status: 'cancelada', canceladaEm: serverTimestamp() });
  });

  mostrarToast('Cancelado.');
  await carregarMovimentos(tipo);
  await carregarColecao('produtos');
}

async function alternarStatusParcela(tipo, id, numeroParcela) {
  const cfg = MOVIMENTOS[tipo];
  const mov = movimentosCache[tipo].find(m => m.id === id);
  if (!mov) return;
  const parcelas = (mov.parcelas || []).map(p =>
    p.numero === numeroParcela
      ? { ...p, status: p.status === 'pago' ? 'pendente' : 'pago', pagoEm: p.status === 'pago' ? null : new Date().toISOString() }
      : p
  );
  try {
    await updateDoc(doc(db, cfg.colecao, id), { parcelas });
    mov.parcelas = parcelas;
    mostrarToast('Parcela atualizada.');
    abrirFormMovimento(tipo, id);
  } catch (err) {
    console.error(err);
    mostrarToast('Erro ao atualizar a parcela.', true);
  }
}

function abrirFormMovimento(tipo, id) {
  const cfg = MOVIMENTOS[tipo];
  const item = id ? movimentosCache[tipo].find(x => x.id === id) : null;
  const somenteLeitura = !!item && (item.status !== 'pendente' || (item.parcelas || []).some(p => p.status === 'pago'));

  const relacionados = dadosCache[cfg.entidadeRelacionada] || [];
  const opcoesRelacionado = relacionados.map(r =>
    `<option value="${r.id}" ${item?.[cfg.campoRelacionado] === r.id ? 'selected' : ''}>${r.nome}</option>`).join('');

  const itensIniciais = item?.itens?.length ? item.itens : [{ produtoId: '', nome: '', quantidade: 1, valorUnitario: 0 }];

  document.getElementById('modalRoot').innerHTML = `
    <div class="modal-overlay" id="movOverlay">
      <div class="modal" style="max-width:740px;">
        <div class="modal-form">
          <button class="modal-close" id="closeMovForm">✕</button>
          <h2 style="font-size:26px;margin-bottom:4px;">${item ? (somenteLeitura ? 'Detalhes' : 'Editar') : cfg.tituloNovo}</h2>
          ${item ? `<div class="cell-muted" style="margin-bottom:18px;">Status: <strong>${rotuloStatusMovimento(item.status)}</strong></div>` : '<div style="margin-bottom:18px;"></div>'}

          <form id="movForm">
            <div class="field">
              <label>${cfg.rotuloRelacionado} *</label>
              <select id="movRelacionado" ${somenteLeitura ? 'disabled' : ''} required>
                <option value="">Selecione</option>
                ${opcoesRelacionado}
              </select>
            </div>

            <div class="field" style="margin-top:18px;">
              <label>Itens</label>
              <div id="itensEditor"></div>
              ${somenteLeitura ? '' : '<button type="button" class="btn btn-ghost btn-sm" id="addItemBtn" style="margin-top:6px;">+ Adicionar item</button>'}
            </div>

            <div class="field-row" style="margin-top:20px;">
              <div class="field">
                <label>Forma de pagamento</label>
                <select id="movFormaPagamento" ${somenteLeitura ? 'disabled' : ''}>
                  <option value="avista" ${item?.formaPagamento !== 'parcelado' ? 'selected' : ''}>À vista</option>
                  <option value="parcelado" ${item?.formaPagamento === 'parcelado' ? 'selected' : ''}>Parcelado</option>
                </select>
              </div>
              <div class="field" id="movNumParcelasWrap" style="display:${item?.formaPagamento === 'parcelado' ? 'block' : 'none'};">
                <label>Nº de parcelas</label>
                <input type="number" id="movNumParcelas" min="2" max="24" value="${item?.parcelas?.length > 1 ? item.parcelas.length : 2}" ${somenteLeitura ? 'disabled' : ''}>
              </div>
              <div class="field" id="movPrimeiroVencimentoWrap" style="display:${item?.formaPagamento === 'parcelado' ? 'block' : 'none'};">
                <label>1º vencimento</label>
                <input type="date" id="movPrimeiroVencimento" value="${item?.parcelas?.[0]?.vencimento || ''}" ${somenteLeitura ? 'disabled' : ''}>
              </div>
            </div>

            <div class="divider"><span class="diamond">◆</span></div>

            <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:6px;">
              <span class="cell-muted">Total</span>
              <span id="movTotalExibido" style="font-family:var(--font-mono);font-size:20px;color:var(--gold-bright);">${formatBRL(item?.valorTotal || 0)}</span>
            </div>

            ${item ? `<div id="parcelasView" style="margin-top:14px;">${renderParcelasView(tipo, item)}</div>` : ''}

            ${somenteLeitura ? '' : `
              <div class="modal-actions">
                <button type="button" class="btn btn-ghost" id="cancelMovForm">Cancelar</button>
                <button type="submit" class="btn btn-gold" id="saveMovBtn">${item ? 'Salvar alterações' : 'Cadastrar'}</button>
              </div>
            `}
          </form>

          ${item ? `
            <div class="modal-actions" style="border-top:1px solid var(--border-soft);margin-top:20px;padding-top:18px;">
              ${(item.status === 'pendente' || item.status === 'cancelada') ? `<button type="button" class="btn btn-danger" id="excluirMovBtn">Excluir</button>` : ''}
              ${item.status === 'pendente' ? `<button type="button" class="btn btn-gold" id="confirmarMovBtn">${tipo === 'vendas' ? 'Confirmar venda (baixa estoque)' : 'Confirmar compra (soma estoque)'}</button>` : ''}
              ${item.status !== 'cancelada' ? `<button type="button" class="btn btn-ghost" id="cancelarMovBtn" style="color:var(--danger);">Cancelar ${tipo === 'vendas' ? 'venda' : 'compra'}</button>` : ''}
            </div>
          ` : ''}
        </div>
      </div>
    </div>`;

  const overlay = document.getElementById('movOverlay');
  document.getElementById('closeMovForm').addEventListener('click', () => overlay.remove());
  const cancelBtn = document.getElementById('cancelMovForm');
  if (cancelBtn) cancelBtn.addEventListener('click', () => overlay.remove());

  function renderItensEditor() {
    const wrap = document.getElementById('itensEditor');
    const produtos = dadosCache.produtos || [];
    wrap.innerHTML = itensIniciais.map((it, idx) => `
      <div class="field-row" style="align-items:flex-end;margin-bottom:10px;" data-idx="${idx}">
        <div class="field" style="margin-bottom:0;flex:2;">
          <label>Produto</label>
          <select class="item-produto" ${somenteLeitura ? 'disabled' : ''}>
            <option value="">Selecione</option>
            ${produtos.map(p => `<option value="${p.id}" data-valor="${p.valorAVista || 0}" ${it.produtoId === p.id ? 'selected' : ''}>${p.nome}</option>`).join('')}
          </select>
        </div>
        <div class="field" style="margin-bottom:0;flex:0 0 90px;">
          <label>Qtd.</label>
          <input type="number" class="item-quantidade" min="1" value="${it.quantidade || 1}" ${somenteLeitura ? 'disabled' : ''}>
        </div>
        <div class="field" style="margin-bottom:0;flex:0 0 130px;">
          <label>Valor unit. (R$)</label>
          <input type="number" class="item-valor" min="0" step="0.01" value="${it.valorUnitario || 0}" ${somenteLeitura ? 'disabled' : ''}>
        </div>
        ${somenteLeitura ? '' : `<button type="button" class="btn btn-danger btn-sm" data-remove-item="${idx}" style="margin-bottom:1px;" ${itensIniciais.length === 1 ? 'disabled' : ''}>✕</button>`}
      </div>
    `).join('');

    if (!somenteLeitura) {
      wrap.querySelectorAll('.item-produto').forEach(sel => {
        sel.addEventListener('change', () => {
          const idx = Number(sel.closest('[data-idx]').dataset.idx);
          const opt = sel.selectedOptions[0];
          itensIniciais[idx].produtoId = sel.value;
          itensIniciais[idx].nome = opt ? opt.textContent : '';
          const valorInput = sel.closest('[data-idx]').querySelector('.item-valor');
          if (opt && opt.dataset.valor && Number(valorInput.value) === 0) {
            valorInput.value = opt.dataset.valor;
            itensIniciais[idx].valorUnitario = Number(opt.dataset.valor);
          }
          recalcularTotal();
        });
      });
      wrap.querySelectorAll('.item-quantidade, .item-valor').forEach(inp => {
        inp.addEventListener('input', () => {
          const idx = Number(inp.closest('[data-idx]').dataset.idx);
          itensIniciais[idx].quantidade = Number(inp.closest('[data-idx]').querySelector('.item-quantidade').value) || 1;
          itensIniciais[idx].valorUnitario = Number(inp.closest('[data-idx]').querySelector('.item-valor').value) || 0;
          recalcularTotal();
        });
      });
      wrap.querySelectorAll('[data-remove-item]').forEach(btn => {
        btn.addEventListener('click', () => {
          itensIniciais.splice(Number(btn.dataset.removeItem), 1);
          renderItensEditor();
          recalcularTotal();
        });
      });
    }
  }

  function recalcularTotal() {
    const total = itensIniciais.reduce((soma, it) => soma + (Number(it.quantidade) || 0) * (Number(it.valorUnitario) || 0), 0);
    document.getElementById('movTotalExibido').textContent = formatBRL(total);
    return total;
  }

  renderItensEditor();
  recalcularTotal();

  if (!somenteLeitura) {
    document.getElementById('addItemBtn').addEventListener('click', () => {
      itensIniciais.push({ produtoId: '', nome: '', quantidade: 1, valorUnitario: 0 });
      renderItensEditor();
    });

    const formaPagSelect = document.getElementById('movFormaPagamento');
    formaPagSelect.addEventListener('change', () => {
      const parcelado = formaPagSelect.value === 'parcelado';
      document.getElementById('movNumParcelasWrap').style.display = parcelado ? 'block' : 'none';
      document.getElementById('movPrimeiroVencimentoWrap').style.display = parcelado ? 'block' : 'none';
    });

    document.getElementById('movForm').addEventListener('submit', (e) => {
      e.preventDefault();
      salvarMovimento(tipo, id, itensIniciais, recalcularTotal());
    });
  }

  const confirmarBtn = document.getElementById('confirmarMovBtn');
  if (confirmarBtn) {
    confirmarBtn.addEventListener('click', () => {
      confirmarAcao({
        titulo: tipo === 'vendas' ? 'Confirmar venda?' : 'Confirmar compra?',
        mensagem: tipo === 'vendas'
          ? 'Isso desconta os itens do estoque agora. Só faça isso quando a venda estiver de fato saindo.'
          : 'Isso soma os itens ao estoque agora. Só faça isso quando a mercadoria realmente chegar.',
        textoBotao: 'Confirmar',
        aoConfirmar: async () => { await confirmarMovimento(tipo, id); overlay.remove(); }
      });
    });
  }
  const cancelarMovBtn = document.getElementById('cancelarMovBtn');
  if (cancelarMovBtn) {
    cancelarMovBtn.addEventListener('click', () => {
      confirmarAcao({
        titulo: `Cancelar ${tipo === 'vendas' ? 'venda' : 'compra'}?`,
        mensagem: item.status === 'confirmada'
          ? 'O estoque já foi movimentado — cancelar agora vai ESTORNAR essa movimentação automaticamente.'
          : 'Essa ação não pode ser desfeita.',
        textoBotao: 'Cancelar ' + (tipo === 'vendas' ? 'venda' : 'compra'),
        classeBotao: 'btn-danger',
        aoConfirmar: async () => { await cancelarMovimento(tipo, id); overlay.remove(); }
      });
    });
  }
  const excluirBtn = document.getElementById('excluirMovBtn');
  if (excluirBtn) {
    excluirBtn.addEventListener('click', () => {
      confirmarAcao({
        titulo: 'Excluir registro?',
        mensagem: item.status === 'cancelada' 
          ? 'Esta venda já foi cancelada e o estoque já foi restaurado. Excluir agora remove permanentemente o registro.'
          : 'Como ainda está pendente, o estoque nunca foi alterado — excluir aqui é seguro e definitivo.',
        textoBotao: 'Excluir',
        classeBotao: 'btn-danger',
        aoConfirmar: async () => {
          await deleteDoc(doc(db, cfg.colecao, id));
          movimentosCache[tipo] = movimentosCache[tipo].filter(m => m.id !== id);
          renderMovimentosTable(tipo);
          mostrarToast('Excluído.');
          overlay.remove();
        }
      });
    });
  }

  const parcelasViewEl = document.getElementById('parcelasView');
  if (parcelasViewEl) {
    parcelasViewEl.querySelectorAll('[data-toggle-parcela]').forEach(btn => {
      btn.addEventListener('click', () => alternarStatusParcela(tipo, id, Number(btn.dataset.toggleParcela)));
    });
    parcelasViewEl.querySelectorAll('[data-gerar-pix]').forEach(btn => {
      btn.addEventListener('click', () => {
        const numero = Number(btn.dataset.gerarPix);
        const parcela = item.parcelas.find(p => p.numero === numero);
        abrirModalPix(parcela?.valor, `${tipo === 'vendas' ? 'VENDA' : 'COMPRA'}${id.slice(0, 6).toUpperCase()}P${numero}`);
      });
    });
  }
}

function renderParcelasView(tipo, mov) {
  if (!mov.parcelas || !mov.parcelas.length) return '';
  const cfg = MOVIMENTOS[tipo];
  const linhas = mov.parcelas.map(p => `
    <tr>
      <td>${p.numero}</td>
      <td>${p.vencimento ? new Date(p.vencimento + 'T00:00:00').toLocaleDateString('pt-BR') : '—'}</td>
      <td class="cell-mono">${formatBRL(p.valor)}</td>
      <td><span class="badge ${p.status === 'pago' ? 'badge-ok' : 'badge-out'}">${p.status === 'pago' ? 'Pago' : 'Pendente'}</span></td>
      <td>
        <div class="row-actions" style="justify-content:flex-start;">
          <button type="button" class="btn btn-sm btn-ghost" data-toggle-parcela="${p.numero}">${p.status === 'pago' ? 'Marcar pendente' : 'Marcar paga'}</button>
          ${(cfg.permitePix && p.status !== 'pago') ? `<button type="button" class="btn btn-sm" style="background:#25D366;color:#0b2413;" data-gerar-pix="${p.numero}">PIX</button>` : ''}
        </div>
      </td>
    </tr>`).join('');
  return `
    <div class="table-wrap">
      <table>
        <thead><tr><th>Parcela</th><th>Vencimento</th><th>Valor</th><th>Status</th><th></th></tr></thead>
        <tbody>${linhas}</tbody>
      </table>
    </div>`;
}

async function salvarMovimento(tipo, id, itensBrutos, valorTotal) {
  const cfg = MOVIMENTOS[tipo];
  const saveBtn = document.getElementById('saveMovBtn');
  const relacionadoSelect = document.getElementById('movRelacionado');
  const formaPagamento = document.getElementById('movFormaPagamento').value;

  const itens = itensBrutos
    .filter(i => i.produtoId && Number(i.quantidade) > 0)
    .map(i => ({ 
      produtoId: i.produtoId, 
      nome: i.nome, 
      quantidade: Number(i.quantidade), 
      valorUnitario: Number(i.valorUnitario) || 0 
    }));

  if (!relacionadoSelect.value) {
    mostrarToast(`Selecione um(a) ${cfg.rotuloRelacionado.toLowerCase()}.`, true);
    return;
  }
  if (itens.length === 0) {
    mostrarToast('Adicione ao menos um item válido.', true);
    return;
  }

  const produtoIds = itens.map(i => i.produtoId).filter(Boolean);

  let parcelas;
  if (formaPagamento === 'parcelado') {
    const numParcelas = Math.max(2, Number(document.getElementById('movNumParcelas').value) || 2);
    const primeiroVencimento = document.getElementById('movPrimeiroVencimento').value;
    if (!primeiroVencimento) {
      mostrarToast('Informe a data do 1º vencimento.', true);
      return;
    }
    parcelas = gerarParcelas(valorTotal, numParcelas, primeiroVencimento);
  } else {
    parcelas = [{ numero: 1, valor: Number(valorTotal.toFixed(2)), vencimento: new Date().toISOString().slice(0, 10), status: 'pendente' }];
  }

  const relacionadoNome = relacionadoSelect.selectedOptions[0].textContent;

  const dados = {
    [cfg.campoRelacionado]: relacionadoSelect.value,
    [cfg.campoRelacionadoNome]: relacionadoNome,
    itens,
    produtoIds,
    valorTotal: Number(valorTotal.toFixed(2)),
    formaPagamento,
    parcelas
  };

  saveBtn.disabled = true;
  saveBtn.textContent = 'Salvando...';
  try {
    if (id) {
      await updateDoc(doc(db, cfg.colecao, id), dados);
      mostrarToast('Atualizado com sucesso.');
    } else {
      dados.status = 'pendente';
      dados.criadoEm = serverTimestamp();
      await addDoc(collection(db, cfg.colecao), dados);
      mostrarToast('Cadastrado com sucesso.');
    }
    document.getElementById('movOverlay').remove();
    await carregarMovimentos(tipo);
  } catch (err) {
    console.error('Erro ao salvar:', err);
    mostrarToast('Erro ao salvar. Verifique os dados e as permissões do Firebase.', true);
  } finally {
    saveBtn.disabled = false;
    saveBtn.textContent = id ? 'Salvar alterações' : 'Cadastrar';
  }
}

function gerarParcelas(valorTotal, numParcelas, primeiroVencimentoISO) {
  const valorParcela = Math.floor((valorTotal / numParcelas) * 100) / 100;
  const parcelas = [];
  let somaParcial = 0;
  const [ano, mes, dia] = primeiroVencimentoISO.split('-').map(Number);

  for (let i = 0; i < numParcelas; i++) {
    const dataVenc = new Date(ano, mes - 1 + i, dia);
    const valor = i === numParcelas - 1
      ? Number((valorTotal - somaParcial).toFixed(2))
      : valorParcela;
    somaParcial += valor;
    parcelas.push({
      numero: i + 1,
      valor,
      vencimento: dataVenc.toISOString().slice(0, 10),
      status: 'pendente'
    });
  }
  return parcelas;
}

function abrirModalPix(valor, identificador) {
  const chave = configCache.pixChave;
  document.getElementById('modalRoot').innerHTML = `
    <div class="modal-overlay" id="pixOverlay">
      <div class="modal" style="max-width:420px;">
        <div class="modal-form" style="text-align:center;">
          <button class="modal-close" id="closePixModal">✕</button>
          <h2 style="font-size:24px;margin-bottom:4px;">Cobrar via PIX</h2>
          <p class="cell-muted" style="margin-bottom:20px;">${formatBRL(valor)}</p>
          <div id="pixQrWrap" style="display:flex;justify-content:center;margin-bottom:18px;"></div>
          <div id="pixMsg" style="font-size:13px;color:var(--danger);margin-bottom:12px;"></div>
          <textarea id="pixCopiaCola" readonly rows="3" style="width:100%;font-family:var(--font-mono);font-size:11px;resize:none;"></textarea>
          <button type="button" class="btn btn-gold" id="copiarPixBtn" style="width:100%;justify-content:center;margin-top:12px;">Copiar código</button>
          <p style="font-size:11px;color:var(--muted-2);margin-top:14px;">
            Peça pro cliente escanear com o app do banco, ou envie o código copiado por WhatsApp.
            A confirmação de pagamento continua manual — marque a parcela como paga depois de conferir.
          </p>
        </div>
      </div>
    </div>`;
  const overlay = document.getElementById('pixOverlay');
  document.getElementById('closePixModal').addEventListener('click', () => overlay.remove());
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });

  const msgEl = document.getElementById('pixMsg');
  if (!chave) {
    msgEl.textContent = 'Nenhuma chave PIX configurada. Vá em Configurações e cadastre uma antes de gerar cobranças.';
    document.getElementById('pixCopiaCola').style.display = 'none';
    document.getElementById('copiarPixBtn').style.display = 'none';
    return;
  }

  try {
    const payload = gerarPayloadPix({
      chave,
      nomeRecebedor: configCache.pixNome,
      cidadeRecebedor: configCache.pixCidade,
      valor,
      identificador
    });
    document.getElementById('pixCopiaCola').value = payload;
    if (window.QRCode) {
      new QRCode(document.getElementById('pixQrWrap'), { text: payload, width: 200, height: 200, colorDark: '#14100f', colorLight: '#f4ece3' });
    } else {
      document.getElementById('pixQrWrap').innerHTML = '<p class="cell-muted">QR code indisponível — use o código copiado abaixo.</p>';
    }
    document.getElementById('copiarPixBtn').addEventListener('click', () => {
      navigator.clipboard.writeText(payload).then(() => mostrarToast('Código PIX copiado.'));
    });
  } catch (err) {
    msgEl.textContent = err.message;
    document.getElementById('pixCopiaCola').style.display = 'none';
    document.getElementById('copiarPixBtn').style.display = 'none';
  }
}
/* ============================================================================
   PEDIDOS
   ============================================================================ */
let pedidosCache = [];

const ETAPAS_PEDIDO = { aguardando_frete: 'Aguardando frete', aguardando_pagamento: 'Aguardando pagamento', pago: 'Pago', despachado: 'Despachado', entregue: 'Entregue', cancelado: 'Cancelado' };
const PRAZO_PAGAMENTO_HORAS = 24;

async function carregarPedidos() {
  const tbody = document.getElementById('pedidosTableBody');
  tbody.innerHTML = `<tr><td colspan="6" class="loading-row"><div class="spinner" style="margin:0 auto;"></div></td></tr>`;
  try {
    const snap = await getDocs(collection(db, 'pedidos'));
    pedidosCache = snap.docs.map(d => ({ id: d.id, ...d.data() }))
      .sort((a, b) => (b.criadoEm?.seconds || 0) - (a.criadoEm?.seconds || 0));

    const prazoMs = PRAZO_PAGAMENTO_HORAS * 60 * 60 * 1000;
    const vencidos = pedidosCache.filter(p =>
      ['aguardando_frete', 'aguardando_pagamento'].includes(p.status) && p.criadoEm?.seconds &&
      Date.now() - p.criadoEm.seconds * 1000 > prazoMs
    );
    if (vencidos.length) {
      await Promise.all(vencidos.map(p =>
        updateDoc(doc(db, 'pedidos', p.id), { status: 'cancelado', canceladoEm: serverTimestamp(), canceladoPor: 'expiracao_automatica' })
          .then(() => { p.status = 'cancelado'; })
          .catch(err => console.warn('Falha ao expirar pedido', p.id, err.message))
      ));
      mostrarToast(`${vencidos.length} pedido(s) vencido(s) (24h sem pagamento) foram cancelados automaticamente.`);
    }

    renderPedidosTable();
  } catch (err) {
    console.error('Erro ao carregar pedidos:', err);
    tbody.innerHTML = `<tr><td colspan="6" class="loading-row">Erro ao carregar. Confira se as regras do Firestore foram publicadas.</td></tr>`;
  }
}

function renderPedidosTable() {
  const tbody = document.getElementById('pedidosTableBody');
  if (pedidosCache.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" class="loading-row">Nenhum pedido ainda.</td></tr>`;
    return;
  }
  tbody.innerHTML = pedidosCache.map(p => {
    const resumoItens = (p.itens || []).map(i => `${i.quantidade}× ${i.nome}`).join(', ') || '—';
    const badge = p.status === 'entregue' ? 'badge-ok' : p.status === 'cancelado' ? '' : 'badge-out';
    return `<tr class="tabela-linha" data-id="${p.id}" ${p.cancelamentoSolicitado ? 'style="background:rgba(193,101,95,0.06);"' : ''}>
      <td>${escapeHtml(p.comprador?.nome || '—')}<div class="cell-muted">${escapeHtml(p.comprador?.telefone || '')}</div></td>
      <td class="cell-muted" style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${resumoItens}</td>
      <td class="cell-mono">${formatBRL(p.valorTotal)}</td>
      <td>${p.comprador?.tipoEntrega === 'entrega' ? 'Entrega' : 'Retirada'}</td>
      <td>
        <span class="badge ${badge}">${ETAPAS_PEDIDO[p.status] || p.status}</span>${p.comprovanteUrl ? ' <span title="Comprovante anexado">📎</span>' : ''}
        ${p.cancelamentoSolicitado ? '<div class="badge badge-out" style="margin-top:4px;">Cancelamento solicitado</div>' : ''}
      </td>
      <td><div class="row-actions"><button class="btn btn-sm btn-ghost" data-action="ver-pedido" data-id="${p.id}">Gerenciar</button></div></td>
    </tr>`;
  }).join('');

  tbody.querySelectorAll('.tabela-linha').forEach(tr => {
    tr.addEventListener('click', () => abrirDetalhePedido(tr.dataset.id));
  });
}

async function ajustarEstoquePedido(id, direcao) {
  const pedidoRef = doc(db, 'pedidos', id);
  await runTransaction(db, async (tx) => {
    const snap = await tx.get(pedidoRef);
    if (!snap.exists()) throw new Error('Pedido não encontrado.');
    const pedido = snap.data();
    const itens = pedido.itens || [];
    const produtoRefs = itens.map(i => doc(db, 'produtos', i.produtoId));
    const produtoSnaps = await Promise.all(produtoRefs.map(ref => tx.get(ref)));
    produtoSnaps.forEach((s, i) => {
      if (!s.exists()) return;
      const estoqueAtual = s.data().estoque ?? 0;
      tx.update(produtoRefs[i], { estoque: estoqueAtual + (direcao * itens[i].quantidade) });
    });
  });
}

function sugerirAvisoWhatsapp(pedido, mensagem) {
  const telefone = pedido?.comprador?.telefone;
  if (!telefone) return;
  const link = `https://wa.me/55${telefone.replace(/\D/g, '')}?text=${encodeURIComponent(mensagem)}`;
  document.getElementById('modalRoot').innerHTML = `
    <div class="modal-overlay" id="avisoWaOverlay">
      <div class="modal" style="max-width:380px;">
        <div class="modal-form" style="text-align:center;">
          <h2 style="font-size:20px;">Avisar o cliente?</h2>
          <p style="margin:10px 0 18px;font-size:13px;color:var(--muted);">A notificação push só chega se o cliente tiver ativado. Um WhatsApp garante que ele saiba que pode agir.</p>
          <a href="${link}" target="_blank" rel="noopener" class="btn btn-gold" style="width:100%;justify-content:center;" id="btnAbrirWaAviso">Abrir WhatsApp</a>
          <button type="button" class="btn btn-ghost" style="width:100%;justify-content:center;margin-top:8px;" id="fecharAvisoWa">Agora não</button>
        </div>
      </div>
    </div>`;
  document.getElementById('fecharAvisoWa').addEventListener('click', () => document.getElementById('avisoWaOverlay')?.remove());
  document.getElementById('btnAbrirWaAviso').addEventListener('click', () => {
    setTimeout(() => document.getElementById('avisoWaOverlay')?.remove(), 200);
  });
}

const MENSAGENS_WHATSAPP_STATUS = {
  frete_definido: (p) => `Olá, ${p.comprador?.nome || ''}! Já calculamos sua entrega — o pagamento (PIX) está liberado. Acompanhe e pague por aqui: ${location.origin}/pedido.html?id=${p.id}`,
  pago: (p) => `Olá, ${p.comprador?.nome || ''}! Recebemos seu pagamento e já estamos preparando seu pedido. 🎉`,
  despachado: (p) => `Olá, ${p.comprador?.nome || ''}! Seu pedido saiu para entrega. 🚚`,
  entregue: (p) => `Olá, ${p.comprador?.nome || ''}! Esperamos que você ame seu novo perfume. ✨`
};

async function mudarStatusPedido(id, novoStatus) {
  const pedido = pedidosCache.find(p => p.id === id);

  if (novoStatus === 'pago' && pedido.status === 'aguardando_pagamento') {
    await ajustarEstoquePedido(id, -1);
    await carregarColecao('produtos');
  }
  if (novoStatus === 'cancelado' && (pedido.status === 'pago' || pedido.status === 'despachado')) {
    await ajustarEstoquePedido(id, 1);
    await carregarColecao('produtos');
  }

  const campoData = { pago: 'pagoEm', despachado: 'despachadoEm', entregue: 'entregueEm', cancelado: 'canceladoEm' }[novoStatus];
  await updateDoc(doc(db, 'pedidos', id), { status: novoStatus, ...(campoData ? { [campoData]: serverTimestamp() } : {}) });

  if (['pago', 'despachado', 'entregue'].includes(novoStatus)) {
    try { await adminApi.notificarPedido(id, novoStatus); } catch (err) { console.warn('Push não enviado:', err.message); }
  }

  mostrarToast('Status atualizado.');
  await carregarPedidos();
}

function abrirDetalhePedido(id) {
  const p = pedidosCache.find(x => x.id === id);
  if (!p) return;

  const itensHtml = (p.itens || []).map(i => `
    <div class="price-row" style="margin-top:6px;"><span class="label">${i.quantidade}× ${escapeHtml(i.nome)}</span><span class="value">${formatBRL(i.quantidade * i.valorUnitario)}</span></div>
  `).join('');

  const mostrarBreakdownFrete = p.comprador?.tipoEntrega === 'entrega';
  const breakdownFreteHtml = mostrarBreakdownFrete ? `
    <div class="price-row" style="margin-top:10px;"><span class="label">Subtotal itens</span><span class="value">${formatBRL(p.subtotalItens ?? p.valorTotal)}</span></div>
    <div class="price-row" style="margin-top:4px;"><span class="label">Frete</span><span class="value">${p.frete === null || p.frete === undefined ? 'A combinar' : formatBRL(p.frete)}</span></div>
  ` : '';

  const waLink = p.comprador?.telefone ? `https://wa.me/55${p.comprador.telefone.replace(/\D/g, '')}` : null;

  const solicitacaoCancelamentoHtml = p.cancelamentoSolicitado ? `
    <div class="divider"><span class="diamond">◆</span></div>
    <div style="background:rgba(193,101,95,0.12);border:1px solid var(--danger);border-radius:var(--radius);padding:12px 16px;">
      <strong style="color:var(--danger);font-size:13px;">⚠️ Cliente solicitou cancelamento</strong>
      ${p.motivoCancelamento ? `<p style="font-size:13px;margin-top:6px;color:var(--ivory);">"${escapeHtml(p.motivoCancelamento)}"</p>` : '<p style="font-size:13px;margin-top:6px;color:var(--muted);">Sem motivo informado.</p>'}
      <p style="font-size:12px;color:var(--muted-2);margin-top:6px;">Aguardando seu contato para combinar o reembolso.</p>
    </div>
  ` : '';

  // Antes de usar comprovanteUrl como src/href, confirmamos que é mesmo um
  // data-URI de imagem/PDF (mesma checagem das regras do Firestore) — não
  // basta o campo existir, ele precisa ter o formato esperado. Isso evita
  // que um valor inválido/malicioso (bypass das regras, ou dado antigo)
  // vire HTML/JS executado dentro do painel admin.
  const comprovanteValido = isDataUriComprovanteValida(p.comprovanteUrl);
  const ehComprovantePdf = comprovanteValido && p.comprovanteUrl.startsWith('data:application/pdf');
  const comprovanteHtml = p.comprovanteUrl ? (comprovanteValido ? `
    <div class="divider"><span class="diamond">◆</span></div>
    <h3 style="font-size:15px;margin-bottom:10px;">Comprovante enviado pelo cliente</h3>
    <div class="comprovante-preview">
      ${ehComprovantePdf
        ? `<div style="display:flex;align-items:center;gap:10px;padding:8px 4px;">
             <span style="font-size:26px;">📄</span>
             <a href="${p.comprovanteUrl}" target="_blank" rel="noopener" style="font-size:13px;">Abrir comprovante (PDF)</a>
           </div>`
        : `<img src="${p.comprovanteUrl}" id="imgComprovanteAdmin" style="cursor:zoom-in;">`}
    </div>
  ` : `
    <div class="divider"><span class="diamond">◆</span></div>
    <p class="cell-muted" style="font-size:13px;color:var(--danger);">⚠️ O comprovante deste pedido está em um formato inesperado e não pôde ser exibido com segurança. Confira o pagamento diretamente no aplicativo do banco.</p>
  `) : (p.status === 'aguardando_pagamento' ? `
    <div class="divider"><span class="diamond">◆</span></div>
    <p class="cell-muted" style="font-size:13px;">O cliente ainda não anexou comprovante — confira diretamente no seu aplicativo do banco antes de confirmar.</p>
  ` : '');

  const freteFormHtml = p.status === 'aguardando_frete' ? `
    <div class="divider"><span class="diamond">◆</span></div>
    <h3 style="font-size:15px;margin-bottom:8px;">Definir frete</h3>
    <p class="cell-muted" style="font-size:13px;margin-bottom:12px;">Combine o valor com o cliente (WhatsApp acima) e defina aqui — o pedido só libera o pagamento depois disso.</p>
    <div class="field-row" style="align-items:flex-end;">
      <div class="field" style="margin-bottom:0;">
        <label>Valor do frete (R$)</label>
        <input type="number" id="freteInput" min="0" step="0.01" value="0">
      </div>
      <button type="button" class="btn btn-gold" id="confirmarFreteBtn" style="margin-bottom:1px;">Confirmar frete e liberar pagamento</button>
    </div>
  ` : '';

  let acoesHtml = '';

  if (p.status === 'cancelado') {
    acoesHtml = '';
  } else if (p.cancelamentoSolicitado) {
    acoesHtml = `
      <button type="button" class="btn btn-danger" data-mudar-status="cancelado">Cancelar pedido (estorna estoque)</button>
    `;
  } else if (p.status === 'aguardando_frete') {
    acoesHtml = `<button type="button" class="btn btn-ghost" style="color:var(--danger);" data-mudar-status="cancelado">Cancelar pedido</button>`;
  } else if (p.status === 'aguardando_pagamento') {
    acoesHtml = `
      <button type="button" class="btn btn-gold" data-mudar-status="pago">Confirmar pagamento (baixa estoque)</button>
      <button type="button" class="btn btn-ghost" style="color:var(--danger);" data-mudar-status="cancelado">Cancelar pedido</button>`;
  } else if (p.status === 'pago') {
    acoesHtml = `
      <button type="button" class="btn btn-gold" data-mudar-status="despachado">Marcar como despachado</button>
      <button type="button" class="btn btn-ghost" style="color:var(--danger);" data-mudar-status="cancelado">Cancelar pedido (estorna estoque)</button>`;
  } else if (p.status === 'despachado') {
    acoesHtml = `<button type="button" class="btn btn-gold" data-mudar-status="entregue">Marcar como entregue</button>`;
  }

  if (p.status === 'cancelado') {
    acoesHtml = `<button type="button" class="btn btn-danger" id="excluirPedidoBtn">Excluir pedido</button>`;
  } else {
    acoesHtml += `<button type="button" class="btn btn-danger" id="excluirPedidoBtn" style="margin-left:auto;">Excluir pedido</button>`;
  }

  document.getElementById('modalRoot').innerHTML = `
    <div class="modal-overlay" id="pedidoDetalheOverlay">
      <div class="modal" style="max-width:560px;">
        <div class="modal-form">
          <button class="modal-close" id="closePedidoDetalhe">✕</button>
          <h2 style="font-size:26px;margin-bottom:4px;">Pedido</h2>
          <div class="cell-muted" style="margin-bottom:18px;">Status: <strong>${ETAPAS_PEDIDO[p.status] || p.status}</strong></div>

          <h3 style="font-size:15px;margin-bottom:4px;">${escapeHtml(p.comprador?.nome || '—')}</h3>
          <p class="cell-muted" style="margin-bottom:2px;">${escapeHtml(p.comprador?.telefone || '')}</p>
          <p class="cell-muted">${p.comprador?.tipoEntrega === 'entrega' ? escapeHtml(p.comprador?.endereco || '') : 'Retirar na loja'}</p>
          ${waLink ? `<a href="${waLink}" target="_blank" rel="noopener" class="btn btn-ghost btn-sm" style="margin-top:10px;">Falar no WhatsApp</a>` : ''}

          <div class="divider"><span class="diamond">◆</span></div>
          ${itensHtml}
          ${breakdownFreteHtml}
          <div class="price-row avista" style="margin-top:12px;padding-top:12px;border-top:1px solid var(--border-soft);">
            <span class="label">Total</span><span class="value">${formatBRL(p.valorTotal)}</span>
          </div>

          ${freteFormHtml}
          ${solicitacaoCancelamentoHtml}
          ${comprovanteHtml}

          ${acoesHtml ? `<div class="modal-actions" style="justify-content:flex-start;flex-wrap:wrap;">${acoesHtml}</div>` : ''}
        </div>
      </div>
    </div>`;

  const overlay = document.getElementById('pedidoDetalheOverlay');
  document.getElementById('closePedidoDetalhe').addEventListener('click', () => overlay.remove());

  const excluirPedidoBtn = document.getElementById('excluirPedidoBtn');
  if (excluirPedidoBtn) {
    excluirPedidoBtn.addEventListener('click', () => {
      const estoqueDebitado = ['pago', 'despachado', 'entregue'].includes(p.status);
      confirmarAcao({
        titulo: 'Excluir pedido?',
        mensagem: estoqueDebitado
          ? 'Esse pedido já teve pagamento confirmado e o estoque foi baixado. Ao excluir, o estoque é devolvido automaticamente e o registro some do Faturamento. Essa ação não pode ser desfeita — use só para limpar dados de teste, nunca em cima de uma venda real.'
          : 'Essa ação não pode ser desfeita. Como o pedido ainda não teve pagamento confirmado (ou já está cancelado), o estoque não é afetado.',
        textoBotao: 'Excluir definitivamente',
        classeBotao: 'btn-danger',
        aoConfirmar: async () => {
          if (estoqueDebitado) {
            await ajustarEstoquePedido(id, 1);
            await carregarColecao('produtos');
          }
          await deleteDoc(doc(db, 'pedidos', id));
          pedidosCache = pedidosCache.filter(x => x.id !== id);
          mostrarToast('Pedido excluído.');
          overlay.remove();
          renderPedidosTable();
        }
      });
    });
  }

  const confirmarFreteBtn = document.getElementById('confirmarFreteBtn');
  if (confirmarFreteBtn) {
    confirmarFreteBtn.addEventListener('click', () => {
      const frete = Number(document.getElementById('freteInput').value);
      if (!Number.isFinite(frete) || frete < 0) {
        mostrarToast('Informe um valor de frete válido.', true);
        return;
      }
      confirmarAcao({
        titulo: 'Confirmar frete?',
        mensagem: `O total do pedido passa a ser ${formatBRL((p.subtotalItens ?? p.valorTotal) + frete)} (itens + frete). O cliente será avisado e o PIX libera com esse valor.`,
        textoBotao: 'Confirmar frete',
        aoConfirmar: async () => {
          const subtotal = p.subtotalItens ?? p.valorTotal;
          await updateDoc(doc(db, 'pedidos', id), {
            frete,
            valorTotal: Number((subtotal + frete).toFixed(2)),
            status: 'aguardando_pagamento',
            freteDefinidoEm: serverTimestamp()
          });
          try { await adminApi.notificarPedido(id, 'frete_definido'); } catch (err) { console.warn('Push não enviado:', err.message); }
          mostrarToast('Frete definido — pagamento liberado.');
          await carregarPedidos();
          document.getElementById('modalRoot').innerHTML = '';
          sugerirAvisoWhatsapp({ ...p, id }, MENSAGENS_WHATSAPP_STATUS.frete_definido({ ...p, id }));
        }
      });
    });
  }

  const imgComprovante = document.getElementById('imgComprovanteAdmin');
  if (imgComprovante) {
    imgComprovante.addEventListener('click', () => window.open(p.comprovanteUrl, '_blank'));
  }

  overlay.querySelectorAll('[data-mudar-status]').forEach(btn => {
    btn.addEventListener('click', () => {
      const novoStatus = btn.dataset.mudarStatus;

      if (p.cancelamentoSolicitado && novoStatus === 'despachado') {
        mostrarToast('❌ Cliente solicitou cancelamento. Não é possível despachar.', true);
        return;
      }

      confirmarAcao({
        titulo: novoStatus === 'cancelado' ? 'Cancelar pedido?' : `Marcar como "${ETAPAS_PEDIDO[novoStatus]}"?`,
        mensagem: novoStatus === 'pago'
          ? 'Isso desconta os itens do estoque e avisa o cliente (se ele tiver notificações ativadas).'
          : novoStatus === 'cancelado' && (p.status === 'pago' || p.status === 'despachado')
            ? 'O estoque já tinha sido baixado — cancelar agora vai devolver os itens ao estoque.'
            : 'O cliente será avisado, se tiver notificações ativadas.',
        textoBotao: 'Confirmar',
        classeBotao: novoStatus === 'cancelado' ? 'btn-danger' : 'btn-gold',
        aoConfirmar: async () => {
          await mudarStatusPedido(id, novoStatus);
          document.getElementById('modalRoot').innerHTML = '';
          if (MENSAGENS_WHATSAPP_STATUS[novoStatus]) {
            sugerirAvisoWhatsapp(pedidosCache.find(x => x.id === id) || p, MENSAGENS_WHATSAPP_STATUS[novoStatus](p));
          }
        }
      });
    });
  });
}

/* ============================================================================
   FATURAMENTO
   ============================================================================ */
async function carregarFaturamento() {
  const tbody = document.getElementById('faturamentoTableBody');
  tbody.innerHTML = `<tr><td colspan="6" class="loading-row"><div class="spinner" style="margin:0 auto;"></div></td></tr>`;
  try {
    const [snapVendas, snapPedidos] = await Promise.all([
      getDocs(collection(db, 'vendas')),
      getDocs(collection(db, 'pedidos'))
    ]);

    const linhasVendas = snapVendas.docs
      .map(d => ({ id: d.id, ...d.data() }))
      .filter(v => v.status === 'confirmada')
      .map(v => ({
        data: v.confirmadaEm || v.criadoEm,
        origem: 'Venda manual',
        cliente: v.clienteNome || '—',
        itensResumo: (v.itens || []).map(i => `${i.quantidade}× ${i.nome}`).join(', ') || '—',
        valor: v.valorTotal || 0,
        status: 'Confirmada'
      }));

    const linhasPedidos = snapPedidos.docs
      .map(d => ({ id: d.id, ...d.data() }))
      .filter(p => ['pago', 'despachado', 'entregue'].includes(p.status))
      .map(p => ({
        data: p.pagoEm || p.criadoEm,
        origem: 'Pedido site',
        cliente: p.comprador?.nome || '—',
        itensResumo: (p.itens || []).map(i => `${i.quantidade}× ${i.nome}`).join(', ') || '—',
        valor: p.valorTotal || 0,
        status: ETAPAS_PEDIDO[p.status] || p.status
      }));

    const todasLinhas = [...linhasVendas, ...linhasPedidos]
      .sort((a, b) => (b.data?.seconds || 0) - (a.data?.seconds || 0));

    renderFaturamento(todasLinhas);
  } catch (err) {
    console.error('Erro ao carregar faturamento:', err);
    tbody.innerHTML = `<tr><td colspan="6" class="loading-row">Erro ao carregar. Confira se as regras do Firestore foram publicadas.</td></tr>`;
  }
}

function renderFaturamento(linhas) {
  const tbody = document.getElementById('faturamentoTableBody');
  const total = linhas.reduce((soma, l) => soma + l.valor, 0);
  document.getElementById('faturamentoTotal').textContent = formatBRL(total);

  if (linhas.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" class="loading-row">Nada por aqui ainda — vendas confirmadas e pedidos pagos aparecem nessa lista.</td></tr>`;
    return;
  }

  tbody.innerHTML = linhas.map(l => `
    <tr>
      <td class="cell-muted">${l.data?.seconds ? new Date(l.data.seconds * 1000).toLocaleDateString('pt-BR') : '—'}</td>
      <td><span class="badge ${l.origem === 'Venda manual' ? '' : 'badge-ok'}">${l.origem}</span></td>
      <td>${l.cliente}</td>
      <td class="cell-muted" style="max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${l.itensResumo}</td>
      <td class="cell-mono">${formatBRL(l.valor)}</td>
      <td>${l.status}</td>
    </tr>
  `).join('');
}

/* ============================================================================
   RENDER DA TABELA GENÉRICA
   ============================================================================ */
function formatBRL(value) {
  if (value === undefined || value === null || value === '') return '—';
  return Number(value).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function obterNomeCategoria(categoriaId) {
  if (!categoriaId) return '—';
  const cat = dadosCache.categorias?.find(c => c.id === categoriaId);
  return cat?.nome || '—';
}

function renderTabela() {
  const ent = ENTIDADES[abaAtual];
  const termo = document.getElementById('adminSearch').value.trim().toLowerCase();
  let lista = dadosCache[abaAtual] || [];

  if (abaAtual === 'produtos') {
    lista = lista.map(item => ({
      ...item,
      categoriaNome: obterNomeCategoria(item.categoriaId)
    }));
  }

  if (termo) {
    lista = lista.filter(item =>
      ent.buscaCampos.some(campo => (item[campo] || '').toString().toLowerCase().includes(termo))
    );
  }

  document.getElementById('tabCount').textContent = `${lista.length} registro${lista.length !== 1 ? 's' : ''}`;

  const thead = document.getElementById('tableHead');
  thead.innerHTML = '<tr>' + ent.colunas.map(c => `<th>${c.label}</th>`).join('') + '<th></th></tr>';

  const tbody = document.getElementById('tableBody');
  if (lista.length === 0) {
    tbody.innerHTML = `<tr><td colspan="${ent.colunas.length + 1}" class="loading-row">Nenhum registro encontrado.</td></tr>`;
    return;
  }

  tbody.innerHTML = lista.map(item => {
    const celulas = ent.colunas.map(col => renderCelula(abaAtual, col, item)).join('');
    return `<tr class="tabela-linha" data-id="${item.id}" tabindex="0">
      ${celulas}
      <td>
        <div class="row-actions">
          <button class="btn btn-sm btn-ghost" data-action="edit" data-id="${item.id}">Editar</button>
          <button class="btn btn-sm btn-danger" data-action="delete" data-id="${item.id}">Excluir</button>
        </div>
      </td>
    </tr>`;
  }).join('');

  tbody.querySelectorAll('.tabela-linha').forEach(tr => {
    tr.addEventListener('click', (e) => {
      if (e.target.closest('[data-action="delete"]')) return;
      abrirFormulario(abaAtual, tr.dataset.id);
    });
  });
  tbody.querySelectorAll('[data-action="edit"]').forEach(btn =>
    btn.addEventListener('click', (e) => { e.stopPropagation(); abrirFormulario(abaAtual, btn.dataset.id); }));
  tbody.querySelectorAll('[data-action="delete"]').forEach(btn =>
    btn.addEventListener('click', (e) => { e.stopPropagation(); confirmarExclusao(abaAtual, btn.dataset.id); }));
}

function renderCelula(chave, col, item) {
  if (col.key === 'cidadeUf') {
    const texto = [item.cidade, item.uf].filter(Boolean).join(' / ');
    return `<td>${texto || '<span class="cell-muted">—</span>'}</td>`;
  }
  if (col.key === 'foto') {
    return `<td>${item.fotoUrl
      ? `<img src="${item.fotoUrl}" class="cell-thumb" data-action="edit" data-id="${item.id}" style="cursor:pointer;" title="Clique para editar e trocar a foto">`
      : `<div class="cell-thumb" data-action="edit" data-id="${item.id}" style="display:flex;align-items:center;justify-content:center;color:var(--muted-2);cursor:pointer;" title="Clique para editar e adicionar uma foto">◆</div>`}</td>`;
  }
  if (col.key === 'preco') {
    const { preco, precoOriginal, emPromocao } = precoEfetivo(item);
    const precoHtml = emPromocao
      ? `<span style="text-decoration:line-through;color:var(--muted-2);font-size:11px;">${formatBRL(precoOriginal)}</span> <span style="color:var(--danger);">${formatBRL(preco)}</span>`
      : formatBRL(item.valorAVista);
    return `<td class="cell-mono">${precoHtml}<br><span class="cell-muted">${formatBRL(item.valorPrazo)}${item.parcelas ? ' · ' + item.parcelas + 'x' : ''}</span></td>`;
  }
  if (col.key === 'estoque') {
    const v = item.estoque ?? 0;
    return `<td><span class="badge ${v > 0 ? 'badge-ok' : 'badge-out'}">${v > 0 ? v + ' un.' : 'zerado'}</span></td>`;
  }
  if (col.key === 'categoriaNome') {
    return `<td>${item.categoriaNome || '—'}</td>`;
  }
  if (col.key === 'status') {
    const ativo = item.ativo !== false;
    return `<td><span class="badge ${ativo ? 'badge-ok' : 'badge-out'}">${ativo ? 'Ativo' : 'Inativo'}</span></td>`;
  }
  return `<td>${item[col.key] || '<span class="cell-muted">—</span>'}</td>`;
}

/* ============================================================================
   FORMULÁRIO GENÉRICO
   ============================================================================ */
function abrirFormulario(chave, id) {
  const ent = ENTIDADES[chave];
  const item = id ? dadosCache[chave].find(x => x.id === id) : {};
  // Compatibilidade: produtos cadastrados antes desta funcionalidade só têm
  // `fotoUrl` (uma foto só, sem o array `fotos`). Ao editar um desses,
  // reaproveita fotoUrl como primeira foto da galeria em vez de começar
  // vazio — evita "perder" a foto que já existia ao simplesmente abrir o
  // formulário de edição.
  fotosSelecionadas = Array.isArray(item.fotos) && item.fotos.length
    ? [...item.fotos]
    : (item.fotoUrl ? [item.fotoUrl] : []);

  const camposHtml = ent.campos.map(campo => renderCampo(chave, campo, item)).join('');

  document.getElementById('modalRoot').innerHTML = `
    <div class="modal-overlay" id="formOverlay">
      <div class="modal" style="max-width:640px;">
        <div class="modal-form">
          <button class="modal-close" id="closeForm">✕</button>
          <h2 style="font-size:26px;margin-bottom:22px;">${id ? 'Editar' : ent.tituloNovo}</h2>
          <form id="entityForm">
            <div class="form-grid">${camposHtml}</div>
            <div class="modal-actions">
              <button type="button" class="btn btn-ghost" id="cancelForm">Cancelar</button>
              <button type="submit" class="btn btn-gold" id="saveBtn">${id ? 'Salvar alterações' : 'Cadastrar'}</button>
            </div>
          </form>
        </div>
      </div>
    </div>`;

  const overlay = document.getElementById('formOverlay');
  document.getElementById('closeForm').addEventListener('click', () => overlay.remove());
  document.getElementById('cancelForm').addEventListener('click', () => overlay.remove());

  ativarEventosGaleriaFotos(chave);

  const campoUf = document.getElementById('campo_uf');
  const campoCidade = document.getElementById('campo_cidade');
  if (campoUf && campoCidade) {
    if (campoUf.value) carregarCidadesPorUf(campoUf.value, campoCidade.dataset.valorAtual, campoCidade);
    campoUf.addEventListener('change', () => carregarCidadesPorUf(campoUf.value, null, campoCidade));
  }

  const campoCep = document.getElementById('campo_cep');
  if (campoCep) {
    campoCep.addEventListener('input', () => {
      let v = campoCep.value.replace(/\D/g, '').slice(0, 8);
      if (v.length > 5) v = v.slice(0, 5) + '-' + v.slice(5);
      campoCep.value = v;
    });
    campoCep.addEventListener('blur', () => {
      buscarEnderecoPorCep(campoCep.value, {
        uf: campoUf, cidade: campoCidade, endereco: document.getElementById('campo_endereco')
      });
    });
  }

  document.getElementById('entityForm').addEventListener('submit', (e) => {
    e.preventDefault();
    salvarEntidade(chave, id);
  });
}

function renderCampo(chave, campo, item) {
  const valor = item[campo.key];
  const largura = campo.largura === 'full' ? 'full' : '';

  if (campo.tipo === 'select-categoria') {
    const categorias = dadosCache.categorias || [];
    const opcoes = categorias.map(c =>
      `<option value="${c.id}" ${valor === c.id ? 'selected' : ''}>${c.nome}</option>`).join('');
    return `
      <div class="field ${largura}">
        <label>${campo.label}${campo.obrigatorio ? ' *' : ''}</label>
        <select id="campo_${campo.key}" ${campo.obrigatorio ? 'required' : ''}>
          <option value="">Selecione uma categoria</option>
          ${opcoes}
        </select>
      </div>`;
  }

  if (campo.tipo === 'galeria-fotos') {
    const miniaturas = fotosSelecionadas.map((foto, i) => `
      <div class="galeria-foto-item" data-foto-idx="${i}" style="position:relative;width:72px;height:72px;border-radius:6px;overflow:hidden;border:2px solid ${i === 0 ? 'var(--gold-bright)' : 'var(--border-soft)'};">
        <img src="${foto}" style="width:100%;height:100%;object-fit:cover;">
        ${i === 0 ? '<span style="position:absolute;bottom:0;left:0;right:0;background:rgba(0,0,0,.6);color:var(--gold-bright);font-size:9px;text-align:center;padding:1px 0;">CAPA</span>' : ''}
        <button type="button" class="galeria-foto-remover" data-remover-idx="${i}" title="Remover" style="position:absolute;top:1px;right:1px;background:rgba(0,0,0,.65);color:#fff;border:none;width:18px;height:18px;border-radius:50%;font-size:11px;line-height:1;cursor:pointer;">✕</button>
        ${i !== 0 ? `<button type="button" class="galeria-foto-capa" data-capa-idx="${i}" title="Definir como capa" style="position:absolute;bottom:1px;left:1px;background:rgba(0,0,0,.65);color:#fff;border:none;font-size:9px;padding:1px 4px;border-radius:3px;cursor:pointer;">Capa</button>` : ''}
      </div>`).join('');
    const podeAdicionar = fotosSelecionadas.length < MAX_FOTOS_PRODUTO;
    return `
      <div class="field full">
        <label>${campo.label}</label>
        <div id="galeriaFotosWrap" style="display:flex;flex-wrap:wrap;gap:10px;align-items:center;">
          ${miniaturas}
          ${podeAdicionar ? `
            <div class="photo-upload" id="galeriaFotoAddBtn" role="button" tabindex="0" style="width:72px;height:72px;display:flex;align-items:center;justify-content:center;">
              <div class="hint" style="font-size:11px;text-align:center;">+ Foto</div>
            </div>` : ''}
          <input type="file" id="galeriaFotoInput" accept="image/*" style="display:none;">
        </div>
        <span class="field-hint">${fotosSelecionadas.length}/${MAX_FOTOS_PRODUTO} fotos — clique em "Capa" numa miniatura para trocar a foto principal do catálogo.</span>
      </div>`;
  }


  if (campo.tipo === 'cep') {
    return `
      <div class="field ${largura}">
        <label>${campo.label}</label>
        <input type="text" id="campo_${campo.key}" value="${valor ?? ''}"
          placeholder="${campo.placeholder || '00000-000'}" maxlength="9" inputmode="numeric">
        <span class="field-hint" id="cepHint"></span>
      </div>`;
  }

  if (campo.tipo === 'uf') {
    const opcoes = UF_LIST.map(([sigla, nomeUf]) =>
      `<option value="${sigla}" ${valor === sigla ? 'selected' : ''}>${sigla} — ${nomeUf}</option>`).join('');
    return `
      <div class="field ${largura}">
        <label>${campo.label}</label>
        <select id="campo_${campo.key}">
          <option value="">Selecione</option>
          ${opcoes}
        </select>
      </div>`;
  }

  if (campo.tipo === 'cidade') {
    return `
      <div class="field ${largura}">
        <label>${campo.label}</label>
        <select id="campo_${campo.key}" data-valor-atual="${valor ?? ''}" ${valor ? '' : 'disabled'}>
          <option value="${valor ?? ''}">${valor || 'Selecione o UF primeiro'}</option>
        </select>
      </div>`;
  }

  if (campo.tipo === 'select-fornecedor') {
    const opcoes = dadosCache.fornecedores.map(f =>
      `<option value="${f.id}" ${valor === f.id ? 'selected' : ''}>${f.nome}</option>`).join('');
    return `
      <div class="field ${largura}">
        <label>${campo.label}</label>
        <select id="campo_${campo.key}">
          <option value="">Nenhum</option>
          ${opcoes}
        </select>
      </div>`;
  }

  if (campo.tipo === 'checkbox') {
    const marcado = valor === undefined ? campo.padrao : valor;
    return `
      <div class="field ${largura}" style="display:flex;align-items:center;gap:10px;margin-top:26px;">
        <input type="checkbox" id="campo_${campo.key}" ${marcado ? 'checked' : ''} style="width:16px;height:16px;">
        <label style="margin:0;text-transform:none;letter-spacing:0;font-size:13px;color:var(--ivory);">${campo.label}</label>
      </div>`;
  }

  if (campo.tipo === 'textarea') {
    return `
      <div class="field ${largura}">
        <label>${campo.label}</label>
        <textarea id="campo_${campo.key}" rows="3" placeholder="${campo.placeholder || ''}">${valor || ''}</textarea>
      </div>`;
  }

  return `
    <div class="field ${largura}">
      <label>${campo.label}${campo.obrigatorio ? ' *' : ''}</label>
      <input type="${campo.tipo}" id="campo_${campo.key}" value="${valor ?? ''}"
        placeholder="${campo.placeholder || ''}" ${campo.obrigatorio ? 'required' : ''} ${campo.tipo === 'number' ? 'step="0.01"' : ''}>
    </div>`;
}

// Re-renderiza só o bloco da galeria (sem reabrir o formulário inteiro),
// depois de adicionar, remover ou trocar a foto de capa.
function rerenderGaleriaFotos(chave, item) {
  const campo = ENTIDADES[chave].campos.find(c => c.tipo === 'galeria-fotos');
  if (!campo) return;
  const wrapPai = document.getElementById('galeriaFotosWrap')?.closest('.field');
  if (!wrapPai) return;
  wrapPai.outerHTML = renderCampo(chave, campo, item);
  ativarEventosGaleriaFotos(chave);
}

function ativarEventosGaleriaFotos(chave) {
  const addBtn = document.getElementById('galeriaFotoAddBtn');
  const input = document.getElementById('galeriaFotoInput');
  if (addBtn && input) {
    addBtn.addEventListener('click', () => input.click());
    addBtn.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); input.click(); }
    });
  }
  if (input) {
    input.addEventListener('change', async (e) => {
      const file = e.target.files[0];
      input.value = '';
      if (!file) return;
      if (fotosSelecionadas.length >= MAX_FOTOS_PRODUTO) return;
      try {
        const base64 = await comprimirImagem(file);
        fotosSelecionadas.push(base64);
        rerenderGaleriaFotos(chave, {});
      } catch (err) {
        console.error(err);
        mostrarToast('Não foi possível processar a imagem. Tente outro arquivo.', true);
      }
    });
  }
  document.querySelectorAll('[data-remover-idx]').forEach(btn => {
    btn.addEventListener('click', () => {
      fotosSelecionadas.splice(Number(btn.dataset.removerIdx), 1);
      rerenderGaleriaFotos(chave, {});
    });
  });
  document.querySelectorAll('[data-capa-idx]').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = Number(btn.dataset.capaIdx);
      const [foto] = fotosSelecionadas.splice(idx, 1);
      fotosSelecionadas.unshift(foto);
      rerenderGaleriaFotos(chave, {});
    });
  });
}

async function salvarEntidade(chave, id) {
  const ent = ENTIDADES[chave];

  // Documentos do Firestore têm limite rígido de 1MB — checa ANTES de
  // tentar salvar, pra dar um aviso claro em vez do cliente receber um
  // erro genérico de rede caso as fotos somadas estourem o limite.
  if (chave === 'produtos') {
    const totalKB = fotosSelecionadas.reduce((soma, f) => soma + tamanhoBase64KB(f), 0);
    if (totalKB > 950) {
      mostrarToast(`As fotos somam ${totalKB} KB — passou do limite do banco de dados. Remova uma foto ou use imagens mais simples.`, true);
      return;
    }
  }

  const saveBtn = document.getElementById('saveBtn');
  saveBtn.disabled = true;
  saveBtn.textContent = 'Salvando...';

  try {
    const dados = {};
    for (const campo of ent.campos) {
      if (campo.tipo === 'foto' || campo.tipo === 'galeria-fotos') continue;
      const el = document.getElementById(`campo_${campo.key}`);
      if (!el) continue;
      if (campo.tipo === 'checkbox') dados[campo.key] = el.checked;
      else if (campo.tipo === 'number') dados[campo.key] = el.value === '' ? null : Number(el.value);
      else dados[campo.key] = el.value.trim();
    }

    // `fotos` é o array completo da galeria (ordem = ordem de exibição,
    // a primeira é a capa). `fotoUrl` continua sendo escrito com a mesma
    // primeira foto — é o campo que o restante do app (tabela do admin,
    // card do carrinho, e qualquer outra versão que só conheça fotoUrl)
    // sempre leu, então mantê-lo em sincronia evita ter que atualizar
    // código que já funciona.
    if (chave === 'produtos') {
      dados.fotos = fotosSelecionadas;
      dados.fotoUrl = fotosSelecionadas[0] || null;
    }

    if (id) {
      await updateDoc(doc(db, ent.colecao, id), dados);
      const idx = dadosCache[chave].findIndex(x => x.id === id);
      if (idx > -1) dadosCache[chave][idx] = { ...dadosCache[chave][idx], ...dados };
      mostrarToast('Registro atualizado com sucesso.');
    } else {
      dados.criadoEm = serverTimestamp();
      const ref = await addDoc(collection(db, ent.colecao), dados);
      dadosCache[chave].push({ id: ref.id, ...dados, criadoEm: { seconds: Date.now() / 1000 } });
      mostrarToast('Registro cadastrado com sucesso.');
    }

    document.getElementById('formOverlay').remove();
    renderTabela();
  } catch (err) {
    console.error('Erro ao salvar:', err);
    mostrarToast('Erro ao salvar. Verifique os dados e as permissões do Firebase.', true);
  } finally {
    saveBtn.disabled = false;
    saveBtn.textContent = id ? 'Salvar alterações' : 'Cadastrar';
  }
}

/* ============================================================================
   EXCLUSÃO COM INTEGRIDADE REFERENCIAL - CORRIGIDA
   ============================================================================ */

async function categoriaTemProdutos(categoriaId) {
  const q = query(collection(db, 'produtos'), where('categoriaId', '==', categoriaId), limit(1));
  const snap = await getDocs(q);
  return !snap.empty;
}

async function produtoTemVinculos(produtoId) {
  const vendasSnap = await getDocs(collection(db, 'vendas'));
  for (const docSnap of vendasSnap.docs) {
    const data = docSnap.data();
    const itens = data.itens || [];
    if (itens.some(item => item.produtoId === produtoId)) {
      return 'vendas';
    }
  }

  const pedidosSnap = await getDocs(collection(db, 'pedidos'));
  for (const docSnap of pedidosSnap.docs) {
    const data = docSnap.data();
    const itens = data.itens || [];
    if (itens.some(item => item.produtoId === produtoId)) {
      return 'pedidos';
    }
  }

  const comprasSnap = await getDocs(collection(db, 'compras'));
  for (const docSnap of comprasSnap.docs) {
    const data = docSnap.data();
    const itens = data.itens || [];
    if (itens.some(item => item.produtoId === produtoId)) {
      return 'compras';
    }
  }

  return null;
}

async function clienteTemVinculos(clienteId) {
  const vendasSnap = await getDocs(collection(db, 'vendas'));
  for (const docSnap of vendasSnap.docs) {
    const data = docSnap.data();
    if (data.clienteId === clienteId) {
      return 'vendas';
    }
  }

  const pedidosSnap = await getDocs(collection(db, 'pedidos'));
  for (const docSnap of pedidosSnap.docs) {
    const data = docSnap.data();
    if (data.compradorUid === clienteId) {
      return 'pedidos';
    }
  }

  return null;
}

async function fornecedorTemCompras(fornecedorId) {
  const comprasSnap = await getDocs(collection(db, 'compras'));
  for (const docSnap of comprasSnap.docs) {
    const data = docSnap.data();
    if (data.fornecedorId === fornecedorId) {
      return true;
    }
  }
  return false;
}

async function verificarBloqueioExclusao(chave, id) {
  const item = dadosCache[chave]?.find(x => x.id === id);
  const nome = item?.nome || 'este registro';

  switch (chave) {
    case 'categorias': {
      const temProdutos = await categoriaTemProdutos(id);
      if (temProdutos) {
        return `Não é possível excluir a categoria "${nome}": há produtos vinculados a ela. Remova ou reassigne os produtos primeiro.`;
      }
      return null;
    }
    case 'produtos': {
      const vinculo = await produtoTemVinculos(id);
      if (vinculo === 'vendas') {
        return `Não é possível excluir o produto "${nome}": há vendas registradas com este produto.`;
      }
      if (vinculo === 'pedidos') {
        return `Não é possível excluir o produto "${nome}": há pedidos registrados com este produto.`;
      }
      if (vinculo === 'compras') {
        return `Não é possível excluir o produto "${nome}": há compras registradas com este produto.`;
      }
      return null;
    }
    case 'clientes': {
      const vinculo = await clienteTemVinculos(id);
      if (vinculo === 'vendas') {
        return `Não é possível excluir o cliente "${nome}": há vendas registradas para este cliente.`;
      }
      if (vinculo === 'pedidos') {
        return `Não é possível excluir o cliente "${nome}": há pedidos registrados para este cliente.`;
      }
      return null;
    }
    case 'fornecedores': {
      const temCompras = await fornecedorTemCompras(id);
      if (temCompras) {
        return `Não é possível excluir o fornecedor "${nome}": há compras registradas com este fornecedor.`;
      }
      return null;
    }
    default:
      return null;
  }
}

function confirmarExclusao(chave, id) {
  const item = dadosCache[chave]?.find(x => x.id === id);
  const nome = item?.nome || 'este registro';

  document.getElementById('modalRoot').innerHTML = `
    <div class="modal-overlay" id="delOverlay">
      <div class="modal" style="max-width:400px;">
        <div class="modal-form">
          <h2 style="font-size:22px;">Excluir registro?</h2>
          <p style="margin-top:10px;">Tem certeza que deseja excluir <strong style="color:var(--ivory);">${nome}</strong>? Essa ação não pode ser desfeita.</p>
          <div id="delVerificando" style="font-size:12px;color:var(--muted-2);margin-top:8px;">Verificando vínculos...</div>
          <div class="modal-actions">
            <button class="btn btn-ghost" id="cancelDel">Cancelar</button>
            <button class="btn btn-danger" id="confirmDel" disabled>Excluir</button>
          </div>
        </div>
      </div>
    </div>`;

  const overlay = document.getElementById('delOverlay');
  document.getElementById('cancelDel').addEventListener('click', () => overlay.remove());
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });

  const confirmBtn = document.getElementById('confirmDel');
  const verificando = document.getElementById('delVerificando');

  verificarBloqueioExclusao(chave, id).then(bloqueio => {
    if (bloqueio) {
      verificando.textContent = '❌ ' + bloqueio;
      verificando.style.color = 'var(--danger)';
      confirmBtn.disabled = true;
    } else {
      verificando.textContent = '✅ Nenhum vínculo encontrado. Pode excluir.';
      verificando.style.color = 'var(--success)';
      confirmBtn.disabled = false;
    }
  }).catch(err => {
    verificando.textContent = '⚠️ Erro ao verificar vínculos. Tente novamente.';
    verificando.style.color = 'var(--danger)';
    confirmBtn.disabled = true;
    console.error(err);
  });

  document.getElementById('confirmDel').addEventListener('click', async () => {
    const btn = document.getElementById('confirmDel');
    btn.disabled = true;
    btn.textContent = 'Excluindo...';
    try {
      await deleteDoc(doc(db, ENTIDADES[chave].colecao, id));
      dadosCache[chave] = dadosCache[chave].filter(x => x.id !== id);
      mostrarToast('Registro excluído.');
      overlay.remove();
      renderTabela();
    } catch (err) {
      console.error('Erro ao excluir:', err);
      mostrarToast('Erro ao excluir o registro.', true);
      btn.disabled = false;
      btn.textContent = 'Excluir';
    }
  });
}

/* ============================================================================
   TOAST
   ============================================================================ */
function mostrarToast(msg, erro = false) {
  const root = document.getElementById('toastRoot');
  const el = document.createElement('div');
  el.className = 'toast' + (erro ? ' error' : '');
  el.innerHTML = `<span class="dot"></span>${msg}`;
  root.appendChild(el);
  requestAnimationFrame(() => el.classList.add('show'));
  setTimeout(() => {
    el.classList.remove('show');
    setTimeout(() => el.remove(), 300);
  }, 3200);
}

function showToast(msg) {
  const root = document.getElementById('toastRoot');
  if (!root) return;
  const el = document.createElement('div');
  el.style.cssText = `
    background: var(--surface); color: var(--text); border: 1px solid var(--border);
    padding: 12px 20px; border-radius: var(--radius); font-size: 13px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.3); margin-bottom: 10px;
    opacity: 0; transform: translateY(10px); transition: all 0.3s ease;
    pointer-events: none; max-width: 320px;
  `;
  el.textContent = msg;
  root.appendChild(el);
  requestAnimationFrame(() => { el.style.opacity = '1'; el.style.transform = 'translateY(0)'; });
  setTimeout(() => {
    el.style.opacity = '0'; el.style.transform = 'translateY(10px)';
    setTimeout(() => el.remove(), 300);
  }, 3000);
}

/* ============================================================================
   NOTIFICAÇÕES PUSH
   ============================================================================ */

async function carregarContadorNotificacoes() {
  try {
    const snap = await getDocs(collection(db, 'fcmTokens'));
    document.getElementById('notifContador').textContent = snap.size;
  } catch (err) {
    document.getElementById('notifContador').textContent = '—';
    console.error('Erro ao contar tokens:', err);
  }
}

document.getElementById('enviarNotifBtn').addEventListener('click', async () => {
  const titulo = document.getElementById('notifTitulo').value.trim();
  const corpo = document.getElementById('notifCorpo').value.trim();
  const link = document.getElementById('notifLink').value.trim();
  const statusEl = document.getElementById('notifStatus');
  const btn = document.getElementById('enviarNotifBtn');

  if (!titulo || !corpo) {
    statusEl.textContent = 'Preencha título e corpo da mensagem.';
    statusEl.style.color = 'var(--danger)';
    return;
  }

  btn.disabled = true;
  btn.textContent = 'Enviando...';
  statusEl.textContent = '';

  try {
    const resp = await adminApi.enviarNotificacao({ titulo, corpo, link });
    document.getElementById('notifEnviados').textContent = resp.enviados;
    document.getElementById('notifFalhas').textContent = resp.falhas;
    statusEl.textContent = `Enviado para ${resp.enviados} de ${resp.total} dispositivos${resp.removidos ? ` (${resp.removidos} inválidos removidos)` : ''}.`;
    statusEl.style.color = 'var(--success)';
    showToast(`Notificação enviada para ${resp.enviados} dispositivos!`);
    document.getElementById('notifTitulo').value = '';
    document.getElementById('notifCorpo').value = '';
    document.getElementById('notifLink').value = '';
  } catch (err) {
    statusEl.textContent = err.message || 'Erro ao enviar notificação.';
    statusEl.style.color = 'var(--danger)';
    showToast('Erro ao enviar notificação.');
  } finally {
    btn.disabled = false;
    btn.textContent = '📨 Enviar para todos os inscritos';
  }
});