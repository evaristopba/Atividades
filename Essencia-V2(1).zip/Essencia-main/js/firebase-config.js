// ============================================================================
// CONFIGURAÇÃO DO FIREBASE — PREENCHA COM OS DADOS REAIS DO SEU PROJETO
// ============================================================================
//
// COMO OBTER OS DADOS:
// 1. Acesse https://console.firebase.google.com/
// 2. Clique no seu projeto
// 3. Clique no ícone de engrenagem (⚙️) ao lado de "Visão geral do projeto"
// 4. Vá em "Configurações do projeto" → aba "Geral"
// 5. Role até "Seus apps" e clique no app Web (ou crie um novo)
// 6. Copie o objeto firebaseConfig e cole AQUI, substituindo TODO o objeto abaixo
//
// EXEMPLO de como deve ficar (valores fictícios):
//   apiKey: "AIzaSyABC123...",
//   authDomain: "meu-projeto-12345.firebaseapp.com",
//   projectId: "meu-projeto-12345",
//   storageBucket: "meu-projeto-12345.appspot.com",
//   messagingSenderId: "123456789012",
//   appId: "1:123456789012:web:abc123def456"
//
// ⚠️ NÃO deixe os placeholders abaixo, senão o login não funciona!
// ============================================================================

export const firebaseConfig = {
  apiKey: "AIzaSyDh_AqBiKhzuqmAdOuvux7aGvBvzl_6h2U",
  authDomain: "toque-zen.firebaseapp.com",
  projectId: "toque-zen",
  storageBucket: "toque-zen.firebasestorage.app",
  messagingSenderId: "778431982220",
  appId: "1:778431982220:web:df14feec23b50818d2e9a9"
};

// SDK do Firebase via CDN (módulos ES) — versão 10.x
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import {
  getFirestore, collection, doc, getDoc, getDocs, addDoc, setDoc,
  updateDoc, deleteDoc, query, orderBy, where, limit, onSnapshot, serverTimestamp,
  runTransaction
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import {
  getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, onAuthStateChanged,
  sendPasswordResetEmail, GoogleAuthProvider, signInWithPopup,
  reauthenticateWithCredential, EmailAuthProvider, updatePassword
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import {
  getMessaging, getToken, onMessage
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-messaging.js";

export const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

// Verificação: alerta no console se ainda estiver com placeholder
if (firebaseConfig.apiKey.includes('COLE') || firebaseConfig.projectId.includes('SEU')) {
  console.error('⚠️ FIREBASE NÃO CONFIGURADO: edite js/firebase-config.js com os dados reais do seu projeto Firebase. Veja as instruções no topo do arquivo.');
}

// Firebase Messaging não é suportado em todo navegador/contexto (Safari
// mais antigo, navegadores embutidos de app como Instagram/Facebook,
// contexto sem HTTPS, etc.) — e getMessaging() lança um erro SÍNCRONO
// nesses casos. Como este arquivo é importado tanto por public.js quanto
// por admin.js, um erro aqui sem proteção quebrava o módulo inteiro,
// derrubando junto a tela de login do admin. Por isso o try/catch: quando
// não suportado, `messaging` fica null e o app funciona normalmente sem
// a funcionalidade de notificações push.
let messagingInstance = null;
try {
  messagingInstance = getMessaging(app);
} catch (err) {
  console.warn('Firebase Messaging não suportado neste navegador/contexto — notificações push ficam desativadas, o resto do app funciona normalmente:', err.message);
}
export const messaging = messagingInstance;

export {
  // Firestore
  collection, doc, getDoc, getDocs, addDoc, setDoc, updateDoc, deleteDoc,
  query, orderBy, where, limit, onSnapshot, serverTimestamp, runTransaction,
  // Auth
  signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, onAuthStateChanged,
  sendPasswordResetEmail, GoogleAuthProvider, signInWithPopup,
  // Messaging
  getToken, onMessage,
  // Auth - reautenticação e troca de senha
  reauthenticateWithCredential, EmailAuthProvider, updatePassword
};