// ============================================================================
// js/seguranca.js
// ============================================================================
// Funções pequenas, sem dependências externas, para reduzir o risco de XSS
// ao renderizar dados que NÃO são controlados pelo admin — vêm do carrinho
// público ou do próprio cliente: nome/telefone/endereço do comprador, motivo
// de cancelamento, comprovante de pagamento.
//
// Regra prática usada no restante do app a partir desta correção:
//   - Todo texto vindo de `comprador`, `motivoCancelamento` ou qualquer outro
//     campo que o cliente possa escrever, ao entrar em innerHTML, passa por
//     escapeHtml() antes.
//   - Todo valor usado como src="" ou href="" de um elemento (ex.: o
//     comprovante em base64) passa primeiro por isDataUriComprovanteValida().
//
// Isso é uma segunda camada de defesa: a validação "de verdade" já acontece
// nas regras do Firestore (firestore.rules), mas o front-end não deve
// confiar cegamente nisso — regras podem mudar, e um cliente Firestore mal
// configurado em outra tela do mesmo projeto não deveria virar um vetor de
// ataque para quem só está lendo a tela.
// ============================================================================

const MAPA_ESCAPE = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };

/**
 * Escapa texto antes de inserir via innerHTML/template string em HTML.
 * Use em QUALQUER dado que não tenha vindo do próprio admin (nome, telefone,
 * endereço do comprador, motivo de cancelamento, etc.).
 */
export function escapeHtml(valor) {
  return String(valor ?? '').replace(/[&<>"']/g, (c) => MAPA_ESCAPE[c]);
}

// Mesma checagem de formato usada em firestore.rules para o comprovante:
// só imagens comuns ou PDF, como data-URI base64. Mantenha os dois em sincronia
// se um dia mudar o formato aceito.
const REGEX_DATA_URI_COMPROVANTE = /^data:(image\/(png|jpe?g|webp)|application\/pdf);base64,[A-Za-z0-9+/=]+$/;

/**
 * Confirma que uma string é um data-URI base64 de um dos formatos aceitos
 * para comprovante de pagamento. Retorna false para qualquer outra coisa
 * (inclusive strings vazias, URLs comuns, ou payloads de injeção).
 */
export function isDataUriComprovanteValida(valor) {
  return typeof valor === 'string' && REGEX_DATA_URI_COMPROVANTE.test(valor);
}
