# Essência — App de Perfumaria (Firebase/Firestore + Vercel)

App web completo para uma perfumaria: **catálogo público com carrinho de compras**, **checkout com PIX**, **acompanhamento de pedido para o cliente**, e um **painel administrativo** com dois níveis de acesso para gerir produtos, **categorias**, clientes, fornecedores, vendas, compras, pedidos online, faturamento consolidado, notificações push e administradores.

Feito para rodar 100% de graça: Firebase no plano **Spark** (sem cartão de crédito) + Vercel no plano **Hobby**, sem gateway de pagamento, sem Cloud Functions pagas.

---

## Sumário

1. [Arquitetura](#arquitetura)
2. [Estrutura de arquivos](#estrutura-de-arquivos)
3. [Setup do Firebase](#setup-do-firebase)
4. [Deploy — GitHub + Vercel](#deploy--github--vercel)
5. [Papéis: Proprietário × Operador](#papéis-proprietário--operador)
6. [Fluxo do cliente](#fluxo-do-cliente)
7. [Painel administrativo](#painel-administrativo)
8. [Categorias](#categorias)
9. [Integridade referencial e bloqueios de exclusão](#integridade-referencial-e-bloqueios-de-exclusão)
10. [Notificações push](#notificações-push)
11. [Pix](#pix--como-funciona-e-o-que-não-faz)
12. [Frete](#frete-entrega-combinada-com-o-vendedor)
13. [Cancelamento e prazos](#cancelamento-e-prazo-de-pagamento)
14. [Contas de cliente e endereços](#contas-de-cliente-login-obrigatório-para-finalizar-pedido)
15. [Modelo de dados](#modelo-de-dados)
16. [Segurança — resumo](#segurança--resumo)
17. [Testando localmente](#testando-localmente)
18. [Limitações conhecidas](#limitações-conhecidas)
19. [Personalização](#personalização)
20. [Migração para categorias](#migração-para-categorias)

---

## Arquitetura

- **Frontend**: HTML/CSS/JS puro, sem build, sem framework. Firebase via CDN (módulos ES).
- **Banco de dados**: Firestore. Fotos de produto e comprovantes de pagamento são comprimidos no navegador e salvos como base64 dentro do próprio documento — **não usa Firebase Storage**, então roda 100% no plano gratuito.
- **Backend**: só o estritamente necessário, como funções serverless da própria **Vercel** (não Cloud Functions do Firebase, que exigem plano pago):
  - `api/gerenciar-admin.js` — cria/exclui administradores e define papéis (owner/operador), via **custom claims** do Firebase Auth. É a única forma confiável de gravar um papel, porque o navegador nunca pode fazer isso sozinho.
  - `api/criar-pedido.js` — recebe o carrinho do cliente e calcula o preço real no servidor (nunca confia no valor que o navegador envia).
  - `api/enviar-notificacao.js` e `api/notificar-pedido.js` — disparam notificações push via Firebase Cloud Messaging.
- Todas usam o **Firebase Admin SDK**, autenticado por uma chave de conta de serviço guardada como variável de ambiente na Vercel (nunca no código).

---

## Estrutura de arquivos


perfumaria-app/
├── index.html → Catálogo público + carrinho + botão WhatsApp
├── pedido.html → Acompanhamento de pedido (cliente)
├── admin.html → Login e painel administrativo
├── firebase-messaging-sw.js → Service worker de notificações push (precisa da MESMA config do Firebase)
├── firestore.rules → Regras de segurança do Firestore
├── package.json → Dependência firebase-admin (usada pelas funções em /api)
├── .vercelignore → Evita publicar firestore.rules/README como arquivo do site
├── api/
│ ├── gerenciar-admin.js → Cria/exclui admins e define papéis (owner/operador)
│ ├── criar-pedido.js → PÚBLICA (exige login) — cria pedido, calcula preço no servidor
│ ├── enviar-notificacao.js → Push broadcast pra quem está inscrito (admin dispara manualmente)
│ └── notificar-pedido.js → Push pro cliente de UM pedido específico, ao mudar de status
├── css/
│ └── style.css → Estilo (visual único de perfumaria)
└── js/
├── firebase-config.js → Config do Firebase (você precisa preencher)
├── admin-api.js → Cliente HTTP que fala com as funções /api/* protegidas por login
├── conta-cliente.js → Login/cadastro de cliente, perfil, endereços, meus pedidos (compartilhado)
├── pix.js → Gera o payload Pix Copia e Cola (offline, sem gateway)
├── public.js → Catálogo público, carrinho, checkout
├── pedido.js → Página de acompanhamento de pedido
└── admin.js → Painel: CRUD + papéis + vendas/compras/pedidos/faturamento


---

## Setup do Firebase

### 1. Criar o projeto
1. [console.firebase.google.com](https://console.firebase.google.com/) → criar projeto (plano **Spark**, gratuito).
2. **Authentication → Sign-in method** → ative **E-mail/senha** e **Google**. O Google é usado tanto pelo login do admin quanto pelo dos clientes — qualquer conta Google consegue logar, mas isso é seguro porque o acesso de admin depende do papel (custom claim), não de "estar logado" (ver seção de Segurança).
3. **Firestore Database** → criar banco (modo produção, região ex: `southamerica-east1`).
4. **Project Settings → Cloud Messaging** → na aba "Web configuration", clique em **"Generate key pair"** para gerar a chave VAPID (necessária pra notificações push — ver seção própria abaixo).

### 2. Criar o primeiro administrador
**Authentication → Users → Add user** e cadastre e-mail e senha. Esse é o único cadastro manual necessário — na primeira vez que essa conta logar no painel (`admin.html`), o app promove ela automaticamente a **proprietário** (fluxo de "bootstrap": só funciona enquanto não existir nenhum proprietário no projeto).

### 3. Pegar as credenciais do app web
**Configurações do projeto → Seus apps** → ícone `</>` (Web) → copie o objeto `firebaseConfig` e cole em `js/firebase-config.js`, no lugar dos placeholders.

**Importante**: cole esse MESMO objeto também dentro de `firebase-messaging-sw.js` (ver comentário no topo do arquivo) — o service worker de notificações não consegue importar `js/firebase-config.js`, precisa da própria cópia.

### 4. Gerar a credencial de servidor
1. **Configurações do projeto → Contas de serviço → Gerar nova chave privada**. Baixa um arquivo `.json`.
2. Guarde com cuidado — dá acesso administrativo total ao projeto. **Nunca** commite esse arquivo no Git.
3. O conteúdo inteiro vai virar uma variável de ambiente na Vercel (próxima seção).

### 5. Publicar as regras do Firestore
**Firestore Database → Regras** → cole o conteúdo de `firestore.rules` → publique. Sempre que esse arquivo mudar no projeto, repita esse passo — atualizar o arquivo local não atualiza sozinho o que está publicado.

---

## Deploy — GitHub + Vercel

1. Confirme que `js/firebase-config.js` e `firebase-messaging-sw.js` estão preenchidos com as credenciais reais. **Não** suba o `.json` da conta de serviço.
2. Suba a pasta inteira pra um repositório no GitHub (de preferência na sua conta pessoal — repositórios em organizações exigem plano pago na Vercel).
3. Na [Vercel](https://vercel.com) → **Add New → Project** → selecione o repositório. Framework Preset: **Other**. A Vercel roda `npm install` sozinha (só pra instalar `firebase-admin`, usado pelas funções em `/api` — o site continua estático).
4. Em **Settings → Environment Variables**, adicione:
   - **Nome**: `FIREBASE_SERVICE_ACCOUNT`
   - **Valor**: conteúdo completo do `.json` da conta de serviço.
5. Deploy. Depois, no Console do Firebase → **Authentication → Settings → Authorized domains**, adicione o domínio que a Vercel gerou.

⚠️ Se por engano você já commitou a chave de serviço alguma vez, gere uma nova (a antiga fica comprometida) e revogue a antiga em **Contas de serviço**.

---

## Papéis: Proprietário × Operador

- **Proprietário (`owner`)**: acesso total — inclusive **Administradores** (criar/excluir logins, mudar papéis) e **Configurações** (WhatsApp e PIX).
- **Operador (`operador`)**: gerencia Produtos, Categorias, Clientes, Fornecedores, Vendas, Compras e Pedidos. Administradores e Configurações ficam ocultos e bloqueados — tanto na interface quanto nas regras do Firestore.
- Ninguém consegue alterar o próprio papel nem se autoexcluir — sempre precisa de outro proprietário.
- **Contas de cliente não têm papel nenhum** — mesmo autenticadas pelo mesmo Firebase Auth, não têm acesso a nada do painel administrativo (ver [Segurança](#segurança--resumo)).

### Se você já tinha administradores cadastrados antes do sistema de papéis existir
Cada admin precisa logar **uma vez** depois do deploy: o primeiro vira proprietário automaticamente; os demais ficam **bloqueados** numa tela de "Acesso negado" (nenhuma aba chega a carregar dado nenhum) até o proprietário atribuir um papel na aba Administradores. Isso vale também pra qualquer sessão de cliente que por acaso já esteja logada no mesmo navegador ao abrir `admin.html` — o Firebase Auth reaproveita sessões entre páginas do mesmo site, mas sem papel a tela trava mesmo assim.

---

## Fluxo do cliente

1. **Catálogo** (`index.html`): busca, filtro por categoria, detalhe do produto — tudo sem login.
2. **Carrinho**: adicionar/remover itens também não exige login — só guarda estado no navegador (localStorage).
3. **Checkout ("Finalizar pedido")**: aqui sim, login é obrigatório — e-mail/senha ou "Continuar com Google". Pede nome, telefone, e escolha entre **retirar na loja** ou **entrega**.
   - Retirada: pedido nasce direto como `aguardando_pagamento`, com PIX já gerado.
   - Entrega: pedido nasce como `aguardando_frete` (ver seção própria) — o admin combina o valor da entrega antes do PIX ser liberado.
4. **Endereço de entrega**: se o cliente já tiver conta, escolhe entre os endereços salvos (com um marcado como principal) ou cadastra um novo ali mesmo, com CEP puxando rua/bairro/cidade/UF automaticamente.
5. **Pagamento**: QR code / código Pix Copia e Cola, gerado no navegador. O cliente pode anexar um comprovante (opcional, mas ajuda o admin a confirmar mais rápido).
6. **Acompanhamento** (`pedido.html?id=...`): timeline visual do status, sem precisar de login (o link em si já funciona como "número de rastreio"). Se o cliente estiver logado como dono do pedido, também pode trocar o endereço ou cancelar, dependendo do status (ver seções de Frete e Cancelamento).
7. **Minha conta**: nome, telefone, endereços salvos (múltiplos, um principal) e "Meus pedidos" (lista real, consultada pelo Firestore).

---

## Painel administrativo

Login em `admin.html` (e-mail/senha, com "Esqueci minha senha").

- **Categorias**: CRUD completo. Gerencie categorias para organizar os produtos. A leitura é pública (usada no filtro do catálogo), mas apenas administradores podem criar, editar ou excluir. Uma categoria com produtos vinculados **não pode ser excluída** (ver [Integridade referencial](#integridade-referencial-e-bloqueios-de-exclusão)).
- **Produtos**: CRUD completo. Foto comprimida no navegador (até 640px, JPEG) e salva como texto no próprio documento — sem custo de Storage. Campo "Visível no catálogo público" controla o que aparece pro cliente. O campo **Categoria** agora é um dropdown com as categorias cadastradas.
- **Clientes / Fornecedores**: CRUD completo, com CEP/UF/cidade estruturados (mesmo componente usado no cadastro de endereço do cliente).
- **Vendas / Compras**: registradas manualmente pelo admin (venda de balcão, compra de fornecedor), com parcelas e confirmação transacional de estoque.
- **Pedidos**: pedidos feitos pelo carrinho público. Confirmar pagamento, definir frete, despachar, entregar, cancelar — cada ação move o estoque via transação do Firestore (nunca duplica nem perde contagem, mesmo com ações simultâneas).
- **Faturamento**: visão só de leitura, juntando Vendas confirmadas + Pedidos pagos numa lista única com total — não grava nada novo, só combina as duas fontes na hora de exibir.
- **Notificações** *(só proprietário)*: dispara um push manual (título, corpo, link opcional) pra todo mundo que ativou notificações no catálogo.
- **Administradores** *(só proprietário)*: cria logins com nível de acesso, muda papel, exclui conta de verdade (não é só um registro escondido).
- **Configurações** *(só proprietário)*: contatos de WhatsApp exibidos no catálogo, e os dados de recebimento PIX (chave, nome, cidade).

---

## Categorias

O sistema agora trabalha com categorias como uma **entidade separada**, garantindo integridade e organização:

### Funcionalidades
- **CRUD completo** de categorias no painel administrativo (primeira aba do menu).
- **Dropdown** no formulário de produtos para selecionar a categoria (campo `categoriaId`).
- **Filtro por categoria** no catálogo público, populado automaticamente a partir das categorias cadastradas.
- **Exibição do nome da categoria** na lista de produtos e no detalhe do produto.

### Regras de negócio
- Categoria **não pode ser excluída** se houver produtos vinculados a ela.
- Ao criar um produto, o campo `categoriaId` é obrigatório.
- A leitura de categorias é pública (para o filtro do catálogo), mas escrita é restrita a administradores.

### Modelo de dados
```javascript
categorias/{categoriaId}: {
  nome: string,        // Nome da categoria (ex: "Feminino", "Masculino")
  descricao: string,   // Descrição opcional
  criadoEm: timestamp
}

Integridade referencial e bloqueios de exclusão

O sistema agora protege a integridade dos dados com bloqueios automáticos de exclusão:
Bloqueios implementados
Entidade	Bloqueio	Verificação
Categoria	Não excluir se tiver produtos	Busca produtos com categoriaId igual ao ID da categoria
Produto	Não excluir se tiver vendas ou pedidos	Verifica em vendas (itens) e pedidos (itens)
Cliente	Não excluir se tiver vendas ou pedidos	Verifica em vendas (clienteId) e pedidos (compradorUid)
Fornecedor	Não excluir se tiver compras	Verifica em compras (fornecedorId)
Experiência do usuário

    Ao tentar excluir um registro com vínculos, o sistema exibe uma mensagem clara explicando o motivo do bloqueio.

    O botão "Excluir" fica desabilitado enquanto a verificação é feita.

    Mensagens específicas indicam qual tipo de vínculo impede a exclusão.

Exemplo de mensagem de bloqueio
❌ Não é possível excluir a categoria "Feminino": há produtos vinculados a ela.
Remova ou reassigne os produtos primeiro.

Notificações push

Usa Firebase Cloud Messaging (FCM), gratuito.

Setup obrigatório (sem isso as notificações simplesmente não funcionam):

    Gerar a chave VAPID: Firebase Console → Configurações do projeto → Cloud Messaging → Web configuration → Generate key pair.

    Colar essa chave em dois lugares: a constante VAPID_KEY no topo de js/public.js e de js/pedido.js. Os dois precisam ter o mesmo valor.

    Preencher firebase-messaging-sw.js com a mesma firebaseConfig de js/firebase-config.js (ver passo 3 do setup do Firebase).

Como funciona:

    O visitante ativa notificações por um botão explícito (nunca um pedido automático assim que a página carrega — isso é penalizado pelos navegadores e incomoda quem não pediu).

    Token salvo em fcmTokens/{token} (Firestore) — leitura bloqueada pra todo mundo, exceto o proprietário (usado só pra mostrar a contagem de inscritos no painel).

    Broadcast (aba Notificações do admin): manda pra todo mundo inscrito, de uma vez.

    Por pedido (api/notificar-pedido.js): manda só pro token daquele pedido específico, disparado automaticamente quando o status muda (pago, despachado, entregue, frete definido).

    Fallback por WhatsApp: como ativar notificação é opt-in (o cliente pode nunca ter clicado), toda vez que o admin muda o status de um pedido (frete definido, pago, despachado, entregue) aparece um botão "Abrir WhatsApp" com a mensagem certa já pronta, apontando pro link de acompanhamento. Não envia nada sozinho — só facilita o admin mandar manualmente, garantindo que o cliente saiba mesmo sem push.

Pix — como funciona (e o que NÃO faz)

Modo "copia e cola" / QR code estático, gerado 100% no navegador a partir da chave configurada em Configurações (js/pix.js, sem biblioteca externa, sem gateway, sem custo).

    Não existe confirmação automática de pagamento. O admin confere no aplicativo do banco e clica "Confirmar pagamento" manualmente — só então o status muda e o estoque é debitado.

    O valor do QR code é sempre o valor real, calculado no servidor (api/criar-pedido) — impossível de adulterar pelo DevTools, mas a confirmação de que o Pix caiu continua sendo humana.

    Automatizar isso exigiria um gateway de pagamento (Mercado Pago, Efí, Asaas etc.) com webhook — custo por transação e mais uma camada de segurança pra implementar (validar a autenticidade do webhook). Fora do escopo atual por decisão consciente.

Frete (entrega combinada com o vendedor)

Retirada não tem frete — vai direto pra aguardando_pagamento. Entrega passa por uma etapa extra:

    Pedido nasce em aguardando_frete, com subtotalItens calculado e frete: null — nenhum PIX é gerado ainda, porque o valor final não está definido.

    O admin combina o frete com o cliente (WhatsApp já disponível no painel) e define o valor na aba Pedidos.

    Isso recalcula valorTotal = subtotalItens + frete, muda o status pra aguardando_pagamento, e dispara um push (se o cliente ativou notificações). Daí em diante segue o fluxo normal.

Se o cliente trocar de endereço depois do frete já cotado, o pedido volta automaticamente pra aguardando_frete e o frete é zerado — a cotação antiga não valia pro endereço novo. Essa transição específica é validada nas regras do Firestore (edicaoEnderecoPublicaValida), não só confiada ao código do navegador.

O prazo de 24h (próxima seção) também vale pra etapa aguardando_frete.

Cancelamento e prazo de pagamento

    Antes de pagar (aguardando_frete ou aguardando_pagamento): o cliente cancela sozinho, a qualquer momento, pela página de acompanhamento — nada foi debitado do estoque ainda.

    Prazo de 24h: se o pedido ficar parado numa dessas duas etapas por mais de 24h, é cancelado automaticamente (canceladoPor: 'expiracao_automatica') — sem cron job: a checagem roda toda vez que alguém abre a página de acompanhamento ou a aba Pedidos do admin. Pra mudar o prazo, ajuste PRAZO_PAGAMENTO_HORAS em js/pedido.js e em js/admin.js (precisam ficar iguais).

    Depois de pago (pago ou despachado): o cliente não cancela sozinho — o dinheiro já está com a loja, e reembolso é manual. Ele só "Solicita cancelamento" (motivo opcional), o que destaca o pedido no painel; o admin processa o reembolso por fora e só então cancela de fato.

    Depois de entregue: sem fluxo de cancelamento — isso já seria devolução, processo diferente, fora do escopo atual.

Contas de cliente (login obrigatório para finalizar pedido)

Diferente do login do admin, qualquer pessoa pode criar conta de cliente livremente — e-mail/senha ou Google. A segurança não está em restringir quem entra, está em o que uma conta de cliente consegue fazer depois de logada.

    Mesma base de Firebase Auth do admin, mas contas de cliente nunca recebem custom claim de papel — e como as regras do Firestore para produtos/clientes/fornecedores exigem esse papel (não só "estar logado"), um cliente autenticado continua sem nenhum acesso a essas coleções.

    Perfil em contasClientes/{uid} (nome, telefone, endereços) — cada cliente só lê/escreve o próprio documento; admin só lê (suporte), nunca escreve.

    api/criar-pedido exige e verifica o token de login no servidor — sem token válido, o pedido é recusado ali, não só escondido na interface.

    "Meus Pedidos" consulta where('compradorUid','==', uid) — as regras do Firestore só permitem esse tipo de consulta filtrada pro próprio dono.

Endereços: múltiplos por cliente, um marcado como principal, com formulário estruturado (CEP com busca automática via ViaCEP, UF/cidade reais via IBGE — mesma técnica do cadastro de clientes do admin). Um único componente (montarFormularioEndereco, em js/conta-cliente.js) é reaproveitado em Minha Conta, Checkout e na troca de endereço de um pedido — em vez de três formulários divergentes.

Modelo de dados

categorias: nome, descricao (opcional), criadoEm.

produtos: nome, marca, categoriaId (referência à categoria), volume, descricao (string) · valorAVista, valorPrazo, parcelas, estoque (number) · fornecedorId (referência) · fotoUrl (base64) · ativo (boolean) · criadoEm.

clientes: nome, telefone, email, cpf, endereco, cep, uf, cidade, observacoes, criadoEm.

fornecedores: nome, contato, telefone, email, cnpj, observacoes, criadoEm.

configuracoes (doc único geral): contatos (array {label, numero}), mensagemPadrao, pixChave, pixNome, pixCidade, atualizadoEm.

vendas / compras (registradas pelo admin): clienteId/fornecedorId, clienteNome/fornecedorNome, itens (array {produtoId, nome, quantidade, valorUnitario}), valorTotal, formaPagamento (avista|parcelado), parcelas (array {numero, valor, vencimento, status, pagoEm}), status (pendente|confirmada|cancelada), criadoEm/confirmadaEm/canceladaEm.

pedidos (carrinho público):
Campo	Tipo
compradorUid	uid da conta logada que fez o pedido (verificado no servidor)
comprador	{nome, telefone, tipoEntrega, endereco}
itens	array — calculado no servidor, nunca aceito do navegador
valorTotal, subtotalItens, frete	number (frete é null até ser definido)
status	aguardando_frete (só entrega) → aguardando_pagamento → pago → despachado → entregue (ou cancelado)
fcmToken, comprovanteUrl	opcionais, preenchidos pelo cliente — comprovanteUrl aceita imagem (comprimida) ou PDF (base64 direto), o prefixo data: indica qual é
cancelamentoSolicitado, motivoCancelamento, canceladoPor	ver seção de Cancelamento
criadoEm, pagoEm, despachadoEm, entregueEm, canceladoEm	timestamps

contasClientes (id = uid): nome, telefone, enderecos (array {id, label, cep, rua, numero, complemento, bairro, cidade, uf, endereco, principal}).

fcmTokens (id = o próprio token): registro de dispositivos inscritos em notificações — leitura só pro proprietário.

Administradores não ficam no Firestore — vivem só no Firebase Authentication (custom claim role).

Segurança — resumo

    Papéis via custom claim, não só "estar autenticado" — fecha o buraco de qualquer login (inclusive Google) dar acesso administrativo sem querer.

    admin.html bloqueia por completo quem não tem papel, com uma tela própria de "Acesso negado" — nenhuma aba chega a tentar carregar dado nenhum. Isso importa porque o Firebase Auth reaproveita sessão entre páginas do mesmo site: se um cliente estiver logado no mesmo navegador e alguém abrir admin.html, a sessão do cliente é reconhecida automaticamente (sem pedir login de novo) — mas sem o custom claim de papel, a tela trava ali, mesmo que o Firestore já recusasse os dados por trás.

    Preço sempre calculado no servidor (api/criar-pedido), nunca aceito do navegador — impossível adulterar pelo DevTools.

    Escritas públicas no Firestore são todas de campo único e validadas na própria regra (não só no JavaScript): fcmToken, comprovanteUrl (com limite de tamanho), cancelamento (só em status sem dinheiro comprometido), solicitação de cancelamento pós-pagamento (não muda status sozinha), troca de endereço com reset de frete (a regra confere a transição exata, não confia no código do cliente).

    Chave de conta de serviço fica só na Vercel (variável de ambiente), nunca no repositório.

    Integridade referencial: bloqueios de exclusão para categorias, produtos, clientes e fornecedores com vínculos (ver seção própria).

O que fica fora do escopo, por decisão consciente: confirmação automática de pagamento Pix (exigiria gateway pago), auditoria/histórico de alterações, e proteção contra vazamento da própria chave de conta de serviço.

## Testando localmente

```bash
cd perfumaria-app
python3 -m http.server 8000
```

Funciona pro catálogo, carrinho e login. **As funções em `/api` não rodam nesse servidor simples** — só existem no ambiente da Vercel. Pra testar isso localmente também:

```bash
npm i -g vercel
vercel dev
```

Limitações conhecidas

    icon-192.png e icon-72.png são referenciados pelas notificações push mas não existem no projeto — as notificações aparecem com ícone padrão/quebrado do navegador em vez do ícone da loja. Fácil de corrigir (só adicionar esses dois arquivos de imagem na raiz do projeto), mas não foi feito.

    VAPID_KEY e PRAZO_PAGAMENTO_HORAS estão duplicados em dois arquivos cada — mudar um sem mudar o outro quebra a consistência silenciosamente.

    Sem automação de reembolso Pix, sem gateway de pagamento, sem cálculo automático de frete por distância — todos por decisão consciente de manter o projeto sem custo, documentados nas seções próprias.

Personalização

    Cores, fontes, espaçamentos: variáveis CSS no topo de css/style.css (:root { ... }).

    Novo campo em produtos/clientes/fornecedores: array campos da entidade em js/admin.js.

    Tamanho/qualidade de foto comprimida: FOTO_LADO_MAX e FOTO_QUALIDADE no topo de js/admin.js.

    Prazo de pagamento: PRAZO_PAGAMENTO_HORAS em js/pedido.js e js/admin.js (mudar os dois).

Migração para categorias

Se você já tem produtos cadastrados com o campo categoria como texto livre, é necessário migrar os dados para o novo modelo com categoriaId.
Script de migração

Execute o script abaixo UMA VEZ no console do navegador (logado como admin) antes de usar o sistema em produção:

// ============================================================
// SCRIPT DE MIGRAÇÃO: Converter categoria texto → categoriaId
// ============================================================
// Execute UMA VEZ no console do navegador (admin logado)
// ============================================================

(async function migrarCategorias() {
  console.log('🔄 Iniciando migração de categorias...');

  const { db, collection, getDocs, doc, updateDoc, addDoc, serverTimestamp } = await import('./firebase-config.js');

  // 1. Buscar todas as categorias existentes
  const categoriasSnap = await getDocs(collection(db, 'categorias'));
  const categoriasMap = {};
  categoriasSnap.forEach(doc => {
    const data = doc.data();
    categoriasMap[data.nome?.toLowerCase().trim()] = doc.id;
  });
  console.log(`📂 ${Object.keys(categoriasMap).length} categorias encontradas.`);

  // 2. Buscar produtos que têm campo 'categoria' (texto) mas não têm 'categoriaId'
  const produtosSnap = await getDocs(collection(db, 'produtos'));
  let convertidos = 0;
  let criados = 0;

  for (const docSnap of produtosSnap.docs) {
    const data = docSnap.data();
    const produtoId = docSnap.id;
    const categoriaTexto = data.categoria?.trim();

    // Se já tem categoriaId, pula
    if (data.categoriaId) {
      console.log(`⏭️ Produto "${data.nome}" já tem categoriaId: ${data.categoriaId}`);
      continue;
    }

    // Se não tem categoria texto, pula
    if (!categoriaTexto) {
      console.log(`⏭️ Produto "${data.nome}" sem categoria definida.`);
      continue;
    }

    const chave = categoriaTexto.toLowerCase().trim();
    let categoriaId = categoriasMap[chave];

    // Se a categoria não existe, cria
    if (!categoriaId) {
      console.log(`➕ Criando nova categoria: "${categoriaTexto}"`);
      const novaCatRef = await addDoc(collection(db, 'categorias'), {
        nome: categoriaTexto,
        criadoEm: serverTimestamp(),
      });
      categoriaId = novaCatRef.id;
      categoriasMap[chave] = categoriaId;
      criados++;
    }

    // Atualiza o produto
    await updateDoc(doc(db, 'produtos', produtoId), {
      categoriaId: categoriaId,
    });
    convertidos++;
    console.log(`✅ Produto "${data.nome}" → categoriaId: ${categoriaId}`);
  }

  console.log(`\n📊 RESUMO:`);
  console.log(`   • ${convertidos} produtos convertidos`);
  console.log(`   • ${criados} categorias criadas`);
  console.log(`✅ Migração concluída!`);
})();

Passos para executar a migração

    Faça login no painel administrativo (admin.html) com uma conta de proprietário.

    Abra o console do navegador (F12 → Console).

    Cole o script acima e pressione Enter.

    Aguarde a conclusão.

    Verifique os logs para confirmar que todos os produtos foram convertidos.

⚠️ Importante: Faça um backup do Firestore antes de rodar o script em produção.


---

## ✅ **Resumo dos arquivos para substituir:**

| Arquivo | Substituir? |
|---------|-------------|
| `js/admin.js` | ✅ **SIM** (já gerei) |
| `admin.html` | ✅ **SIM** (já gerei) |
| `js/public.js` | ✅ **SIM** (já gerei) |
| `README.md` | ✅ **SIM** (acabei de gerar) |

---

**Agora você tem todos os 4 arquivos para substituir!** 🚀
